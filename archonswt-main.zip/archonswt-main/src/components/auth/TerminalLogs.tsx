import { useEffect, useState, useRef } from "react";

interface TerminalLogsProps {
  phase: "scanning" | "locating" | "connecting" | "complete";
}

interface LogEntry {
  text: string;
  type: "command" | "output" | "success" | "warning" | "error";
  delay: number;
}

const scanningLogs: LogEntry[] = [
  { text: "$ init satellite-uplink --mode=secure", type: "command", delay: 0 },
  { text: "Initializing secure uplink protocol v3.2.1...", type: "output", delay: 300 },
  { text: "$ scan --network --range=global", type: "command", delay: 800 },
  { text: "Scanning available satellite nodes...", type: "output", delay: 1100 },
  { text: "[INFO] Found 147 active nodes in range", type: "output", delay: 1600 },
  { text: "[WARN] Signal interference detected on band 4.7GHz", type: "warning", delay: 2000 },
  { text: "$ route --optimize --priority=latency", type: "command", delay: 2400 },
  { text: "Calculating optimal routing path...", type: "output", delay: 2700 },
];

const locatingLogs: LogEntry[] = [
  { text: "$ geolocate --source=multi-sat --precision=high", type: "command", delay: 0 },
  { text: "Triangulating position via 3 satellites...", type: "output", delay: 400 },
  { text: "[INFO] SAT-1: Signal acquired (strength: 94%)", type: "output", delay: 800 },
  { text: "[INFO] SAT-2: Signal acquired (strength: 87%)", type: "output", delay: 1100 },
  { text: "[INFO] SAT-3: Signal acquired (strength: 91%)", type: "output", delay: 1400 },
  { text: "Position locked. Accuracy: +/- 2.3m", type: "success", delay: 1800 },
  { text: "$ verify --identity --protocol=zero-knowledge", type: "command", delay: 2200 },
  { text: "Running identity verification...", type: "output", delay: 2500 },
];

const connectingLogs: LogEntry[] = [
  { text: "$ connect --secure --encryption=AES-256-GCM", type: "command", delay: 0 },
  { text: "Establishing encrypted tunnel...", type: "output", delay: 400 },
  { text: "[INFO] Handshake initiated with primary node", type: "output", delay: 800 },
  { text: "[INFO] Key exchange: ECDH-P384", type: "output", delay: 1100 },
  { text: "[INFO] Certificate verified: SHA-384", type: "output", delay: 1400 },
  { text: "$ auth --token --method=biometric", type: "command", delay: 1800 },
  { text: "Authenticating session token...", type: "output", delay: 2100 },
  { text: "[INFO] Session ID: 0x7F3A2B1C", type: "output", delay: 2400 },
];

const completeLogs: LogEntry[] = [
  { text: "[SUCCESS] Secure connection established", type: "success", delay: 0 },
  { text: "[INFO] Encryption: ACTIVE (AES-256-GCM)", type: "output", delay: 300 },
  { text: "[INFO] Latency: 23ms | Bandwidth: 1.2 Gbps", type: "output", delay: 600 },
  { text: "[INFO] Session authenticated and verified", type: "success", delay: 900 },
  { text: "$ status --all", type: "command", delay: 1200 },
  { text: "CONNECTION: SECURED", type: "success", delay: 1500 },
  { text: "Welcome to the secure network.", type: "success", delay: 1800 },
];

const TerminalLogs = ({ phase }: TerminalLogsProps) => {
  const [displayedLogs, setDisplayedLogs] = useState<LogEntry[]>([]);
  const [currentText, setCurrentText] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const lastPhaseRef = useRef<string>("");

  const getLogs = (currentPhase: string): LogEntry[] => {
    switch (currentPhase) {
      case "scanning":
        return scanningLogs;
      case "locating":
        return locatingLogs;
      case "connecting":
        return connectingLogs;
      case "complete":
        return completeLogs;
      default:
        return [];
    }
  };

  useEffect(() => {
    if (phase !== lastPhaseRef.current) {
      lastPhaseRef.current = phase;
      const logs = getLogs(phase);
      let logIndex = 0;

      const addLog = () => {
        if (logIndex >= logs.length) return;

        const log = logs[logIndex];
        setIsTyping(true);
        
        // Type out the text character by character
        let charIndex = 0;
        const typeInterval = setInterval(() => {
          if (charIndex <= log.text.length) {
            setCurrentText(log.text.slice(0, charIndex));
            charIndex++;
          } else {
            clearInterval(typeInterval);
            setIsTyping(false);
            setDisplayedLogs(prev => [...prev.slice(-7), log]); // Keep last 8 logs
            setCurrentText("");
            logIndex++;
            
            if (logIndex < logs.length) {
              setTimeout(addLog, logs[logIndex].delay);
            }
          }
        }, 15); // Typing speed
      };

      // Start after initial delay
      setTimeout(addLog, 200);
    }
  }, [phase]);

  // Auto-scroll to bottom
  useEffect(() => {
    if (containerRef.current) {
      containerRef.current.scrollTop = containerRef.current.scrollHeight;
    }
  }, [displayedLogs, currentText]);

  const getLogColor = (type: LogEntry["type"]) => {
    switch (type) {
      case "command":
        return "text-cyan-400";
      case "success":
        return "text-success";
      case "warning":
        return "text-yellow-400";
      case "error":
        return "text-destructive";
      default:
        return "text-gold/80";
    }
  };

  return (
    <div className="absolute bottom-20 right-4 sm:bottom-24 sm:right-8 w-[280px] sm:w-[350px] max-h-[180px] sm:max-h-[200px]">
      <div className="bg-navy/80 backdrop-blur-sm border border-gold/30 rounded-lg overflow-hidden">
        {/* Terminal Header */}
        <div className="flex items-center gap-2 px-3 py-1.5 bg-navy border-b border-gold/20">
          <div className="flex gap-1.5">
            <div className="w-2.5 h-2.5 rounded-full bg-destructive/80" />
            <div className="w-2.5 h-2.5 rounded-full bg-yellow-500/80" />
            <div className="w-2.5 h-2.5 rounded-full bg-success/80" />
          </div>
          <span className="text-[10px] sm:text-xs text-gold/60 font-mono ml-2">secure-terminal</span>
        </div>

        {/* Terminal Content */}
        <div 
          ref={containerRef}
          className="p-2 sm:p-3 h-[130px] sm:h-[150px] overflow-y-auto scrollbar-thin scrollbar-thumb-gold/20 scrollbar-track-transparent"
        >
          {displayedLogs.map((log, index) => (
            <div 
              key={index} 
              className={`font-mono text-[10px] sm:text-xs leading-relaxed ${getLogColor(log.type)} animate-fade-in`}
            >
              {log.text}
            </div>
          ))}
          
          {/* Currently typing line */}
          {currentText && (
            <div className="font-mono text-[10px] sm:text-xs leading-relaxed text-gold/80">
              {currentText}
              <span className="inline-block w-1.5 h-3 bg-gold ml-0.5 animate-pulse" />
            </div>
          )}
          
          {/* Cursor when not typing */}
          {!isTyping && !currentText && (
            <div className="font-mono text-[10px] sm:text-xs text-gold/60">
              <span className="inline-block w-1.5 h-3 bg-gold/60 animate-pulse" />
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default TerminalLogs;

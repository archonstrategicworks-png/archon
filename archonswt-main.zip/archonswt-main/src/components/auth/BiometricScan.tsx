import { useEffect, useState } from "react";
import { Fingerprint, ShieldCheck } from "lucide-react";

interface BiometricScanProps {
  phase: "scanning" | "locating" | "connecting" | "complete";
}

const BiometricScan = ({ phase }: BiometricScanProps) => {
  const [scanProgress, setScanProgress] = useState(0);
  const [scanLines, setScanLines] = useState<number[]>([]);

  // Only show during connecting and complete phases
  const isActive = phase === "connecting" || phase === "complete";

  useEffect(() => {
    if (phase === "connecting") {
      setScanProgress(0);
      const interval = setInterval(() => {
        setScanProgress(prev => {
          if (prev >= 100) {
            clearInterval(interval);
            return 100;
          }
          return prev + 2;
        });
      }, 50);
      return () => clearInterval(interval);
    } else if (phase === "complete") {
      setScanProgress(100);
    }
  }, [phase]);

  // Generate random scan line positions
  useEffect(() => {
    if (phase === "connecting") {
      const interval = setInterval(() => {
        setScanLines(prev => {
          const newLines = [...prev, Math.random() * 100];
          return newLines.slice(-5); // Keep only last 5 lines
        });
      }, 200);
      return () => clearInterval(interval);
    }
  }, [phase]);

  if (!isActive) return null;

  return (
    <div className="absolute top-1/2 right-4 sm:right-8 -translate-y-1/2">
      <div className="relative w-[100px] h-[130px] sm:w-[120px] sm:h-[150px]">
        {/* Background Panel */}
        <div className="absolute inset-0 bg-navy/80 backdrop-blur-sm border border-gold/40 rounded-lg overflow-hidden">
          {/* Header */}
          <div className="absolute top-0 left-0 right-0 bg-navy/90 border-b border-gold/30 px-2 py-1">
            <span className="text-[8px] sm:text-[10px] font-mono text-gold">
              BIOMETRIC AUTH
            </span>
          </div>

          {/* Fingerprint Container */}
          <div className="absolute inset-0 mt-6 mb-6 flex items-center justify-center">
            <div className="relative w-16 h-20 sm:w-20 sm:h-24">
              {/* Fingerprint Icon with gradient mask */}
              <div 
                className="relative"
                style={{
                  maskImage: phase === "complete" 
                    ? "none" 
                    : `linear-gradient(to top, transparent ${100 - scanProgress}%, black ${100 - scanProgress}%)`,
                  WebkitMaskImage: phase === "complete" 
                    ? "none" 
                    : `linear-gradient(to top, transparent ${100 - scanProgress}%, black ${100 - scanProgress}%)`,
                }}
              >
                <Fingerprint 
                  className={`w-16 h-20 sm:w-20 sm:h-24 transition-colors duration-300 ${
                    phase === "complete" ? "text-success" : "text-cyan-400"
                  }`}
                  strokeWidth={1}
                />
              </div>

              {/* Scan Line Effect */}
              {phase === "connecting" && (
                <div 
                  className="absolute left-0 right-0 h-0.5 bg-gradient-to-r from-transparent via-cyan-400 to-transparent"
                  style={{
                    top: `${scanProgress}%`,
                    boxShadow: "0 0 10px #00ffff, 0 0 20px #00ffff",
                    transition: "top 0.1s linear",
                  }}
                />
              )}

              {/* Random scan lines */}
              {phase === "connecting" && scanLines.map((pos, index) => (
                <div 
                  key={index}
                  className="absolute left-0 right-0 h-px bg-cyan-400/30"
                  style={{
                    top: `${pos}%`,
                    opacity: 1 - (index * 0.2),
                  }}
                />
              ))}

              {/* Corner brackets */}
              <svg className="absolute inset-0 w-full h-full" viewBox="0 0 80 100">
                <path 
                  d="M 5 15 L 5 5 L 15 5" 
                  fill="none" 
                  stroke={phase === "complete" ? "#48bb78" : "#00ffff"} 
                  strokeWidth="1.5" 
                />
                <path 
                  d="M 65 5 L 75 5 L 75 15" 
                  fill="none" 
                  stroke={phase === "complete" ? "#48bb78" : "#00ffff"} 
                  strokeWidth="1.5" 
                />
                <path 
                  d="M 75 85 L 75 95 L 65 95" 
                  fill="none" 
                  stroke={phase === "complete" ? "#48bb78" : "#00ffff"} 
                  strokeWidth="1.5" 
                />
                <path 
                  d="M 15 95 L 5 95 L 5 85" 
                  fill="none" 
                  stroke={phase === "complete" ? "#48bb78" : "#00ffff"} 
                  strokeWidth="1.5" 
                />
              </svg>

              {/* Pulse effect on complete */}
              {phase === "complete" && (
                <>
                  <div className="absolute inset-0 border-2 border-success/50 rounded-lg animate-ping" />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <ShieldCheck className="absolute w-8 h-8 text-success animate-fade-in" />
                  </div>
                </>
              )}
            </div>
          </div>

          {/* Progress Bar */}
          <div className="absolute bottom-0 left-0 right-0 bg-navy/90 border-t border-gold/30 p-2">
            <div className="h-1 bg-navy rounded-full overflow-hidden mb-1">
              <div 
                className={`h-full transition-all duration-100 ${
                  phase === "complete" 
                    ? "bg-success" 
                    : "bg-gradient-to-r from-cyan-400 to-cyan-300"
                }`}
                style={{ width: `${scanProgress}%` }}
              />
            </div>
            <div className="text-center">
              <span className={`text-[8px] sm:text-[9px] font-mono ${
                phase === "complete" ? "text-success" : "text-cyan-400"
              }`}>
                {phase === "complete" ? "VERIFIED" : `SCANNING ${scanProgress}%`}
              </span>
            </div>
          </div>

          {/* Scanning indicator dots */}
          {phase === "connecting" && (
            <div className="absolute top-7 right-2 flex gap-0.5">
              <div className="w-1 h-1 rounded-full bg-cyan-400 animate-pulse" />
              <div className="w-1 h-1 rounded-full bg-cyan-400 animate-pulse" style={{ animationDelay: "0.2s" }} />
              <div className="w-1 h-1 rounded-full bg-cyan-400 animate-pulse" style={{ animationDelay: "0.4s" }} />
            </div>
          )}

          {/* Success checkmark */}
          {phase === "complete" && (
            <div className="absolute top-7 right-2">
              <ShieldCheck className="w-3 h-3 text-success" />
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default BiometricScan;

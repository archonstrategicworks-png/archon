import { useEffect, useState } from "react";
import { MapPin, Crosshair } from "lucide-react";

interface LocationMiniMapProps {
  latitude?: number;
  longitude?: number;
  city?: string;
  phase: "scanning" | "locating" | "connecting" | "complete";
}

const LocationMiniMap = ({ latitude, longitude, city, phase }: LocationMiniMapProps) => {
  const [zoomLevel, setZoomLevel] = useState(1);
  const [scanAngle, setScanAngle] = useState(0);

  // Animate zoom based on phase
  useEffect(() => {
    switch (phase) {
      case "scanning":
        setZoomLevel(1);
        break;
      case "locating":
        setZoomLevel(2);
        break;
      case "connecting":
        setZoomLevel(3);
        break;
      case "complete":
        setZoomLevel(4);
        break;
    }
  }, [phase]);

  // Animate scan line
  useEffect(() => {
    if (phase === "scanning" || phase === "locating") {
      const interval = setInterval(() => {
        setScanAngle(prev => (prev + 3) % 360);
      }, 30);
      return () => clearInterval(interval);
    }
  }, [phase]);

  // Convert lat/long to approximate grid position
  const getGridPosition = () => {
    if (!latitude || !longitude) return { x: 50, y: 50 };
    // Normalize to 0-100 range
    const x = ((longitude + 180) / 360) * 100;
    const y = ((90 - latitude) / 180) * 100;
    return { x, y };
  };

  const pos = getGridPosition();

  // Don't show during initial scanning
  if (phase === "scanning" && !latitude) return null;

  return (
    <div className="absolute bottom-24 left-4 sm:bottom-28 sm:left-8 w-[120px] h-[120px] sm:w-[150px] sm:h-[150px]">
      <div className="relative w-full h-full bg-navy/80 backdrop-blur-sm border border-gold/40 rounded-lg overflow-hidden">
        {/* Header */}
        <div className="absolute top-0 left-0 right-0 bg-navy/90 border-b border-gold/30 px-2 py-1 z-10">
          <div className="flex items-center gap-1">
            <Crosshair className="w-3 h-3 text-gold" />
            <span className="text-[8px] sm:text-[10px] font-mono text-gold truncate">
              {city || "LOCATING..."}
            </span>
          </div>
        </div>

        {/* Map Grid */}
        <svg viewBox="0 0 100 100" className="w-full h-full">
          <defs>
            {/* Grid pattern */}
            <pattern id="miniMapGrid" width="10" height="10" patternUnits="userSpaceOnUse">
              <path d="M 10 0 L 0 0 0 10" fill="none" stroke="#d4af37" strokeWidth="0.2" opacity="0.3" />
            </pattern>
            
            {/* Radar gradient */}
            <linearGradient id="radarGradient" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#00ffff" stopOpacity="0" />
              <stop offset="100%" stopColor="#00ffff" stopOpacity="0.5" />
            </linearGradient>

            {/* Glow effect */}
            <filter id="miniMapGlow" x="-50%" y="-50%" width="200%" height="200%">
              <feGaussianBlur stdDeviation="2" result="coloredBlur" />
              <feMerge>
                <feMergeNode in="coloredBlur" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>

            {/* Zoom clip path */}
            <clipPath id="zoomClip">
              <circle cx="50" cy="55" r={45 / zoomLevel} />
            </clipPath>
          </defs>

          {/* Background grid */}
          <rect width="100" height="100" fill="url(#miniMapGrid)" />

          {/* Zoomed area effect */}
          <g style={{ 
            transform: `scale(${zoomLevel})`, 
            transformOrigin: `${pos.x}% ${pos.y}%`,
            transition: "transform 1s ease-out"
          }}>
            {/* Simplified continent shapes */}
            <g opacity="0.4" fill="none" stroke="#d4af37" strokeWidth="0.3">
              {/* North America */}
              <ellipse cx="20" cy="35" rx="12" ry="10" />
              {/* South America */}
              <ellipse cx="28" cy="65" rx="6" ry="12" />
              {/* Europe */}
              <ellipse cx="50" cy="30" rx="8" ry="6" />
              {/* Africa */}
              <ellipse cx="52" cy="55" rx="8" ry="12" />
              {/* Asia */}
              <ellipse cx="72" cy="35" rx="15" ry="12" />
              {/* Australia */}
              <ellipse cx="82" cy="65" rx="6" ry="5" />
            </g>

            {/* Grid lines */}
            {[20, 40, 60, 80].map(y => (
              <line key={`h-${y}`} x1="0" y1={y} x2="100" y2={y} stroke="#d4af37" strokeWidth="0.1" opacity="0.2" />
            ))}
            {[20, 40, 60, 80].map(x => (
              <line key={`v-${x}`} x1={x} y1="0" x2={x} y2="100" stroke="#d4af37" strokeWidth="0.1" opacity="0.2" />
            ))}
          </g>

          {/* Radar sweep (during scanning/locating) */}
          {(phase === "scanning" || phase === "locating") && (
            <g transform={`rotate(${scanAngle} ${pos.x} ${pos.y})`}>
              <path
                d={`M ${pos.x} ${pos.y} L ${pos.x + 40} ${pos.y} A 40 40 0 0 1 ${pos.x + 40 * Math.cos(Math.PI / 6)} ${pos.y + 40 * Math.sin(Math.PI / 6)} Z`}
                fill="url(#radarGradient)"
                opacity="0.5"
              />
            </g>
          )}

          {/* Location marker */}
          {latitude && longitude && (
            <g>
              {/* Pulse rings */}
              <circle cx={pos.x} cy={pos.y} r="8" fill="none" stroke={phase === "complete" ? "#48bb78" : "#00ffff"} strokeWidth="0.5" opacity="0.5">
                <animate attributeName="r" values="3;12;3" dur="2s" repeatCount="indefinite" />
                <animate attributeName="opacity" values="0.8;0;0.8" dur="2s" repeatCount="indefinite" />
              </circle>
              <circle cx={pos.x} cy={pos.y} r="5" fill="none" stroke={phase === "complete" ? "#48bb78" : "#00ffff"} strokeWidth="0.5" opacity="0.7">
                <animate attributeName="r" values="2;8;2" dur="2s" repeatCount="indefinite" begin="0.5s" />
                <animate attributeName="opacity" values="0.8;0;0.8" dur="2s" repeatCount="indefinite" begin="0.5s" />
              </circle>

              {/* Center point */}
              <circle 
                cx={pos.x} 
                cy={pos.y} 
                r="2" 
                fill={phase === "complete" ? "#48bb78" : "#00ffff"} 
                filter="url(#miniMapGlow)"
              />

              {/* Crosshair */}
              <line x1={pos.x - 6} y1={pos.y} x2={pos.x - 2} y2={pos.y} stroke={phase === "complete" ? "#48bb78" : "#00ffff"} strokeWidth="0.5" />
              <line x1={pos.x + 2} y1={pos.y} x2={pos.x + 6} y2={pos.y} stroke={phase === "complete" ? "#48bb78" : "#00ffff"} strokeWidth="0.5" />
              <line x1={pos.x} y1={pos.y - 6} x2={pos.x} y2={pos.y - 2} stroke={phase === "complete" ? "#48bb78" : "#00ffff"} strokeWidth="0.5" />
              <line x1={pos.x} y1={pos.y + 2} x2={pos.x} y2={pos.y + 6} stroke={phase === "complete" ? "#48bb78" : "#00ffff"} strokeWidth="0.5" />
            </g>
          )}

          {/* Corner brackets */}
          <path d="M 5 15 L 5 5 L 15 5" fill="none" stroke="#d4af37" strokeWidth="0.5" />
          <path d="M 85 5 L 95 5 L 95 15" fill="none" stroke="#d4af37" strokeWidth="0.5" />
          <path d="M 95 85 L 95 95 L 85 95" fill="none" stroke="#d4af37" strokeWidth="0.5" />
          <path d="M 15 95 L 5 95 L 5 85" fill="none" stroke="#d4af37" strokeWidth="0.5" />
        </svg>

        {/* Coordinates display */}
        {latitude && longitude && (
          <div className="absolute bottom-0 left-0 right-0 bg-navy/90 border-t border-gold/30 px-2 py-0.5">
            <div className="text-[7px] sm:text-[8px] font-mono text-gold/70 text-center">
              {latitude.toFixed(2)}°, {longitude.toFixed(2)}°
            </div>
          </div>
        )}

        {/* Zoom indicator */}
        <div className="absolute top-6 right-1 flex flex-col gap-0.5">
          {[1, 2, 3, 4].map(level => (
            <div 
              key={level}
              className={`w-1 h-1.5 rounded-sm transition-colors duration-300 ${
                level <= zoomLevel 
                  ? phase === "complete" ? "bg-success" : "bg-cyan-400" 
                  : "bg-gold/30"
              }`}
            />
          ))}
        </div>

        {/* Scanning indicator */}
        {(phase === "scanning" || phase === "locating") && (
          <div className="absolute top-6 left-1">
            <div className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
          </div>
        )}

        {/* Lock indicator when complete */}
        {phase === "complete" && (
          <div className="absolute top-6 left-1">
            <MapPin className="w-3 h-3 text-success" />
          </div>
        )}
      </div>
    </div>
  );
};

export default LocationMiniMap;

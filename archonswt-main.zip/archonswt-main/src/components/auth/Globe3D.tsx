import { useRef, useMemo, useState, useEffect } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { Sphere, OrbitControls, Stars, Trail } from "@react-three/drei";
import * as THREE from "three";

interface GlobeProps {
  phase: "scanning" | "locating" | "connecting" | "complete";
  targetLat?: number;
  targetLng?: number;
}

// Celebration Particles that burst when connection is complete
const CelebrationParticles = ({ active }: { active: boolean }) => {
  const particlesRef = useRef<THREE.Points>(null);
  const [triggered, setTriggered] = useState(false);
  const velocitiesRef = useRef<Float32Array | null>(null);
  const startTimeRef = useRef<number>(0);

  const { geometry, velocities } = useMemo(() => {
    const count = 200;
    const positions = new Float32Array(count * 3);
    const colors = new Float32Array(count * 3);
    const vels = new Float32Array(count * 3);
    
    const goldColor = new THREE.Color("#d4af37");
    const greenColor = new THREE.Color("#48bb78");
    const cyanColor = new THREE.Color("#00ffff");
    
    for (let i = 0; i < count; i++) {
      // Start at center
      positions[i * 3] = 0;
      positions[i * 3 + 1] = 0;
      positions[i * 3 + 2] = 0;
      
      // Random velocities in all directions (burst effect)
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(2 * Math.random() - 1);
      const speed = 2 + Math.random() * 3;
      
      vels[i * 3] = Math.sin(phi) * Math.cos(theta) * speed;
      vels[i * 3 + 1] = Math.sin(phi) * Math.sin(theta) * speed;
      vels[i * 3 + 2] = Math.cos(phi) * speed;
      
      // Random colors
      const colorChoice = Math.random();
      const color = colorChoice < 0.4 ? goldColor : colorChoice < 0.7 ? greenColor : cyanColor;
      colors[i * 3] = color.r;
      colors[i * 3 + 1] = color.g;
      colors[i * 3 + 2] = color.b;
    }
    
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geo.setAttribute('color', new THREE.BufferAttribute(colors, 3));
    
    return { geometry: geo, velocities: vels };
  }, []);

  useEffect(() => {
    velocitiesRef.current = velocities;
  }, [velocities]);

  useEffect(() => {
    if (active && !triggered) {
      setTriggered(true);
      startTimeRef.current = 0;
    }
  }, [active, triggered]);

  useFrame((state, delta) => {
    if (!triggered || !particlesRef.current || !velocitiesRef.current) return;
    
    startTimeRef.current += delta;
    const positions = particlesRef.current.geometry.attributes.position.array as Float32Array;
    const vels = velocitiesRef.current;
    
    // Animate for 2 seconds
    if (startTimeRef.current < 2) {
      const damping = Math.max(0, 1 - startTimeRef.current * 0.5);
      
      for (let i = 0; i < positions.length / 3; i++) {
        positions[i * 3] += vels[i * 3] * delta * damping;
        positions[i * 3 + 1] += vels[i * 3 + 1] * delta * damping - delta * 0.5; // gravity
        positions[i * 3 + 2] += vels[i * 3 + 2] * delta * damping;
      }
      
      particlesRef.current.geometry.attributes.position.needsUpdate = true;
      
      // Fade out
      const material = particlesRef.current.material as THREE.PointsMaterial;
      material.opacity = Math.max(0, 1 - startTimeRef.current * 0.5);
    }
  });

  if (!triggered) return null;

  return (
    <points ref={particlesRef} geometry={geometry}>
      <pointsMaterial
        size={0.08}
        vertexColors
        transparent
        opacity={1}
        sizeAttenuation
        depthWrite={false}
      />
    </points>
  );
};

// Atmospheric Glow component
const AtmosphericGlow = ({ phase }: { phase: string }) => {
  const glowRef1 = useRef<THREE.Mesh>(null);
  const glowRef2 = useRef<THREE.Mesh>(null);
  const glowRef3 = useRef<THREE.Mesh>(null);

  const getGlowIntensity = () => {
    switch (phase) {
      case "scanning":
        return { opacity: 0.1, scale: 1.15 };
      case "locating":
        return { opacity: 0.15, scale: 1.2 };
      case "connecting":
        return { opacity: 0.25, scale: 1.25 };
      case "complete":
        return { opacity: 0.4, scale: 1.35 };
      default:
        return { opacity: 0.1, scale: 1.15 };
    }
  };

  const getGlowColor = () => {
    return phase === "complete" ? "#48bb78" : "#d4af37";
  };

  useFrame((state) => {
    const time = state.clock.elapsedTime;
    const { scale } = getGlowIntensity();
    const pulseIntensity = phase === "complete" ? 0.1 : 0.05;
    
    if (glowRef1.current) {
      const s1 = scale + Math.sin(time * 2) * pulseIntensity;
      glowRef1.current.scale.setScalar(s1);
    }
    if (glowRef2.current) {
      const s2 = scale + 0.1 + Math.sin(time * 1.5 + 1) * pulseIntensity;
      glowRef2.current.scale.setScalar(s2);
    }
    if (glowRef3.current) {
      const s3 = scale + 0.2 + Math.sin(time * 1 + 2) * pulseIntensity;
      glowRef3.current.scale.setScalar(s3);
    }
  });

  const { opacity } = getGlowIntensity();
  const color = getGlowColor();

  return (
    <group>
      {/* Inner glow layer */}
      <Sphere ref={glowRef1} args={[1, 32, 32]}>
        <meshBasicMaterial
          color={color}
          transparent
          opacity={opacity}
          side={THREE.BackSide}
        />
      </Sphere>
      
      {/* Middle glow layer */}
      <Sphere ref={glowRef2} args={[1, 32, 32]}>
        <meshBasicMaterial
          color={color}
          transparent
          opacity={opacity * 0.6}
          side={THREE.BackSide}
        />
      </Sphere>
      
      {/* Outer glow layer */}
      <Sphere ref={glowRef3} args={[1, 32, 32]}>
        <meshBasicMaterial
          color={color}
          transparent
          opacity={opacity * 0.3}
          side={THREE.BackSide}
        />
      </Sphere>
    </group>
  );
};

const Earth = ({ phase }: { phase: string }) => {
  const meshRef = useRef<THREE.Mesh>(null);
  const glowRef = useRef<THREE.Mesh>(null);

  useFrame((state) => {
    if (meshRef.current) {
      meshRef.current.rotation.y += 0.002;
    }
    if (glowRef.current) {
      const scale = 1.02 + Math.sin(state.clock.elapsedTime * 2) * 0.02;
      glowRef.current.scale.setScalar(scale);
    }
  });

  const getGlobeColor = () => {
    switch (phase) {
      case "scanning":
        return "#1a365d";
      case "locating":
        return "#2c5282";
      case "connecting":
        return "#3182ce";
      case "complete":
        return "#48bb78";
      default:
        return "#1a365d";
    }
  };

  return (
    <group>
      {/* Atmospheric Glow */}
      <AtmosphericGlow phase={phase} />

      {/* Main Globe */}
      <Sphere ref={meshRef} args={[1, 64, 64]}>
        <meshPhongMaterial
          color={getGlobeColor()}
          emissive={getGlobeColor()}
          emissiveIntensity={phase === "complete" ? 0.4 : 0.2}
          transparent
          opacity={0.9}
          wireframe={phase === "scanning"}
        />
      </Sphere>

      {/* Globe Glow */}
      <Sphere ref={glowRef} args={[1.05, 32, 32]}>
        <meshBasicMaterial
          color={phase === "complete" ? "#48bb78" : "#d4af37"}
          transparent
          opacity={phase === "complete" ? 0.4 : 0.15}
          side={THREE.BackSide}
        />
      </Sphere>

      {/* Grid Lines */}
      <Sphere args={[1.01, 32, 32]}>
        <meshBasicMaterial
          color="#d4af37"
          transparent
          opacity={0.3}
          wireframe
        />
      </Sphere>

      {/* Scanning Ring */}
      {phase !== "complete" && (
        <ScanningRing />
      )}

      {/* Radar Sweep during scanning */}
      {phase === "scanning" && (
        <RadarSweep />
      )}

      {/* Location Marker when locating */}
      {(phase === "locating" || phase === "connecting" || phase === "complete") && (
        <LocationMarker phase={phase} />
      )}
    </group>
  );
};

const RadarSweep = () => {
  const sweepRef = useRef<THREE.Mesh>(null);
  const ringRef = useRef<THREE.Mesh>(null);

  const sweepMaterial = useMemo(() => {
    return new THREE.ShaderMaterial({
      uniforms: {
        time: { value: 0 },
        color: { value: new THREE.Color("#d4af37") },
      },
      vertexShader: `
        varying vec2 vUv;
        void main() {
          vUv = uv;
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }
      `,
      fragmentShader: `
        uniform float time;
        uniform vec3 color;
        varying vec2 vUv;
        
        void main() {
          vec2 center = vec2(0.5, 0.5);
          vec2 pos = vUv - center;
          float angle = atan(pos.y, pos.x);
          float normalizedAngle = (angle + 3.14159) / (2.0 * 3.14159);
          
          float sweepAngle = mod(time * 0.5, 1.0);
          float diff = mod(normalizedAngle - sweepAngle + 1.0, 1.0);
          
          float intensity = smoothstep(0.0, 0.15, diff) * (1.0 - smoothstep(0.0, 0.15, diff));
          intensity = pow(intensity, 0.5) * 0.8;
          
          float dist = length(pos) * 2.0;
          intensity *= smoothstep(1.0, 0.3, dist);
          
          gl_FragColor = vec4(color, intensity);
        }
      `,
      transparent: true,
      side: THREE.DoubleSide,
      depthWrite: false,
    });
  }, []);

  useFrame((state) => {
    if (sweepMaterial) {
      sweepMaterial.uniforms.time.value = state.clock.elapsedTime;
    }
    if (ringRef.current) {
      ringRef.current.rotation.z = state.clock.elapsedTime * 0.5;
    }
  });

  return (
    <group rotation={[Math.PI / 2, 0, 0]}>
      <mesh ref={sweepRef} position={[0, 0.02, 0]} material={sweepMaterial}>
        <circleGeometry args={[1.4, 64]} />
      </mesh>
      
      {[0.4, 0.7, 1.0, 1.3].map((radius, i) => (
        <mesh key={i} position={[0, 0.01, 0]} rotation={[0, 0, 0]}>
          <ringGeometry args={[radius - 0.01, radius, 64]} />
          <meshBasicMaterial color="#d4af37" transparent opacity={0.2} side={THREE.DoubleSide} />
        </mesh>
      ))}
      
      <mesh ref={ringRef} position={[0, 0.03, 0]}>
        <planeGeometry args={[1.4, 0.02]} />
        <meshBasicMaterial color="#d4af37" transparent opacity={0.8} side={THREE.DoubleSide} />
      </mesh>
    </group>
  );
};

const ScanningRing = () => {
  const ringRef = useRef<THREE.Mesh>(null);

  useFrame((state) => {
    if (ringRef.current) {
      ringRef.current.rotation.x = Math.sin(state.clock.elapsedTime) * 0.5;
      ringRef.current.rotation.z = state.clock.elapsedTime * 0.5;
    }
  });

  return (
    <mesh ref={ringRef}>
      <torusGeometry args={[1.3, 0.02, 16, 100]} />
      <meshBasicMaterial color="#d4af37" transparent opacity={0.6} />
    </mesh>
  );
};

const LocationMarker = ({ phase }: { phase: string }) => {
  const markerRef = useRef<THREE.Group>(null);
  const pulseRef = useRef<THREE.Mesh>(null);

  useFrame((state) => {
    if (markerRef.current) {
      markerRef.current.rotation.y = state.clock.elapsedTime;
    }
    if (pulseRef.current) {
      const scale = 1 + Math.sin(state.clock.elapsedTime * 4) * 0.3;
      pulseRef.current.scale.setScalar(scale);
    }
  });

  const markerColor = phase === "complete" ? "#48bb78" : "#d4af37";

  return (
    <group ref={markerRef} position={[0, 1.1, 0]}>
      <mesh>
        <coneGeometry args={[0.08, 0.2, 8]} />
        <meshBasicMaterial color={markerColor} />
      </mesh>

      <mesh ref={pulseRef} position={[0, 0.1, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <ringGeometry args={[0.1, 0.15, 32]} />
        <meshBasicMaterial color={markerColor} transparent opacity={0.5} />
      </mesh>
    </group>
  );
};

// Connection Beam from satellite to globe
const ConnectionBeam = ({ 
  startPos, 
  visible 
}: { 
  startPos: THREE.Vector3; 
  visible: boolean;
}) => {
  const beamRef = useRef<THREE.Line>(null);
  const pulseRef = useRef<number>(0);
  const opacityRef = useRef(0.8);

  const beamGeometry = useMemo(() => {
    const curve = new THREE.QuadraticBezierCurve3(
      startPos,
      new THREE.Vector3(startPos.x * 0.5, startPos.y * 0.5 + 0.5, startPos.z * 0.5),
      new THREE.Vector3(0, 0, 0)
    );
    const points = curve.getPoints(20);
    return new THREE.BufferGeometry().setFromPoints(points);
  }, [startPos]);

  const beamMaterial = useMemo(() => {
    return new THREE.LineBasicMaterial({ 
      color: "#00ffff", 
      transparent: true, 
      opacity: 0.8 
    });
  }, []);

  useFrame((state) => {
    pulseRef.current = (Math.sin(state.clock.elapsedTime * 8) + 1) * 0.5;
    opacityRef.current = visible ? 0.3 + pulseRef.current * 0.7 : 0;
    beamMaterial.opacity = opacityRef.current;
  });

  if (!visible) return null;

  return (
    <primitive object={new THREE.Line(beamGeometry, beamMaterial)} />
  );
};

// Satellite with Trail and Connection Beam
const SatelliteWithTrail = ({ 
  orbitSpeed, 
  orbitRadius, 
  initialAngle, 
  yOffset,
  showBeam 
}: {
  orbitSpeed: number;
  orbitRadius: number;
  initialAngle: number;
  yOffset: number;
  showBeam: boolean;
}) => {
  const satRef = useRef<THREE.Group>(null);
  const beamStartRef = useRef(new THREE.Vector3(orbitRadius, 0, 0));

  useFrame((state) => {
    if (satRef.current) {
      const time = state.clock.elapsedTime;
      const x = Math.cos(time * orbitSpeed + initialAngle) * orbitRadius;
      const z = Math.sin(time * orbitSpeed + initialAngle) * orbitRadius;
      const y = Math.sin(time * orbitSpeed * 0.5 + initialAngle) * yOffset;
      
      satRef.current.position.set(x, y, z);
      satRef.current.lookAt(0, 0, 0);
      
      beamStartRef.current.set(x, y, z);
    }
  });

  return (
    <>
      <ConnectionBeam startPos={beamStartRef.current} visible={showBeam} />
      <Trail
        width={0.3}
        length={8}
        color="#d4af37"
        attenuation={(t) => t * t}
      >
        <group ref={satRef}>
          {/* Satellite Body */}
          <mesh>
            <boxGeometry args={[0.1, 0.05, 0.1]} />
            <meshBasicMaterial color="#d4af37" />
          </mesh>
          {/* Solar Panels */}
          <mesh position={[0.12, 0, 0]}>
            <boxGeometry args={[0.1, 0.01, 0.06]} />
            <meshBasicMaterial color="#4a90a4" />
          </mesh>
          <mesh position={[-0.12, 0, 0]}>
            <boxGeometry args={[0.1, 0.01, 0.06]} />
            <meshBasicMaterial color="#4a90a4" />
          </mesh>
          {/* Antenna */}
          <mesh position={[0, 0.04, 0]}>
            <cylinderGeometry args={[0.005, 0.005, 0.08, 8]} />
            <meshBasicMaterial color="#ffffff" />
          </mesh>
          {/* Signal emission effect - intensify during connecting */}
          <pointLight 
            color={showBeam ? "#00ffff" : "#d4af37"} 
            intensity={showBeam ? 1.5 : 0.5} 
            distance={showBeam ? 2 : 1} 
          />
          {/* Pulsing signal sphere during connecting */}
          {showBeam && (
            <Sphere args={[0.15, 16, 16]}>
              <meshBasicMaterial color="#00ffff" transparent opacity={0.3} />
            </Sphere>
          )}
        </group>
      </Trail>
    </>
  );
};

const Satellites = ({ phase }: { phase: string }) => {
  const showBeam = phase === "connecting";
  
  return (
    <>
      <SatelliteWithTrail orbitSpeed={0.5} orbitRadius={2} initialAngle={0} yOffset={0.5} showBeam={showBeam} />
      <SatelliteWithTrail orbitSpeed={0.3} orbitRadius={2.2} initialAngle={2} yOffset={0.8} showBeam={showBeam} />
      <SatelliteWithTrail orbitSpeed={0.4} orbitRadius={1.8} initialAngle={4} yOffset={0.6} showBeam={showBeam} />
    </>
  );
};

// Particle field for atmosphere
const ParticleField = () => {
  const particlesRef = useRef<THREE.Points>(null);
  
  const particlesGeometry = useMemo(() => {
    const geometry = new THREE.BufferGeometry();
    const count = 500;
    const positions = new Float32Array(count * 3);
    
    for (let i = 0; i < count; i++) {
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(2 * Math.random() - 1);
      const radius = 1.1 + Math.random() * 0.3;
      
      positions[i * 3] = radius * Math.sin(phi) * Math.cos(theta);
      positions[i * 3 + 1] = radius * Math.sin(phi) * Math.sin(theta);
      positions[i * 3 + 2] = radius * Math.cos(phi);
    }
    
    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    return geometry;
  }, []);

  useFrame((state) => {
    if (particlesRef.current) {
      particlesRef.current.rotation.y = state.clock.elapsedTime * 0.05;
    }
  });

  return (
    <points ref={particlesRef} geometry={particlesGeometry}>
      <pointsMaterial
        size={0.02}
        color="#d4af37"
        transparent
        opacity={0.6}
        sizeAttenuation
      />
    </points>
  );
};

const Globe3D = ({ phase }: GlobeProps) => {
  return (
    <div className="w-64 h-64 sm:w-80 sm:h-80">
      <Canvas camera={{ position: [0, 0, 3.5], fov: 45 }}>
        <ambientLight intensity={0.3} />
        <pointLight position={[10, 10, 10]} intensity={1} color="#ffffff" />
        <pointLight position={[-10, -10, -10]} intensity={0.5} color="#d4af37" />
        
        {/* Add extra light for complete phase */}
        {phase === "complete" && (
          <pointLight position={[0, 0, 0]} intensity={2} color="#48bb78" distance={5} />
        )}
        
        <Stars
          radius={100}
          depth={50}
          count={2000}
          factor={4}
          saturation={0}
          fade
          speed={1}
        />
        
        <ParticleField />
        <Earth phase={phase} />
        <Satellites phase={phase} />
        
        {/* Celebration particles on complete */}
        <CelebrationParticles active={phase === "complete"} />
        
        <OrbitControls
          enableZoom={false}
          enablePan={false}
          autoRotate
          autoRotateSpeed={0.5}
          minPolarAngle={Math.PI / 3}
          maxPolarAngle={Math.PI / 1.5}
        />
      </Canvas>
    </div>
  );
};

export default Globe3D;

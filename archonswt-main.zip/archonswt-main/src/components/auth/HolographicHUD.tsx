import { useEffect, useState } from "react";
import { Wifi, Database, Shield, Zap, Signal, Lock } from "lucide-react";

interface HolographicHUDProps {
  phase: "scanning" | "locating" | "connecting" | "complete";
  ip?: string;
  location?: string;
}

const HolographicHUD = ({ phase, ip, location }: HolographicHUDProps) => {
  const [dataTransferred, setDataTransferred] = useState(0);
  const [packetsReceived, setPacketsReceived] = useState(0);
  const [signalStrength, setSignalStrength] = useState(0);
  const [encryptionLevel, setEncryptionLevel] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      if (phase === "scanning") {
        setDataTransferred(prev => prev + Math.random() * 50);
        setPacketsReceived(prev => prev + Math.floor(Math.random() * 10));
        setSignalStrength(Math.min(30 + Math.random() * 20, 50));
        setEncryptionLevel(Math.min(encryptionLevel + 5, 25));
      } else if (phase === "locating") {
        setDataTransferred(prev => prev + Math.random() * 100);
        setPacketsReceived(prev => prev + Math.floor(Math.random() * 20));
        setSignalStrength(Math.min(50 + Math.random() * 25, 75));
        setEncryptionLevel(Math.min(encryptionLevel + 10, 50));
      } else if (phase === "connecting") {
        setDataTransferred(prev => prev + Math.random() * 200);
        setPacketsReceived(prev => prev + Math.floor(Math.random() * 30));
        setSignalStrength(Math.min(75 + Math.random() * 20, 95));
        setEncryptionLevel(Math.min(encryptionLevel + 15, 85));
      } else if (phase === "complete") {
        setSignalStrength(100);
        setEncryptionLevel(100);
      }
    }, 100);

    return () => clearInterval(interval);
  }, [phase, encryptionLevel]);

  const getStatusColor = () => {
    switch (phase) {
      case "scanning":
        return "text-gold";
      case "locating":
        return "text-gold-light";
      case "connecting":
        return "text-cyan-400";
      case "complete":
        return "text-success";
      default:
        return "text-gold";
    }
  };

  const getStatusText = () => {
    switch (phase) {
      case "scanning":
        return "SCANNING NETWORK";
      case "locating":
        return "TRIANGULATING POSITION";
      case "connecting":
        return "ESTABLISHING UPLINK";
      case "complete":
        return "CONNECTION SECURED";
      default:
        return "INITIALIZING";
    }
  };

  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden">
      {/* Top Left HUD Panel */}
      <div className="absolute top-4 left-4 sm:top-8 sm:left-8">
        <div className="bg-navy/60 backdrop-blur-sm border border-gold/30 rounded-lg p-3 sm:p-4 space-y-2 animate-fade-in">
          {/* Status Header */}
          <div className="flex items-center gap-2">
            <div className={`w-2 h-2 rounded-full ${phase === "complete" ? "bg-success" : "bg-gold"} animate-pulse`} />
            <span className={`font-mono text-xs sm:text-sm font-bold ${getStatusColor()}`}>
              {getStatusText()}
            </span>
          </div>

          {/* Signal Strength */}
          <div className="flex items-center gap-2">
            <Signal className={`w-3 h-3 sm:w-4 sm:h-4 ${getStatusColor()}`} />
            <div className="flex-1">
              <div className="h-1.5 bg-navy rounded-full overflow-hidden">
                <div 
                  className={`h-full transition-all duration-300 ${phase === "complete" ? "bg-success" : "bg-gold"}`}
                  style={{ width: `${signalStrength}%` }}
                />
              </div>
            </div>
            <span className="font-mono text-[10px] sm:text-xs text-gold/70">{signalStrength.toFixed(0)}%</span>
          </div>

          {/* Encryption Level */}
          <div className="flex items-center gap-2">
            <Lock className={`w-3 h-3 sm:w-4 sm:h-4 ${getStatusColor()}`} />
            <div className="flex-1">
              <div className="h-1.5 bg-navy rounded-full overflow-hidden">
                <div 
                  className={`h-full transition-all duration-300 ${phase === "complete" ? "bg-success" : "bg-cyan-400"}`}
                  style={{ width: `${encryptionLevel}%` }}
                />
              </div>
            </div>
            <span className="font-mono text-[10px] sm:text-xs text-gold/70">{encryptionLevel.toFixed(0)}%</span>
          </div>
        </div>
      </div>

      {/* Top Right HUD Panel */}
      <div className="absolute top-4 right-4 sm:top-8 sm:right-8">
        <div className="bg-navy/60 backdrop-blur-sm border border-gold/30 rounded-lg p-3 sm:p-4 space-y-2 animate-fade-in" style={{ animationDelay: "0.2s" }}>
          {/* Data Transfer */}
          <div className="flex items-center gap-2">
            <Database className="w-3 h-3 sm:w-4 sm:h-4 text-cyan-400" />
            <span className="font-mono text-[10px] sm:text-xs text-gold/70">DATA:</span>
            <span className="font-mono text-[10px] sm:text-xs text-gold">{(dataTransferred / 1024).toFixed(2)} MB</span>
          </div>

          {/* Packets */}
          <div className="flex items-center gap-2">
            <Wifi className="w-3 h-3 sm:w-4 sm:h-4 text-cyan-400" />
            <span className="font-mono text-[10px] sm:text-xs text-gold/70">PACKETS:</span>
            <span className="font-mono text-[10px] sm:text-xs text-gold">{packetsReceived}</span>
          </div>

          {/* Latency */}
          <div className="flex items-center gap-2">
            <Zap className="w-3 h-3 sm:w-4 sm:h-4 text-cyan-400" />
            <span className="font-mono text-[10px] sm:text-xs text-gold/70">LATENCY:</span>
            <span className="font-mono text-[10px] sm:text-xs text-gold">{(15 + Math.random() * 10).toFixed(0)}ms</span>
          </div>
        </div>
      </div>

      {/* Bottom Left - Connection Info */}
      {(phase === "locating" || phase === "connecting" || phase === "complete") && (
        <div className="absolute bottom-20 left-4 sm:bottom-24 sm:left-8">
          <div className="bg-navy/60 backdrop-blur-sm border border-gold/30 rounded-lg p-3 sm:p-4 animate-fade-in" style={{ animationDelay: "0.4s" }}>
            <div className="flex items-center gap-2 mb-2">
              <Shield className={`w-4 h-4 ${phase === "complete" ? "text-success" : "text-gold"}`} />
              <span className="font-mono text-[10px] sm:text-xs text-gold font-bold">SECURE CHANNEL</span>
            </div>
            {ip && (
              <div className="font-mono text-[10px] sm:text-xs text-gold/70">
                NODE: {ip}
              </div>
            )}
            {location && (
              <div className="font-mono text-[10px] sm:text-xs text-gold/70 max-w-[150px] sm:max-w-[200px] truncate">
                LOC: {location}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Corner Decorations */}
      <div className="absolute top-0 left-0 w-16 h-16 sm:w-24 sm:h-24 border-l-2 border-t-2 border-gold/30" />
      <div className="absolute top-0 right-0 w-16 h-16 sm:w-24 sm:h-24 border-r-2 border-t-2 border-gold/30" />
      <div className="absolute bottom-0 left-0 w-16 h-16 sm:w-24 sm:h-24 border-l-2 border-b-2 border-gold/30" />
      <div className="absolute bottom-0 right-0 w-16 h-16 sm:w-24 sm:h-24 border-r-2 border-b-2 border-gold/30" />

      {/* Scan Lines Effect */}
      <div className="absolute inset-0 bg-[linear-gradient(transparent_50%,rgba(212,175,55,0.02)_50%)] bg-[length:100%_4px] pointer-events-none" />
    </div>
  );
};

export default HolographicHUD;

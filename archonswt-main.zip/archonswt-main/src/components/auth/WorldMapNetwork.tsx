import { useEffect, useState, useRef } from "react";

interface ConnectionLine {
  id: number;
  x1: number;
  y1: number;
  x2: number;
  y2: number;
  progress: number;
  speed: number;
  delay: number;
}

interface Node {
  id: number;
  x: number;
  y: number;
  name: string;
  pulse: boolean;
}

// Major cities/satellite ground stations
const nodes: Node[] = [
  { id: 1, x: 20, y: 35, name: "New York", pulse: false },
  { id: 2, x: 10, y: 45, name: "Los Angeles", pulse: false },
  { id: 3, x: 48, y: 30, name: "London", pulse: false },
  { id: 4, x: 52, y: 32, name: "Paris", pulse: false },
  { id: 5, x: 56, y: 28, name: "Berlin", pulse: false },
  { id: 6, x: 75, y: 55, name: "Singapore", pulse: false },
  { id: 7, x: 82, y: 40, name: "Tokyo", pulse: false },
  { id: 8, x: 85, y: 55, name: "Sydney", pulse: false },
  { id: 9, x: 62, y: 45, name: "Dubai", pulse: false },
  { id: 10, x: 70, y: 35, name: "Mumbai", pulse: false },
  { id: 11, x: 78, y: 38, name: "Hong Kong", pulse: false },
  { id: 12, x: 37, y: 75, name: "Sao Paulo", pulse: false },
  { id: 13, x: 58, y: 68, name: "Cape Town", pulse: false },
  { id: 14, x: 64, y: 28, name: "Moscow", pulse: false },
  { id: 15, x: 50, y: 42, name: "Madrid", pulse: false },
];

// Generate connections between nodes
const generateConnections = (): ConnectionLine[] => {
  const connections: ConnectionLine[] = [];
  let id = 0;
  
  // Create network of connections
  const pairs = [
    [0, 2], [0, 1], [2, 3], [3, 4], [2, 14], [4, 14],
    [5, 6], [5, 10], [6, 7], [7, 10], [5, 8],
    [9, 10], [9, 5], [2, 9], [0, 11], [11, 12],
    [12, 9], [14, 9], [3, 14], [1, 5], [0, 6],
    [2, 5], [4, 9], [10, 6], [8, 6], [11, 0],
  ];
  
  pairs.forEach(([from, to], index) => {
    connections.push({
      id: id++,
      x1: nodes[from].x,
      y1: nodes[from].y,
      x2: nodes[to].x,
      y2: nodes[to].y,
      progress: 0,
      speed: 0.5 + Math.random() * 0.5,
      delay: index * 200,
    });
  });
  
  return connections;
};

const WorldMapNetwork = () => {
  const [connections, setConnections] = useState<ConnectionLine[]>([]);
  const [activeNodes, setActiveNodes] = useState<Set<number>>(new Set());
  const animationRef = useRef<number>();
  const startTimeRef = useRef<number>(0);

  useEffect(() => {
    setConnections(generateConnections());
  }, []);

  useEffect(() => {
    const animate = (timestamp: number) => {
      if (!startTimeRef.current) {
        startTimeRef.current = timestamp;
      }
      const elapsed = timestamp - startTimeRef.current;

      setConnections(prev => 
        prev.map(conn => {
          if (elapsed < conn.delay) return conn;
          
          const newProgress = ((elapsed - conn.delay) * conn.speed * 0.001) % 2;
          return { ...conn, progress: newProgress };
        })
      );

      // Update active nodes based on connection progress
      const newActiveNodes = new Set<number>();
      connections.forEach(conn => {
        if (conn.progress > 0 && conn.progress < 2) {
          nodes.forEach((node, index) => {
            if (
              (Math.abs(node.x - conn.x1) < 1 && Math.abs(node.y - conn.y1) < 1) ||
              (Math.abs(node.x - conn.x2) < 1 && Math.abs(node.y - conn.y2) < 1)
            ) {
              newActiveNodes.add(index);
            }
          });
        }
      });
      setActiveNodes(newActiveNodes);

      animationRef.current = requestAnimationFrame(animate);
    };

    animationRef.current = requestAnimationFrame(animate);

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [connections.length]);

  // Calculate the path for curved connections
  const getCurvedPath = (x1: number, y1: number, x2: number, y2: number) => {
    const midX = (x1 + x2) / 2;
    const midY = (y1 + y2) / 2;
    const dx = x2 - x1;
    const dy = y2 - y1;
    const dist = Math.sqrt(dx * dx + dy * dy);
    
    // Curve the line upward (for globe effect)
    const curveHeight = dist * 0.15;
    const controlX = midX;
    const controlY = midY - curveHeight;
    
    return `M ${x1} ${y1} Q ${controlX} ${controlY} ${x2} ${y2}`;
  };

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      <svg
        viewBox="0 0 100 100"
        className="w-full h-full opacity-40"
        preserveAspectRatio="xMidYMid slice"
      >
        <defs>
          {/* Gradient for connection lines */}
          <linearGradient id="lineGradient" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#d4af37" stopOpacity="0" />
            <stop offset="50%" stopColor="#00ffff" stopOpacity="1" />
            <stop offset="100%" stopColor="#d4af37" stopOpacity="0" />
          </linearGradient>
          
          {/* Glow filter */}
          <filter id="glow" x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur stdDeviation="0.3" result="coloredBlur" />
            <feMerge>
              <feMergeNode in="coloredBlur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>

          {/* Animated dash pattern */}
          <pattern id="movingDash" width="4" height="1" patternUnits="userSpaceOnUse">
            <rect width="2" height="1" fill="#d4af37" opacity="0.5" />
          </pattern>
        </defs>

        {/* World map outline (simplified continents) */}
        <g className="opacity-30" stroke="#d4af37" strokeWidth="0.15" fill="none">
          {/* North America */}
          <path d="M5,25 Q15,20 25,25 L28,35 Q22,45 15,48 L8,42 Q3,35 5,25" />
          
          {/* South America */}
          <path d="M25,52 Q32,55 35,65 L33,80 Q28,85 25,78 L22,65 Q20,55 25,52" />
          
          {/* Europe */}
          <path d="M45,22 Q52,18 58,22 L60,32 Q55,38 48,35 L45,28 Z" />
          
          {/* Africa */}
          <path d="M48,42 Q55,40 60,45 L62,65 Q58,75 52,72 L48,58 Q45,48 48,42" />
          
          {/* Asia */}
          <path d="M60,18 Q75,15 88,25 L90,40 Q85,48 75,45 L65,35 Q58,25 60,18" />
          
          {/* Australia */}
          <path d="M78,55 Q88,52 92,58 L90,68 Q85,72 80,68 L78,60 Z" />
        </g>

        {/* Static connection lines (base layer) */}
        {connections.map(conn => (
          <path
            key={`base-${conn.id}`}
            d={getCurvedPath(conn.x1, conn.y1, conn.x2, conn.y2)}
            fill="none"
            stroke="#d4af37"
            strokeWidth="0.1"
            opacity="0.2"
          />
        ))}

        {/* Animated connection lines */}
        {connections.map(conn => {
          const pathLength = 100;
          const dashOffset = pathLength - (conn.progress * pathLength);
          
          return (
            <path
              key={`anim-${conn.id}`}
              d={getCurvedPath(conn.x1, conn.y1, conn.x2, conn.y2)}
              fill="none"
              stroke="#00ffff"
              strokeWidth="0.2"
              strokeDasharray={`3 ${pathLength}`}
              strokeDashoffset={dashOffset}
              filter="url(#glow)"
              opacity={conn.progress > 0 ? 0.8 : 0}
              className="transition-opacity duration-300"
            />
          );
        })}

        {/* Data packet dots traveling along connections */}
        {connections.map(conn => {
          if (conn.progress <= 0 || conn.progress >= 1) return null;
          
          const t = conn.progress;
          const x1 = conn.x1;
          const y1 = conn.y1;
          const x2 = conn.x2;
          const y2 = conn.y2;
          
          // Quadratic bezier point calculation
          const midX = (x1 + x2) / 2;
          const midY = (y1 + y2) / 2 - Math.sqrt((x2-x1)**2 + (y2-y1)**2) * 0.15;
          
          const x = (1-t)**2 * x1 + 2*(1-t)*t * midX + t**2 * x2;
          const y = (1-t)**2 * y1 + 2*(1-t)*t * midY + t**2 * y2;
          
          return (
            <circle
              key={`packet-${conn.id}`}
              cx={x}
              cy={y}
              r="0.5"
              fill="#00ffff"
              filter="url(#glow)"
            >
              <animate
                attributeName="r"
                values="0.3;0.6;0.3"
                dur="0.5s"
                repeatCount="indefinite"
              />
            </circle>
          );
        })}

        {/* Network nodes */}
        {nodes.map((node, index) => (
          <g key={node.id}>
            {/* Outer pulse ring */}
            <circle
              cx={node.x}
              cy={node.y}
              r="1.5"
              fill="none"
              stroke={activeNodes.has(index) ? "#00ffff" : "#d4af37"}
              strokeWidth="0.1"
              opacity={activeNodes.has(index) ? 0.8 : 0.3}
            >
              <animate
                attributeName="r"
                values="0.8;1.5;0.8"
                dur="2s"
                repeatCount="indefinite"
              />
              <animate
                attributeName="opacity"
                values="0.8;0.2;0.8"
                dur="2s"
                repeatCount="indefinite"
              />
            </circle>
            
            {/* Inner node */}
            <circle
              cx={node.x}
              cy={node.y}
              r="0.4"
              fill={activeNodes.has(index) ? "#00ffff" : "#d4af37"}
              filter="url(#glow)"
            />
          </g>
        ))}

        {/* Satellite icons orbiting */}
        <g className="origin-center">
          <animateTransform
            attributeName="transform"
            type="rotate"
            from="0 50 50"
            to="360 50 50"
            dur="60s"
            repeatCount="indefinite"
          />
          <circle cx="50" cy="8" r="0.6" fill="#d4af37">
            <animate
              attributeName="opacity"
              values="1;0.5;1"
              dur="2s"
              repeatCount="indefinite"
            />
          </circle>
        </g>
        
        <g className="origin-center">
          <animateTransform
            attributeName="transform"
            type="rotate"
            from="120 50 50"
            to="480 50 50"
            dur="45s"
            repeatCount="indefinite"
          />
          <circle cx="50" cy="12" r="0.5" fill="#d4af37">
            <animate
              attributeName="opacity"
              values="0.5;1;0.5"
              dur="1.5s"
              repeatCount="indefinite"
            />
          </circle>
        </g>

        <g className="origin-center">
          <animateTransform
            attributeName="transform"
            type="rotate"
            from="240 50 50"
            to="600 50 50"
            dur="55s"
            repeatCount="indefinite"
          />
          <circle cx="50" cy="10" r="0.4" fill="#d4af37">
            <animate
              attributeName="opacity"
              values="0.7;1;0.7"
              dur="1.8s"
              repeatCount="indefinite"
            />
          </circle>
        </g>
      </svg>
    </div>
  );
};

export default WorldMapNetwork;

import { useState, useEffect } from 'react';

interface EncryptionVisualizerProps {
  phase: 'scanning' | 'locating' | 'connecting' | 'complete';
}

const EncryptionVisualizer = ({ phase }: EncryptionVisualizerProps) => {
  const [cipherLines, setCipherLines] = useState<string[]>([]);
  const [encryptionProgress, setEncryptionProgress] = useState(0);

  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*(){}[]|;:,.<>?';
  
  const generateCipherLine = () => {
    const length = Math.floor(Math.random() * 20) + 30;
    let line = '';
    for (let i = 0; i < length; i++) {
      line += characters[Math.floor(Math.random() * characters.length)];
    }
    return line;
  };

  useEffect(() => {
    if (phase === 'scanning' || phase === 'locating') return;

    const lineInterval = setInterval(() => {
      setCipherLines(prev => {
        const newLines = [...prev, generateCipherLine()];
        if (newLines.length > 8) newLines.shift();
        return newLines;
      });
    }, 150);

    const progressInterval = setInterval(() => {
      setEncryptionProgress(prev => {
        if (phase === 'complete') return 100;
        return Math.min(prev + 2, 95);
      });
    }, 100);

    return () => {
      clearInterval(lineInterval);
      clearInterval(progressInterval);
    };
  }, [phase]);

  useEffect(() => {
    if (phase === 'complete') {
      setEncryptionProgress(100);
    }
  }, [phase]);

  if (phase === 'scanning' || phase === 'locating') return null;

  return (
    <div className="absolute bottom-4 right-4 w-72 bg-black/80 border border-cyan-500/30 rounded-lg p-3 backdrop-blur-sm">
      {/* Header */}
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2">
          <div className={`w-2 h-2 rounded-full ${phase === 'complete' ? 'bg-green-500' : 'bg-cyan-500 animate-pulse'}`} />
          <span className="text-cyan-400 text-xs font-mono uppercase tracking-wider">
            {phase === 'complete' ? 'Encrypted' : 'Encrypting'}
          </span>
        </div>
        <span className="text-cyan-300 text-xs font-mono">{encryptionProgress}%</span>
      </div>

      {/* Progress bar */}
      <div className="w-full h-1 bg-gray-800 rounded-full mb-2 overflow-hidden">
        <div 
          className={`h-full transition-all duration-300 ${phase === 'complete' ? 'bg-green-500' : 'bg-cyan-500'}`}
          style={{ width: `${encryptionProgress}%` }}
        />
      </div>

      {/* Cipher text display */}
      <div className="h-24 overflow-hidden font-mono text-[10px] leading-tight">
        {cipherLines.map((line, index) => (
          <div 
            key={index}
            className={`transition-all duration-300 ${
              phase === 'complete' 
                ? 'text-green-500/70' 
                : index === cipherLines.length - 1 
                  ? 'text-cyan-300' 
                  : 'text-cyan-500/50'
            }`}
            style={{
              opacity: (index + 1) / cipherLines.length,
            }}
          >
            {line}
          </div>
        ))}
      </div>

      {/* Encryption details */}
      <div className="mt-2 pt-2 border-t border-cyan-500/20">
        <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-[9px] font-mono">
          <div className="text-cyan-500/60">CIPHER:</div>
          <div className="text-cyan-300">AES-256-GCM</div>
          <div className="text-cyan-500/60">KEY SIZE:</div>
          <div className="text-cyan-300">256-bit</div>
          <div className="text-cyan-500/60">PROTOCOL:</div>
          <div className="text-cyan-300">TLS 1.3</div>
        </div>
      </div>

      {/* Lock icon */}
      <div className="absolute -top-3 -right-3">
        <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
          phase === 'complete' ? 'bg-green-500/20 border-green-500/50' : 'bg-cyan-500/20 border-cyan-500/50'
        } border`}>
          <svg 
            className={`w-4 h-4 ${phase === 'complete' ? 'text-green-400' : 'text-cyan-400'}`}
            fill="none" 
            stroke="currentColor" 
            viewBox="0 0 24 24"
          >
            <path 
              strokeLinecap="round" 
              strokeLinejoin="round" 
              strokeWidth={2} 
              d={phase === 'complete' 
                ? "M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"
                : "M8 11V7a4 4 0 118 0m-4 8v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2z"
              }
            />
          </svg>
        </div>
      </div>
    </div>
  );
};

export default EncryptionVisualizer;

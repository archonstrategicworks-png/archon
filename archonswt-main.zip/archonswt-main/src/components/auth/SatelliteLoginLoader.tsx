import { useEffect, useState, Suspense } from "react";
import { Globe, MapPin, Shield, Loader2 } from "lucide-react";
import Globe3D from "./Globe3D";
import HolographicHUD from "./HolographicHUD";
import TerminalLogs from "./TerminalLogs";
import WorldMapNetwork from "./WorldMapNetwork";
import LocationMiniMap from "./LocationMiniMap";
import BiometricScan from "./BiometricScan";
import IrisScan from "./IrisScan";
import EncryptionVisualizer from "./EncryptionVisualizer";
import { useConnectionSound } from "@/hooks/useConnectionSound";
import logoImage from "@/assets/logo.jpg";

interface GeoData {
  ip: string;
  city?: string;
  region?: string;
  country?: string;
  latitude?: number;
  longitude?: number;
}

interface SatelliteLoginLoaderProps {
  onComplete?: () => void;
}

const Globe3DFallback = () => (
  <div className="w-64 h-64 sm:w-80 sm:h-80 flex items-center justify-center">
    <Globe className="w-20 h-20 sm:w-24 sm:h-24 text-gold animate-pulse" />
  </div>
);

const SatelliteLoginLoader = ({ onComplete }: SatelliteLoginLoaderProps) => {
  const [geoData, setGeoData] = useState<GeoData | null>(null);
  const [phase, setPhase] = useState<"scanning" | "locating" | "connecting" | "complete">("scanning");
  const [progress, setProgress] = useState(0);
  const [soundPlayed, setSoundPlayed] = useState(false);
  const { playConnectionSound } = useConnectionSound();

  useEffect(() => {
    const fetchGeoData = async () => {
      try {
        const response = await fetch("https://ipapi.co/json/");
        const data = await response.json();
        setGeoData({
          ip: data.ip,
          city: data.city,
          region: data.region,
          country: data.country_name,
          latitude: data.latitude,
          longitude: data.longitude,
        });
      } catch (error) {
        console.error("Failed to fetch geo data:", error);
        setGeoData({ ip: "Unknown" });
      }
    };

    fetchGeoData();
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          return 100;
        }
        return prev + 2;
      });
    }, 50);

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (progress < 30) {
      setPhase("scanning");
    } else if (progress < 60) {
      setPhase("locating");
    } else if (progress < 90) {
      setPhase("connecting");
    } else {
      setPhase("complete");
      
      // Play sound effect when connection completes
      if (!soundPlayed && progress >= 90) {
        playConnectionSound();
        setSoundPlayed(true);
      }
      
      if (progress === 100 && onComplete) {
        setTimeout(onComplete, 500);
      }
    }
  }, [progress, onComplete, soundPlayed, playConnectionSound]);

  const locationString = geoData?.city 
    ? [geoData.city, geoData.region, geoData.country].filter(Boolean).join(", ")
    : undefined;

  return (
    <div className="fixed inset-0 z-50 bg-navy-dark flex flex-col items-center justify-center overflow-hidden">
      {/* Holographic HUD Overlay */}
      <HolographicHUD 
        phase={phase} 
        ip={geoData?.ip}
        location={locationString}
      />

      {/* Terminal Logs */}
      <TerminalLogs phase={phase} />

      {/* Location Mini-Map */}
      <LocationMiniMap 
        latitude={geoData?.latitude}
        longitude={geoData?.longitude}
        city={geoData?.city}
        phase={phase}
      />

      {/* Dual-Factor Biometric Scans */}
      <BiometricScan phase={phase} />
      <IrisScan phase={phase} />

      {/* Encryption Visualizer */}
      <EncryptionVisualizer phase={phase} />

      {/* World Map Network Background */}
      <WorldMapNetwork />

      {/* Logo Watermark Background */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <img 
          src={logoImage} 
          alt="Logo Watermark" 
          className="w-[60vw] h-[60vw] max-w-[600px] max-h-[600px] object-contain opacity-[0.06]"
        />
      </div>

      {/* Animated Background Grid */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute inset-0 bg-[linear-gradient(rgba(212,175,55,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(212,175,55,0.03)_1px,transparent_1px)] bg-[size:50px_50px] animate-pulse" />
        
        {/* Scanning Lines */}
        <div 
          className="absolute inset-0 bg-gradient-to-b from-transparent via-gold/10 to-transparent"
          style={{
            transform: `translateY(${(progress % 100) - 50}%)`,
            transition: "transform 0.1s linear",
          }}
        />
      </div>

      {/* 3D Globe */}
      <div className="relative mb-8">
        <Suspense fallback={<Globe3DFallback />}>
          <Globe3D 
            phase={phase}
            targetLat={geoData?.latitude}
            targetLng={geoData?.longitude}
          />
        </Suspense>

        {/* Ping Effect for complete phase */}
        {phase === "complete" && (
          <>
            <div className="absolute inset-0 border-2 border-success/50 rounded-full animate-ping" />
            <div className="absolute inset-0 border border-success/30 rounded-full animate-ping" style={{ animationDelay: "0.5s" }} />
          </>
        )}
      </div>

      {/* Status Text */}
      <div className="text-center space-y-4 px-4 relative z-10">
        <h2 className="text-xl sm:text-2xl font-display font-bold text-gold flex items-center justify-center gap-2">
          {phase === "scanning" && (
            <>
              <Loader2 className="w-5 h-5 animate-spin" />
              Scanning Network...
            </>
          )}
          {phase === "locating" && (
            <>
              <MapPin className="w-5 h-5 animate-bounce" />
              Locating Your Position...
            </>
          )}
          {phase === "connecting" && (
            <>
              <div className="w-5 h-5 relative">
                <div className="absolute inset-0 rounded-full bg-gold animate-ping" />
                <div className="absolute inset-1 rounded-full bg-gold" />
              </div>
              Establishing Secure Connection...
            </>
          )}
          {phase === "complete" && (
            <>
              <Shield className="w-5 h-5 text-success" />
              Connection Secured
            </>
          )}
        </h2>

        {/* Location Display */}
        {geoData && phase !== "scanning" && (
          <div className="bg-navy/50 backdrop-blur-sm border border-gold/30 rounded-lg p-4 sm:p-6 max-w-md mx-auto animate-fade-in">
            <p className="text-primary-foreground/80 text-sm sm:text-base mb-2">
              You are logging in from:
            </p>
            <div className="space-y-2">
              <p className="text-gold font-mono text-sm sm:text-base flex items-center gap-2">
                <Globe className="w-4 h-4" />
                IP: {geoData.ip}
              </p>
              {geoData.city && (
                <p className="text-gold font-mono text-sm sm:text-base flex items-center gap-2">
                  <MapPin className="w-4 h-4" />
                  {[geoData.city, geoData.region, geoData.country].filter(Boolean).join(", ")}
                </p>
              )}
              {geoData.latitude && geoData.longitude && (
                <p className="text-gold/70 font-mono text-xs">
                  Coordinates: {geoData.latitude.toFixed(4)}°, {geoData.longitude.toFixed(4)}°
                </p>
              )}
            </div>
          </div>
        )}

        {/* Progress Bar */}
        <div className="w-64 sm:w-80 mx-auto">
          <div className="h-1 bg-navy rounded-full overflow-hidden">
            <div 
              className="h-full bg-gradient-to-r from-gold to-gold-light transition-all duration-100"
              style={{ width: `${progress}%` }}
            />
          </div>
          <p className="text-gold/60 text-xs mt-2 font-mono">{progress}% Complete</p>
        </div>
      </div>

      {/* Attribution */}
      <div className="absolute bottom-4 text-center text-xs text-primary-foreground/50">
        <p>
          Concept, Design & Direction by{" "}
          <a 
            href="https://www.linkedin.com/in/kaziafnanibnealam/" 
            target="_blank" 
            rel="noopener noreferrer"
            className="text-gold hover:text-gold-light transition-colors underline-offset-2 hover:underline"
          >
            Kazi Afnan
          </a>
        </p>
      </div>
    </div>
  );
};

export default SatelliteLoginLoader;

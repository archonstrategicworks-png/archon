import { useEffect, useState } from "react";
import { Eye, ShieldCheck, Scan } from "lucide-react";

interface IrisScanProps {
  phase: "scanning" | "locating" | "connecting" | "complete";
}

const IrisScan = ({ phase }: IrisScanProps) => {
  const [scanProgress, setScanProgress] = useState(0);
  const [irisRotation, setIrisRotation] = useState(0);
  const [pulseScale, setPulseScale] = useState(1);

  // Only show during connecting and complete phases
  const isActive = phase === "connecting" || phase === "complete";

  useEffect(() => {
    if (phase === "connecting") {
      setScanProgress(0);
      // Start slightly after fingerprint scan
      const timeout = setTimeout(() => {
        const interval = setInterval(() => {
          setScanProgress(prev => {
            if (prev >= 100) {
              clearInterval(interval);
              return 100;
            }
            return prev + 1.5;
          });
        }, 40);
        return () => clearInterval(interval);
      }, 500);
      return () => clearTimeout(timeout);
    } else if (phase === "complete") {
      setScanProgress(100);
    }
  }, [phase]);

  // Iris rotation animation
  useEffect(() => {
    if (phase === "connecting") {
      const interval = setInterval(() => {
        setIrisRotation(prev => (prev + 2) % 360);
      }, 30);
      return () => clearInterval(interval);
    }
  }, [phase]);

  // Pulse animation
  useEffect(() => {
    if (phase === "connecting") {
      const interval = setInterval(() => {
        setPulseScale(prev => prev === 1 ? 1.05 : 1);
      }, 500);
      return () => clearInterval(interval);
    }
  }, [phase]);

  if (!isActive) return null;

  return (
    <div className="absolute top-1/2 right-[130px] sm:right-[160px] -translate-y-1/2">
      <div className="relative w-[100px] h-[130px] sm:w-[120px] sm:h-[150px]">
        {/* Background Panel */}
        <div className="absolute inset-0 bg-navy/80 backdrop-blur-sm border border-gold/40 rounded-lg overflow-hidden">
          {/* Header */}
          <div className="absolute top-0 left-0 right-0 bg-navy/90 border-b border-gold/30 px-2 py-1 flex items-center justify-between">
            <span className="text-[8px] sm:text-[10px] font-mono text-gold">
              RETINAL SCAN
            </span>
            <Eye className="w-3 h-3 text-gold" />
          </div>

          {/* Iris Container */}
          <div className="absolute inset-0 mt-6 mb-6 flex items-center justify-center">
            <div className="relative w-16 h-16 sm:w-20 sm:h-20">
              {/* Outer eye shape */}
              <svg 
                viewBox="0 0 100 100" 
                className="absolute inset-0 w-full h-full"
                style={{ transform: `scale(${pulseScale})`, transition: "transform 0.3s ease" }}
              >
                <defs>
                  {/* Iris gradient */}
                  <radialGradient id="irisGradient" cx="50%" cy="50%" r="50%">
                    <stop offset="0%" stopColor="#000000" />
                    <stop offset="30%" stopColor={phase === "complete" ? "#48bb78" : "#00ffff"} />
                    <stop offset="60%" stopColor={phase === "complete" ? "#276749" : "#0891b2"} />
                    <stop offset="100%" stopColor="#1a365d" />
                  </radialGradient>

                  {/* Scan line gradient */}
                  <linearGradient id="scanLineGradient" x1="0%" y1="0%" x2="0%" y2="100%">
                    <stop offset="0%" stopColor="transparent" />
                    <stop offset="50%" stopColor={phase === "complete" ? "#48bb78" : "#00ffff"} />
                    <stop offset="100%" stopColor="transparent" />
                  </linearGradient>

                  {/* Glow filter */}
                  <filter id="irisGlow" x="-50%" y="-50%" width="200%" height="200%">
                    <feGaussianBlur stdDeviation="2" result="coloredBlur" />
                    <feMerge>
                      <feMergeNode in="coloredBlur" />
                      <feMergeNode in="SourceGraphic" />
                    </feMerge>
                  </filter>
                </defs>

                {/* Eye white (sclera) */}
                <ellipse 
                  cx="50" 
                  cy="50" 
                  rx="45" 
                  ry="30" 
                  fill="#1a2744"
                  stroke={phase === "complete" ? "#48bb78" : "#00ffff"}
                  strokeWidth="1"
                  opacity="0.8"
                />

                {/* Iris */}
                <circle 
                  cx="50" 
                  cy="50" 
                  r="22" 
                  fill="url(#irisGradient)"
                  stroke={phase === "complete" ? "#48bb78" : "#00ffff"}
                  strokeWidth="1"
                  filter="url(#irisGlow)"
                />

                {/* Iris pattern (rotating lines) */}
                <g transform={`rotate(${irisRotation} 50 50)`}>
                  {[...Array(12)].map((_, i) => (
                    <line
                      key={i}
                      x1="50"
                      y1="30"
                      x2="50"
                      y2="38"
                      stroke={phase === "complete" ? "#48bb78" : "#00ffff"}
                      strokeWidth="0.5"
                      opacity="0.6"
                      transform={`rotate(${i * 30} 50 50)`}
                    />
                  ))}
                </g>

                {/* Pupil */}
                <circle 
                  cx="50" 
                  cy="50" 
                  r="8" 
                  fill="#000000"
                />

                {/* Light reflection */}
                <circle 
                  cx="44" 
                  cy="44" 
                  r="3" 
                  fill="white"
                  opacity="0.6"
                />
                <circle 
                  cx="56" 
                  cy="54" 
                  r="1.5" 
                  fill="white"
                  opacity="0.3"
                />

                {/* Scanning line */}
                {phase === "connecting" && (
                  <line
                    x1="5"
                    y1={20 + (scanProgress * 0.6)}
                    x2="95"
                    y2={20 + (scanProgress * 0.6)}
                    stroke="url(#scanLineGradient)"
                    strokeWidth="2"
                    opacity="0.8"
                  />
                )}

                {/* Scan grid overlay */}
                {phase === "connecting" && (
                  <g opacity="0.3">
                    {[...Array(5)].map((_, i) => (
                      <line
                        key={`h-${i}`}
                        x1="10"
                        y1={25 + i * 12}
                        x2="90"
                        y2={25 + i * 12}
                        stroke="#00ffff"
                        strokeWidth="0.3"
                        strokeDasharray="2,2"
                      />
                    ))}
                    {[...Array(5)].map((_, i) => (
                      <line
                        key={`v-${i}`}
                        x1={20 + i * 15}
                        y1="20"
                        x2={20 + i * 15}
                        y2="80"
                        stroke="#00ffff"
                        strokeWidth="0.3"
                        strokeDasharray="2,2"
                      />
                    ))}
                  </g>
                )}

                {/* Corner targeting brackets */}
                <path d="M 10 25 L 10 20 L 20 20" fill="none" stroke={phase === "complete" ? "#48bb78" : "#00ffff"} strokeWidth="1.5" />
                <path d="M 80 20 L 90 20 L 90 25" fill="none" stroke={phase === "complete" ? "#48bb78" : "#00ffff"} strokeWidth="1.5" />
                <path d="M 90 75 L 90 80 L 80 80" fill="none" stroke={phase === "complete" ? "#48bb78" : "#00ffff"} strokeWidth="1.5" />
                <path d="M 20 80 L 10 80 L 10 75" fill="none" stroke={phase === "complete" ? "#48bb78" : "#00ffff"} strokeWidth="1.5" />
              </svg>

              {/* Success overlay */}
              {phase === "complete" && (
                <div className="absolute inset-0 flex items-center justify-center animate-fade-in">
                  <div className="absolute inset-0 bg-success/20 rounded-full animate-ping" />
                </div>
              )}
            </div>
          </div>

          {/* Progress Bar */}
          <div className="absolute bottom-0 left-0 right-0 bg-navy/90 border-t border-gold/30 p-2">
            <div className="h-1 bg-navy rounded-full overflow-hidden mb-1">
              <div 
                className={`h-full transition-all duration-100 ${
                  phase === "complete" 
                    ? "bg-success" 
                    : "bg-gradient-to-r from-cyan-400 to-cyan-300"
                }`}
                style={{ width: `${scanProgress}%` }}
              />
            </div>
            <div className="text-center">
              <span className={`text-[8px] sm:text-[9px] font-mono ${
                phase === "complete" ? "text-success" : "text-cyan-400"
              }`}>
                {phase === "complete" ? "MATCHED" : `ANALYZING ${scanProgress.toFixed(0)}%`}
              </span>
            </div>
          </div>

          {/* Scanning indicator */}
          {phase === "connecting" && (
            <div className="absolute top-7 right-2 flex gap-0.5">
              <Scan className="w-3 h-3 text-cyan-400 animate-pulse" />
            </div>
          )}

          {/* Success indicator */}
          {phase === "complete" && (
            <div className="absolute top-7 right-2">
              <ShieldCheck className="w-3 h-3 text-success" />
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default IrisScan;

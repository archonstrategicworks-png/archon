import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useCurrency } from "@/hooks/useCurrency";
import { useLanguage } from "@/contexts/LanguageContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
} from "recharts";
import { TrendingUp, TrendingDown, Minus } from "lucide-react";
import { format, subMonths, startOfMonth, endOfMonth } from "date-fns";

interface MonthlyData {
  month: string;
  amount: number;
  label: string;
}

const MonthlyTrendChart = () => {
  const [data, setData] = useState<MonthlyData[]>([]);
  const [loading, setLoading] = useState(true);
  const [trend, setTrend] = useState<"up" | "down" | "stable">("stable");
  const [trendPercent, setTrendPercent] = useState(0);
  const { format: formatCurrency, currency } = useCurrency();
  const { t } = useLanguage();

  useEffect(() => {
    const fetchMonthlyData = async () => {
      try {
        const now = new Date();
        const months: MonthlyData[] = [];

        // Get last 6 months
        for (let i = 5; i >= 0; i--) {
          const monthStart = startOfMonth(subMonths(now, i));
          const monthEnd = endOfMonth(subMonths(now, i));

          const { data: expenses } = await supabase
            .from("expenses")
            .select("amount, date")
            .gte("date", format(monthStart, "yyyy-MM-dd"))
            .lte("date", format(monthEnd, "yyyy-MM-dd"));

          const total = (expenses || []).reduce((sum, e) => sum + Number(e.amount), 0);

          months.push({
            month: format(monthStart, "yyyy-MM"),
            label: format(monthStart, "MMM"),
            amount: total,
          });
        }

        setData(months);

        // Calculate trend
        if (months.length >= 2) {
          const lastMonth = months[months.length - 1].amount;
          const prevMonth = months[months.length - 2].amount;
          
          if (prevMonth > 0) {
            const change = ((lastMonth - prevMonth) / prevMonth) * 100;
            setTrendPercent(Math.abs(change));
            
            if (change > 5) setTrend("up");
            else if (change < -5) setTrend("down");
            else setTrend("stable");
          }
        }
      } catch (error) {
        console.error("Error fetching monthly data:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchMonthlyData();
  }, []);

  const getTrendIcon = () => {
    switch (trend) {
      case "up":
        return <TrendingUp className="w-5 h-5 text-destructive" />;
      case "down":
        return <TrendingDown className="w-5 h-5 text-success" />;
      default:
        return <Minus className="w-5 h-5 text-muted-foreground" />;
    }
  };

  const getTrendText = () => {
    switch (trend) {
      case "up":
        return `+${trendPercent.toFixed(1)}% from last month`;
      case "down":
        return `-${trendPercent.toFixed(1)}% from last month`;
      default:
        return "Stable compared to last month";
    }
  };

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>{t("analytics.monthlyTrend")}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-64 flex items-center justify-center">
            <div className="animate-pulse bg-muted h-full w-full rounded" />
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>{t("analytics.monthlyTrend")}</CardTitle>
          <div className="flex items-center gap-2 text-sm">
            {getTrendIcon()}
            <span className="text-muted-foreground">{getTrendText()}</span>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {data.every(d => d.amount === 0) ? (
          <div className="h-64 flex items-center justify-center text-muted-foreground">
            No expense data for the past 6 months
          </div>
        ) : (
          <ResponsiveContainer width="100%" height={280}>
            <LineChart data={data} margin={{ top: 5, right: 20, bottom: 5, left: 0 }}>
              <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
              <XAxis 
                dataKey="label" 
                className="text-xs"
                tick={{ fill: 'hsl(var(--muted-foreground))' }}
              />
              <YAxis 
                tickFormatter={(value) => {
                  if (value >= 1000000) return `${(value / 1000000).toFixed(1)}M`;
                  if (value >= 1000) return `${(value / 1000).toFixed(0)}K`;
                  return value.toString();
                }}
                className="text-xs"
                tick={{ fill: 'hsl(var(--muted-foreground))' }}
              />
              <Tooltip
                formatter={(value: number) => [formatCurrency(value), "Amount"]}
                labelFormatter={(label) => `Month: ${label}`}
                contentStyle={{
                  backgroundColor: 'hsl(var(--card))',
                  border: '1px solid hsl(var(--border))',
                  borderRadius: '8px',
                }}
              />
              <Line
                type="monotone"
                dataKey="amount"
                stroke="hsl(var(--primary))"
                strokeWidth={3}
                dot={{ fill: 'hsl(var(--primary))', strokeWidth: 2 }}
                activeDot={{ r: 6, fill: 'hsl(var(--primary))' }}
              />
            </LineChart>
          </ResponsiveContainer>
        )}
      </CardContent>
    </Card>
  );
};

export default MonthlyTrendChart;

import { useState, useEffect, useMemo } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useCurrency } from "@/hooks/useCurrency";
import { useLanguage } from "@/contexts/LanguageContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  Area,
  AreaChart,
} from "recharts";
import {
  TrendingUp,
  TrendingDown,
  Target,
  AlertTriangle,
  Calendar,
} from "lucide-react";
import { format, subMonths, startOfMonth, endOfMonth, parseISO } from "date-fns";

interface Expense {
  id: string;
  date: string;
  amount: number;
  category: string;
  project_id: string;
}

interface Project {
  id: string;
  project_name: string;
  budget: number | null;
}

const COLORS = [
  "#0ea5e9", "#10b981", "#f59e0b", "#ef4444", "#8b5cf6",
  "#ec4899", "#06b6d4", "#84cc16", "#f97316", "#6366f1",
];

const AdvancedAnalytics = () => {
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedProject, setSelectedProject] = useState<string>("all");
  const [timeRange, setTimeRange] = useState<string>("6");
  const { format: formatCurrency } = useCurrency();
  const { t } = useLanguage();

  useEffect(() => {
    const fetchData = async () => {
      try {
        const monthsAgo = parseInt(timeRange);
        const startDate = subMonths(new Date(), monthsAgo).toISOString();

        const [expensesRes, projectsRes] = await Promise.all([
          supabase
            .from("expenses")
            .select("id, date, amount, category, project_id")
            .gte("date", startDate.split("T")[0])
            .order("date"),
          supabase.from("projects").select("id, project_name, budget"),
        ]);

        if (expensesRes.error) throw expensesRes.error;
        if (projectsRes.error) throw projectsRes.error;

        setExpenses(expensesRes.data || []);
        setProjects(projectsRes.data || []);
      } catch (error) {
        console.error("Error fetching analytics data:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [timeRange]);

  const filteredExpenses = useMemo(() => {
    if (selectedProject === "all") return expenses;
    return expenses.filter((e) => e.project_id === selectedProject);
  }, [expenses, selectedProject]);

  // Monthly trend data
  const monthlyTrend = useMemo(() => {
    const months: Record<string, number> = {};
    filteredExpenses.forEach((e) => {
      const month = format(parseISO(e.date), "MMM yyyy");
      months[month] = (months[month] || 0) + Number(e.amount);
    });

    return Object.entries(months).map(([month, amount]) => ({
      month,
      amount,
    }));
  }, [filteredExpenses]);

  // Category breakdown
  const categoryData = useMemo(() => {
    const categories: Record<string, number> = {};
    filteredExpenses.forEach((e) => {
      categories[e.category] = (categories[e.category] || 0) + Number(e.amount);
    });

    return Object.entries(categories)
      .map(([name, value]) => ({ name, value }))
      .sort((a, b) => b.value - a.value);
  }, [filteredExpenses]);

  // Project comparison
  const projectComparison = useMemo(() => {
    const projectTotals: Record<string, { spent: number; budget: number | null; name: string }> = {};

    projects.forEach((p) => {
      projectTotals[p.id] = { spent: 0, budget: p.budget, name: p.project_name };
    });

    expenses.forEach((e) => {
      if (projectTotals[e.project_id]) {
        projectTotals[e.project_id].spent += Number(e.amount);
      }
    });

    return Object.values(projectTotals).map((p) => ({
      name: p.name.length > 15 ? p.name.substring(0, 15) + "..." : p.name,
      spent: p.spent,
      budget: p.budget || 0,
      remaining: p.budget ? Math.max(0, p.budget - p.spent) : 0,
    }));
  }, [projects, expenses]);

  // Budget forecasting
  const forecast = useMemo(() => {
    if (monthlyTrend.length < 2) return null;

    const amounts = monthlyTrend.map((m) => m.amount);
    const avg = amounts.reduce((a, b) => a + b, 0) / amounts.length;
    const lastMonth = amounts[amounts.length - 1] || 0;
    const trend = amounts.length > 1
      ? ((lastMonth - amounts[amounts.length - 2]) / amounts[amounts.length - 2]) * 100
      : 0;

    // Simple linear forecast for next 3 months
    const forecastMonths = [];
    let projected = lastMonth;
    const growthRate = trend > 0 ? 1 + (Math.min(trend, 20) / 100) : 1;

    for (let i = 1; i <= 3; i++) {
      projected *= growthRate;
      forecastMonths.push({
        month: format(subMonths(new Date(), -i), "MMM yyyy"),
        amount: null,
        forecast: projected,
      });
    }

    return {
      average: avg,
      trend,
      forecast: forecastMonths,
      combinedData: [
        ...monthlyTrend.map((m) => ({ ...m, forecast: null })),
        ...forecastMonths,
      ],
    };
  }, [monthlyTrend]);

  // Stats
  const stats = useMemo(() => {
    const total = filteredExpenses.reduce((sum, e) => sum + Number(e.amount), 0);
    const monthlyAvg = monthlyTrend.length > 0 ? total / monthlyTrend.length : 0;
    const topCategory = categoryData[0];

    return { total, monthlyAvg, topCategory };
  }, [filteredExpenses, monthlyTrend, categoryData]);

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map((i) => (
            <Skeleton key={i} className="h-24 rounded-xl" />
          ))}
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {[1, 2, 3, 4].map((i) => (
            <Skeleton key={i} className="h-80 rounded-xl" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Filters */}
      <div className="flex flex-wrap gap-4">
        <Select value={selectedProject} onValueChange={setSelectedProject}>
          <SelectTrigger className="w-[200px]">
            <SelectValue placeholder="All Projects" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Projects</SelectItem>
            {projects.map((p) => (
              <SelectItem key={p.id} value={p.id}>
                {p.project_name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select value={timeRange} onValueChange={setTimeRange}>
          <SelectTrigger className="w-[150px]">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="3">Last 3 months</SelectItem>
            <SelectItem value="6">Last 6 months</SelectItem>
            <SelectItem value="12">Last 12 months</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="card-shadow">
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-primary/10 text-primary">
                <TrendingUp className="w-5 h-5" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Total Spending</p>
                <p className="text-xl font-bold">{formatCurrency(stats.total)}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="card-shadow">
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-accent/10 text-accent-foreground">
                <Calendar className="w-5 h-5" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Monthly Average</p>
                <p className="text-xl font-bold">{formatCurrency(stats.monthlyAvg)}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="card-shadow">
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-success/10 text-success">
                <Target className="w-5 h-5" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Top Category</p>
                <p className="text-xl font-bold truncate">
                  {stats.topCategory?.name || "-"}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="card-shadow">
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div
                className={`p-2 rounded-lg ${
                  forecast && forecast.trend > 0
                    ? "bg-warning/10 text-warning"
                    : "bg-success/10 text-success"
                }`}
              >
                {forecast && forecast.trend > 0 ? (
                  <TrendingUp className="w-5 h-5" />
                ) : (
                  <TrendingDown className="w-5 h-5" />
                )}
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Spending Trend</p>
                <p className="text-xl font-bold">
                  {forecast ? `${forecast.trend > 0 ? "+" : ""}${forecast.trend.toFixed(1)}%` : "-"}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Spending Trend with Forecast */}
        <Card className="card-shadow">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              Spending Trend & Forecast
              {forecast && (
                <Badge variant="secondary" className="text-xs">
                  Projected
                </Badge>
              )}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={forecast?.combinedData || monthlyTrend}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                <XAxis dataKey="month" className="text-xs" />
                <YAxis className="text-xs" />
                <Tooltip
                  formatter={(value: number) => formatCurrency(value)}
                  contentStyle={{
                    backgroundColor: "hsl(var(--card))",
                    border: "1px solid hsl(var(--border))",
                    borderRadius: "8px",
                  }}
                />
                <Area
                  type="monotone"
                  dataKey="amount"
                  stroke="hsl(var(--primary))"
                  fill="hsl(var(--primary) / 0.2)"
                  strokeWidth={2}
                />
                <Area
                  type="monotone"
                  dataKey="forecast"
                  stroke="hsl(var(--warning))"
                  fill="hsl(var(--warning) / 0.2)"
                  strokeWidth={2}
                  strokeDasharray="5 5"
                />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Category Distribution */}
        <Card className="card-shadow">
          <CardHeader>
            <CardTitle>Category Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={categoryData}
                  cx="50%"
                  cy="50%"
                  outerRadius={100}
                  innerRadius={50}
                  dataKey="value"
                  label={({ name, percent }) =>
                    `${name} (${(percent * 100).toFixed(0)}%)`
                  }
                >
                  {categoryData.map((_, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip
                  formatter={(value: number) => formatCurrency(value)}
                  contentStyle={{
                    backgroundColor: "hsl(var(--card))",
                    border: "1px solid hsl(var(--border))",
                    borderRadius: "8px",
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Project Budget Comparison */}
        <Card className="card-shadow lg:col-span-2">
          <CardHeader>
            <CardTitle>Project Budget vs Spending</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={projectComparison} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                <XAxis type="number" className="text-xs" />
                <YAxis dataKey="name" type="category" width={120} className="text-xs" />
                <Tooltip
                  formatter={(value: number) => formatCurrency(value)}
                  contentStyle={{
                    backgroundColor: "hsl(var(--card))",
                    border: "1px solid hsl(var(--border))",
                    borderRadius: "8px",
                  }}
                />
                <Legend />
                <Bar dataKey="spent" name="Spent" fill="hsl(var(--primary))" />
                <Bar dataKey="remaining" name="Remaining" fill="hsl(var(--muted))" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default AdvancedAnalytics;

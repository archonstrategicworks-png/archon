import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/contexts/AuthContext";
import { useLanguage } from "@/contexts/LanguageContext";
import { useCurrency } from "@/hooks/useCurrency";
import { supabase } from "@/integrations/supabase/client";
import { Plus, FolderPlus } from "lucide-react";

interface ProjectFormProps {
  onSuccess: () => void;
}

const ProjectForm = ({ onSuccess }: ProjectFormProps) => {
  const { toast } = useToast();
  const { user } = useAuth();
  const { t } = useLanguage();
  const { currency } = useCurrency();
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    project_name: "",
    client: "",
    start_date: new Date().toISOString().split("T")[0],
    status: "Active" as "Active" | "Completed" | "On Hold",
    budget: "",
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.project_name) {
      toast({
        title: "Missing Project Name",
        description: "Please enter a project name.",
        variant: "destructive",
      });
      return;
    }

    if (!user) {
      toast({
        title: "Not Authenticated",
        description: "Please log in to create projects.",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    try {
      const { error } = await supabase.from("projects").insert({
        project_name: formData.project_name,
        client: formData.client || null,
        start_date: formData.start_date || null,
        status: formData.status,
        user_id: user.id,
        budget: formData.budget ? parseFloat(formData.budget) : null,
      });

      if (error) throw error;

      toast({
        title: "Project Created",
        description: `${formData.project_name} has been created successfully.`,
      });
      setFormData({
        project_name: "",
        client: "",
        start_date: new Date().toISOString().split("T")[0],
        status: "Active",
        budget: "",
      });
      setOpen(false);
      onSuccess();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to create project.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button size="lg" variant="secondary">
          <Plus className="w-5 h-5 mr-2" />
          {t("dashboard.newProject")}
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl">
            <FolderPlus className="w-5 h-5 text-primary" />
            {t("dashboard.newProject")}
          </DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-5 mt-4">
          <div className="space-y-2">
            <Label htmlFor="project_name" className="text-sm font-medium">
              Project Name *
            </Label>
            <Input
              id="project_name"
              placeholder="e.g., Highway Construction Phase 2"
              value={formData.project_name}
              onChange={(e) => setFormData({ ...formData, project_name: e.target.value })}
              className="h-12"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="client" className="text-sm font-medium">
              Client
            </Label>
            <Input
              id="client"
              placeholder="e.g., PWD Bangladesh"
              value={formData.client}
              onChange={(e) => setFormData({ ...formData, client: e.target.value })}
              className="h-12"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="budget" className="text-sm font-medium">
              {t("project.budget")} ({currency})
            </Label>
            <Input
              id="budget"
              type="number"
              placeholder="e.g., 500000"
              value={formData.budget}
              onChange={(e) => setFormData({ ...formData, budget: e.target.value })}
              className="h-12"
              min="0"
              step="0.01"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="start_date" className="text-sm font-medium">
                Start Date
              </Label>
              <Input
                id="start_date"
                type="date"
                value={formData.start_date}
                onChange={(e) => setFormData({ ...formData, start_date: e.target.value })}
                className="h-12"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="status" className="text-sm font-medium">
                Status
              </Label>
              <Select
                value={formData.status}
                onValueChange={(value: "Active" | "Completed" | "On Hold") => 
                  setFormData({ ...formData, status: value })
                }
              >
                <SelectTrigger className="h-12">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Active">🟢 {t("common.active")}</SelectItem>
                  <SelectItem value="Completed">✅ {t("common.completed")}</SelectItem>
                  <SelectItem value="On Hold">⏸️ {t("common.onHold")}</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <Button type="submit" size="lg" className="w-full" disabled={loading}>
            <FolderPlus className="w-4 h-4 mr-2" />
            {loading ? t("common.loading") : t("dashboard.newProject")}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default ProjectForm;

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { CalendarIcon, DollarSign, Save, X } from "lucide-react";

interface ExpenseFormProps {
  projectId: string;
  onSuccess: () => void;
  onCancel?: () => void;
  initialData?: {
    date: string;
    amount: string;
    vendor: string;
    category?: string;
  };
}

const ExpenseForm = ({ projectId, onSuccess, onCancel, initialData }: ExpenseFormProps) => {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  
  const mapCategory = (aiCategory?: string): "Materials" | "Labor" | "Transport" | "Fuel" | "Misc" => {
    if (!aiCategory) return "Misc";
    const lowerCategory = aiCategory.toLowerCase();
    if (lowerCategory.includes("food") || lowerCategory.includes("material")) return "Materials";
    if (lowerCategory.includes("transport") || lowerCategory.includes("travel")) return "Transport";
    if (lowerCategory.includes("fuel") || lowerCategory.includes("gas")) return "Fuel";
    if (lowerCategory.includes("labor") || lowerCategory.includes("service")) return "Labor";
    return "Misc";
  };

  const [formData, setFormData] = useState({
    date: initialData?.date || new Date().toISOString().split("T")[0],
    amount: initialData?.amount || "",
    payment_method: "Cash" as "Cash" | "Bank" | "Mobile" | "Cheque",
    category: mapCategory(initialData?.category),
    vendor: initialData?.vendor || "",
    notes: "",
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.amount || !formData.date) {
      toast({
        title: "Missing Fields",
        description: "Please fill in date and amount.",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    try {
      const { error } = await supabase.from("expenses").insert({
        project_id: projectId,
        date: formData.date,
        amount: parseFloat(formData.amount),
        payment_method: formData.payment_method,
        category: formData.category,
        vendor: formData.vendor || null,
        notes: formData.notes || null,
        source: initialData ? "Receipt OCR" : "Manual",
      });

      if (error) throw error;

      toast({
        title: "Expense Added",
        description: "The expense has been recorded successfully.",
      });
      onSuccess();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to add expense.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-5">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        <div className="space-y-2">
          <Label htmlFor="date" className="text-sm font-medium">
            Date *
          </Label>
          <div className="relative">
            <CalendarIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              id="date"
              type="date"
              value={formData.date}
              onChange={(e) => setFormData({ ...formData, date: e.target.value })}
              className="pl-10 h-12"
              required
            />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="amount" className="text-sm font-medium">
            Amount (₹) *
          </Label>
          <div className="relative">
            <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              id="amount"
              type="number"
              step="0.01"
              placeholder="0.00"
              value={formData.amount}
              onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
              className="pl-10 h-12 text-lg font-semibold"
              required
            />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        <div className="space-y-2">
          <Label htmlFor="payment_method" className="text-sm font-medium">
            Payment Method
          </Label>
          <Select
            value={formData.payment_method}
            onValueChange={(value: "Cash" | "Bank" | "Mobile" | "Cheque") => 
              setFormData({ ...formData, payment_method: value })
            }
          >
            <SelectTrigger className="h-12">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Cash">💵 Cash</SelectItem>
              <SelectItem value="Bank">🏦 Bank Transfer</SelectItem>
              <SelectItem value="Mobile">📱 Mobile Payment</SelectItem>
              <SelectItem value="Cheque">📝 Cheque</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="category" className="text-sm font-medium">
            Category
          </Label>
          <Select
            value={formData.category}
            onValueChange={(value: "Materials" | "Labor" | "Transport" | "Fuel" | "Misc") => 
              setFormData({ ...formData, category: value })
            }
          >
            <SelectTrigger className="h-12">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Materials">🧱 Materials</SelectItem>
              <SelectItem value="Labor">👷 Labor</SelectItem>
              <SelectItem value="Transport">🚛 Transport</SelectItem>
              <SelectItem value="Fuel">⛽ Fuel</SelectItem>
              <SelectItem value="Misc">📦 Miscellaneous</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="vendor" className="text-sm font-medium">
          Vendor / Payee
        </Label>
        <Input
          id="vendor"
          placeholder="Enter vendor name"
          value={formData.vendor}
          onChange={(e) => setFormData({ ...formData, vendor: e.target.value })}
          className="h-12"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="notes" className="text-sm font-medium">
          Notes
        </Label>
        <Textarea
          id="notes"
          placeholder="Add any additional details..."
          value={formData.notes}
          onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
          rows={3}
        />
      </div>

      <div className="flex gap-3 pt-2">
        <Button type="submit" size="lg" className="flex-1" disabled={loading}>
          <Save className="w-4 h-4 mr-2" />
          {loading ? "Saving..." : "Save Expense"}
        </Button>
        {onCancel && (
          <Button type="button" variant="outline" size="lg" onClick={onCancel}>
            <X className="w-4 h-4 mr-2" />
            Cancel
          </Button>
        )}
      </div>
    </form>
  );
};

export default ExpenseForm;

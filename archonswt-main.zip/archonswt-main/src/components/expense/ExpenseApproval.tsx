import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { useLanguage } from "@/contexts/LanguageContext";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Check, X, Clock, CheckCircle, XCircle } from "lucide-react";

interface ExpenseApprovalProps {
  expenseId: string;
  currentStatus: string;
  rejectionReason?: string | null;
  onStatusChange: () => void;
  canApprove?: boolean;
}

const ExpenseApproval = ({
  expenseId,
  currentStatus,
  rejectionReason,
  onStatusChange,
  canApprove = true,
}: ExpenseApprovalProps) => {
  const [loading, setLoading] = useState(false);
  const [showRejectDialog, setShowRejectDialog] = useState(false);
  const [rejectReason, setRejectReason] = useState("");
  const { toast } = useToast();
  const { t } = useLanguage();

  const statusConfig: Record<string, { icon: React.ReactNode; color: string; label: string }> = {
    pending: {
      icon: <Clock className="w-3 h-3" />,
      color: "bg-warning/10 text-warning border-warning/20",
      label: "Pending",
    },
    approved: {
      icon: <CheckCircle className="w-3 h-3" />,
      color: "bg-success/10 text-success border-success/20",
      label: "Approved",
    },
    rejected: {
      icon: <XCircle className="w-3 h-3" />,
      color: "bg-destructive/10 text-destructive border-destructive/20",
      label: "Rejected",
    },
  };

  const handleApprove = async () => {
    setLoading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");

      const { error } = await supabase
        .from("expenses")
        .update({
          approval_status: "approved",
          approved_by: user.id,
          approved_at: new Date().toISOString(),
          rejection_reason: null,
        })
        .eq("id", expenseId);

      if (error) throw error;

      toast({
        title: "Expense Approved",
        description: "The expense has been approved successfully.",
      });
      onStatusChange();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to approve expense",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleReject = async () => {
    if (!rejectReason.trim()) {
      toast({
        title: "Reason Required",
        description: "Please provide a reason for rejection",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");

      const { error } = await supabase
        .from("expenses")
        .update({
          approval_status: "rejected",
          approved_by: user.id,
          approved_at: new Date().toISOString(),
          rejection_reason: rejectReason.trim(),
        })
        .eq("id", expenseId);

      if (error) throw error;

      toast({
        title: "Expense Rejected",
        description: "The expense has been rejected.",
      });
      setShowRejectDialog(false);
      setRejectReason("");
      onStatusChange();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to reject expense",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const config = statusConfig[currentStatus] || statusConfig.pending;

  return (
    <div className="flex items-center gap-2">
      <Badge className={`${config.color} border flex items-center gap-1`}>
        {config.icon}
        {config.label}
      </Badge>

      {canApprove && currentStatus === "pending" && (
        <div className="flex gap-1">
          <Button
            variant="ghost"
            size="sm"
            className="h-7 w-7 p-0 text-success hover:text-success hover:bg-success/10"
            onClick={handleApprove}
            disabled={loading}
          >
            <Check className="w-4 h-4" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="h-7 w-7 p-0 text-destructive hover:text-destructive hover:bg-destructive/10"
            onClick={() => setShowRejectDialog(true)}
            disabled={loading}
          >
            <X className="w-4 h-4" />
          </Button>
        </div>
      )}

      {currentStatus === "rejected" && rejectionReason && (
        <span className="text-xs text-muted-foreground truncate max-w-[100px]" title={rejectionReason}>
          {rejectionReason}
        </span>
      )}

      <Dialog open={showRejectDialog} onOpenChange={setShowRejectDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Reject Expense</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Please provide a reason for rejecting this expense.
            </p>
            <Textarea
              value={rejectReason}
              onChange={(e) => setRejectReason(e.target.value)}
              placeholder="Reason for rejection..."
              rows={3}
            />
            <div className="flex gap-2 justify-end">
              <Button variant="outline" onClick={() => setShowRejectDialog(false)}>
                Cancel
              </Button>
              <Button variant="destructive" onClick={handleReject} disabled={loading}>
                Reject Expense
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default ExpenseApproval;

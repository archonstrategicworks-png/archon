import { useState } from "react";
import { format } from "date-fns";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Trash2, Image, Eye } from "lucide-react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { useCurrency } from "@/hooks/useCurrency";
import ExpenseApproval from "./ExpenseApproval";
import ReceiptLightbox from "@/components/ui/receipt-lightbox";

interface Expense {
  id: string;
  date: string;
  amount: number;
  payment_method: string;
  category: string;
  vendor: string | null;
  notes: string | null;
  source: string;
  created_at: string;
  file_id?: string | null;
  approval_status?: string;
  rejection_reason?: string | null;
}

interface ExpenseTableProps {
  expenses: Expense[];
  onDelete: () => void;
  showApproval?: boolean;
  canApprove?: boolean;
}

const ExpenseTable = ({ 
  expenses, 
  onDelete, 
  showApproval = true,
  canApprove = true 
}: ExpenseTableProps) => {
  const { toast } = useToast();
  const { format: formatCurrency } = useCurrency();
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [lightboxImage, setLightboxImage] = useState<{ url: string; name: string } | null>(null);
  const [loadingReceipt, setLoadingReceipt] = useState<string | null>(null);

  const categoryIcons: Record<string, string> = {
    Materials: "🧱",
    Labor: "👷",
    Transport: "🚛",
    Fuel: "⛽",
    Misc: "📦",
    Equipment: "🔧",
    Travel: "🚗",
    Office: "🏢",
    Utilities: "⚡",
    Marketing: "📢",
    Other: "📦",
  };

  const paymentColors: Record<string, string> = {
    Cash: "bg-success/10 text-success border-success/20",
    Bank: "bg-primary/10 text-primary border-primary/20",
    Mobile: "bg-accent/10 text-accent-foreground border-accent/20",
    Cheque: "bg-warning/10 text-warning border-warning/20",
  };

  const sourceColors: Record<string, string> = {
    Manual: "bg-muted text-muted-foreground",
    "Receipt OCR": "bg-primary/10 text-primary",
    "Bank OCR": "bg-accent/10 text-accent-foreground",
    Recurring: "bg-secondary text-secondary-foreground",
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Are you sure you want to delete this expense?")) return;

    try {
      const { error } = await supabase.from("expenses").delete().eq("id", id);
      if (error) throw error;

      toast({
        title: "Expense Deleted",
        description: "The expense has been removed.",
      });
      onDelete();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to delete expense.",
        variant: "destructive",
      });
    }
  };

  const handleViewReceipt = async (fileId: string) => {
    setLoadingReceipt(fileId);
    try {
      // Get the upload record
      const { data: upload, error: uploadError } = await supabase
        .from("uploads")
        .select("file_url, file_name")
        .eq("id", fileId)
        .single();

      if (uploadError) throw uploadError;

      if (upload?.file_url) {
        setLightboxImage({
          url: upload.file_url,
          name: upload.file_name || "Receipt",
        });
        setLightboxOpen(true);
      }
    } catch (error: any) {
      toast({
        title: "Error",
        description: "Failed to load receipt image",
        variant: "destructive",
      });
    } finally {
      setLoadingReceipt(null);
    }
  };

  if (expenses.length === 0) {
    return (
      <div className="text-center py-12 bg-muted/30 rounded-xl">
        <p className="text-muted-foreground text-lg">No expenses recorded yet.</p>
        <p className="text-sm text-muted-foreground mt-1">
          Add your first expense above.
        </p>
      </div>
    );
  }

  return (
    <>
      <div className="rounded-xl border bg-card overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="bg-muted/50">
              <TableHead className="font-semibold">Date</TableHead>
              <TableHead className="font-semibold">Category</TableHead>
              <TableHead className="font-semibold">Vendor</TableHead>
              <TableHead className="font-semibold">Payment</TableHead>
              <TableHead className="font-semibold text-right">Amount</TableHead>
              <TableHead className="font-semibold">Source</TableHead>
              {showApproval && (
                <TableHead className="font-semibold">Status</TableHead>
              )}
              <TableHead className="w-24"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {expenses.map((expense) => (
              <TableRow key={expense.id} className="hover:bg-muted/30">
                <TableCell className="font-medium">
                  {format(new Date(expense.date), "MMM dd, yyyy")}
                </TableCell>
                <TableCell>
                  <span className="flex items-center gap-2">
                    <span>{categoryIcons[expense.category] || "📦"}</span>
                    {expense.category}
                  </span>
                </TableCell>
                <TableCell className="max-w-[150px] truncate">
                  {expense.vendor || "-"}
                </TableCell>
                <TableCell>
                  <Badge className={`${paymentColors[expense.payment_method] || paymentColors.Cash} border`}>
                    {expense.payment_method}
                  </Badge>
                </TableCell>
                <TableCell className="text-right font-bold font-display">
                  {formatCurrency(expense.amount)}
                </TableCell>
                <TableCell>
                  <Badge variant="secondary" className={sourceColors[expense.source] || sourceColors.Manual}>
                    {expense.source}
                  </Badge>
                </TableCell>
                {showApproval && (
                  <TableCell>
                    <ExpenseApproval
                      expenseId={expense.id}
                      currentStatus={expense.approval_status || "pending"}
                      rejectionReason={expense.rejection_reason}
                      onStatusChange={onDelete}
                      canApprove={canApprove}
                    />
                  </TableCell>
                )}
                <TableCell>
                  <div className="flex items-center gap-1">
                    {expense.file_id && (
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 text-muted-foreground hover:text-primary"
                        onClick={() => handleViewReceipt(expense.file_id!)}
                        disabled={loadingReceipt === expense.file_id}
                      >
                        {loadingReceipt === expense.file_id ? (
                          <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
                        ) : (
                          <Eye className="w-4 h-4" />
                        )}
                      </Button>
                    )}
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 text-muted-foreground hover:text-destructive"
                      onClick={() => handleDelete(expense.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {lightboxImage && (
        <ReceiptLightbox
          imageUrl={lightboxImage.url}
          fileName={lightboxImage.name}
          isOpen={lightboxOpen}
          onClose={() => {
            setLightboxOpen(false);
            setLightboxImage(null);
          }}
        />
      )}
    </>
  );
};

export default ExpenseTable;

import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tags, Plus, X, Loader2, Settings2 } from "lucide-react";

interface CustomField {
  id: string;
  field_name: string;
  field_type: string;
  options: string[] | null;
  is_required: boolean;
}

interface ExpenseTagsManagerProps {
  projectId: string;
}

const FIELD_TYPES = [
  { value: "text", label: "Text" },
  { value: "number", label: "Number" },
  { value: "date", label: "Date" },
  { value: "select", label: "Dropdown" },
];

const ExpenseTagsManager = ({ projectId }: ExpenseTagsManagerProps) => {
  const [customFields, setCustomFields] = useState<CustomField[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();

  const [newField, setNewField] = useState({
    field_name: "",
    field_type: "text",
    options: "",
    is_required: false,
  });

  const fetchFields = async () => {
    try {
      const { data, error } = await supabase
        .from("project_custom_fields")
        .select("*")
        .eq("project_id", projectId)
        .order("created_at");

      if (error) throw error;
      setCustomFields(data || []);
    } catch (error) {
      console.error("Error fetching custom fields:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchFields();
  }, [projectId]);

  const handleAddField = async () => {
    if (!newField.field_name.trim()) {
      toast({
        title: "Field name required",
        variant: "destructive",
      });
      return;
    }

    setSaving(true);
    try {
      const options =
        newField.field_type === "select" && newField.options
          ? newField.options.split(",").map((o) => o.trim()).filter(Boolean)
          : null;

      const { error } = await supabase.from("project_custom_fields").insert({
        project_id: projectId,
        field_name: newField.field_name.trim(),
        field_type: newField.field_type,
        options,
        is_required: newField.is_required,
      });

      if (error) throw error;

      toast({
        title: "Custom Field Added",
        description: `Field "${newField.field_name}" has been created.`,
      });

      setNewField({
        field_name: "",
        field_type: "text",
        options: "",
        is_required: false,
      });
      fetchFields();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteField = async (fieldId: string) => {
    if (!confirm("Delete this custom field? All values will be lost.")) return;

    try {
      const { error } = await supabase
        .from("project_custom_fields")
        .delete()
        .eq("id", fieldId);

      if (error) throw error;

      toast({ title: "Field Deleted" });
      fetchFields();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm">
          <Settings2 className="w-4 h-4 mr-2" />
          Custom Fields
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Tags className="w-5 h-5" />
            Manage Custom Fields
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Existing Fields */}
          <div className="space-y-2">
            <Label className="text-sm font-medium">Current Fields</Label>
            {loading ? (
              <div className="flex items-center justify-center py-4">
                <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
              </div>
            ) : customFields.length === 0 ? (
              <p className="text-sm text-muted-foreground py-4 text-center">
                No custom fields yet
              </p>
            ) : (
              <div className="space-y-2">
                {customFields.map((field) => (
                  <div
                    key={field.id}
                    className="flex items-center justify-between p-2 rounded-lg bg-muted/50"
                  >
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-sm">{field.field_name}</span>
                      <Badge variant="secondary" className="text-xs">
                        {FIELD_TYPES.find((t) => t.value === field.field_type)?.label}
                      </Badge>
                      {field.is_required && (
                        <Badge variant="outline" className="text-xs">
                          Required
                        </Badge>
                      )}
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-7 w-7 p-0 text-destructive hover:text-destructive"
                      onClick={() => handleDeleteField(field.id)}
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Add New Field */}
          <Card>
            <CardHeader className="py-3">
              <CardTitle className="text-sm flex items-center gap-2">
                <Plus className="w-4 h-4" />
                Add Custom Field
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div>
                <Label>Field Name</Label>
                <Input
                  value={newField.field_name}
                  onChange={(e) =>
                    setNewField({ ...newField, field_name: e.target.value })
                  }
                  placeholder="e.g., Invoice Number"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label>Field Type</Label>
                  <Select
                    value={newField.field_type}
                    onValueChange={(v) =>
                      setNewField({ ...newField, field_type: v })
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {FIELD_TYPES.map((type) => (
                        <SelectItem key={type.value} value={type.value}>
                          {type.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex items-end">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={newField.is_required}
                      onChange={(e) =>
                        setNewField({ ...newField, is_required: e.target.checked })
                      }
                      className="rounded"
                    />
                    <span className="text-sm">Required</span>
                  </label>
                </div>
              </div>

              {newField.field_type === "select" && (
                <div>
                  <Label>Options (comma-separated)</Label>
                  <Input
                    value={newField.options}
                    onChange={(e) =>
                      setNewField({ ...newField, options: e.target.value })
                    }
                    placeholder="Option 1, Option 2, Option 3"
                  />
                </div>
              )}

              <Button
                onClick={handleAddField}
                disabled={saving}
                className="w-full"
              >
                {saving && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                Add Field
              </Button>
            </CardContent>
          </Card>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default ExpenseTagsManager;

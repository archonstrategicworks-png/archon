import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { useCurrency } from "@/hooks/useCurrency";
import { useExpenseCategories } from "@/hooks/useExpenseCategories";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { RefreshCw, Plus, Trash2, Loader2 } from "lucide-react";
import { format } from "date-fns";

interface RecurringExpense {
  id: string;
  project_id: string;
  category: string;
  vendor: string | null;
  amount: number;
  payment_method: string;
  notes: string | null;
  frequency: string;
  start_date: string;
  end_date: string | null;
  next_run_date: string;
  is_active: boolean;
  last_generated_at: string | null;
}

interface RecurringExpenseManagerProps {
  projectId: string;
  onExpenseGenerated?: () => void;
}

const FREQUENCIES = [
  { value: "daily", label: "Daily" },
  { value: "weekly", label: "Weekly" },
  { value: "monthly", label: "Monthly" },
  { value: "yearly", label: "Yearly" },
];

const PAYMENT_METHODS = ["Cash", "Bank", "Mobile", "Cheque"];

const RecurringExpenseManager = ({
  projectId,
  onExpenseGenerated,
}: RecurringExpenseManagerProps) => {
  const [recurring, setRecurring] = useState<RecurringExpense[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [generating, setGenerating] = useState<string | null>(null);
  const { toast } = useToast();
  const { format: formatCurrency } = useCurrency();
  const { categories } = useExpenseCategories();

  const [formData, setFormData] = useState({
    category: "",
    vendor: "",
    amount: "",
    payment_method: "Cash",
    notes: "",
    frequency: "monthly",
    start_date: new Date().toISOString().split("T")[0],
    end_date: "",
  });

  const fetchRecurring = async () => {
    try {
      const { data, error } = await supabase
        .from("recurring_expenses")
        .select("*")
        .eq("project_id", projectId)
        .order("created_at", { ascending: false });

      if (error) throw error;
      setRecurring(data || []);
    } catch (error) {
      console.error("Error fetching recurring expenses:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchRecurring();
  }, [projectId]);

  const handleCreate = async () => {
    if (!formData.category || !formData.amount) {
      toast({
        title: "Required Fields",
        description: "Please fill in category and amount",
        variant: "destructive",
      });
      return;
    }

    setSaving(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");

      const { error } = await supabase.from("recurring_expenses").insert({
        project_id: projectId,
        user_id: user.id,
        category: formData.category,
        vendor: formData.vendor || null,
        amount: parseFloat(formData.amount),
        payment_method: formData.payment_method,
        notes: formData.notes || null,
        frequency: formData.frequency,
        start_date: formData.start_date,
        end_date: formData.end_date || null,
        next_run_date: formData.start_date,
      });

      if (error) throw error;

      toast({
        title: "Recurring Expense Created",
        description: "The recurring expense has been set up.",
      });

      setOpen(false);
      setFormData({
        category: "",
        vendor: "",
        amount: "",
        payment_method: "Cash",
        notes: "",
        frequency: "monthly",
        start_date: new Date().toISOString().split("T")[0],
        end_date: "",
      });
      fetchRecurring();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to create recurring expense",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  const handleGenerateNow = async (recurringId: string) => {
    setGenerating(recurringId);
    try {
      const recurringExpense = recurring.find((r) => r.id === recurringId);
      if (!recurringExpense) return;

      // Create the expense
      const { error: expenseError } = await supabase.from("expenses").insert({
        project_id: recurringExpense.project_id,
        category: recurringExpense.category,
        vendor: recurringExpense.vendor,
        amount: recurringExpense.amount,
        payment_method: recurringExpense.payment_method,
        notes: recurringExpense.notes,
        date: new Date().toISOString().split("T")[0],
        source: "Recurring",
      });

      if (expenseError) throw expenseError;

      // Calculate next run date
      const currentDate = new Date();
      let nextDate = new Date(currentDate);

      switch (recurringExpense.frequency) {
        case "daily":
          nextDate.setDate(nextDate.getDate() + 1);
          break;
        case "weekly":
          nextDate.setDate(nextDate.getDate() + 7);
          break;
        case "monthly":
          nextDate.setMonth(nextDate.getMonth() + 1);
          break;
        case "yearly":
          nextDate.setFullYear(nextDate.getFullYear() + 1);
          break;
      }

      // Update recurring expense
      await supabase
        .from("recurring_expenses")
        .update({
          next_run_date: nextDate.toISOString().split("T")[0],
          last_generated_at: new Date().toISOString(),
        })
        .eq("id", recurringId);

      toast({
        title: "Expense Generated",
        description: "The expense has been added to the project.",
      });

      fetchRecurring();
      onExpenseGenerated?.();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to generate expense",
        variant: "destructive",
      });
    } finally {
      setGenerating(null);
    }
  };

  const handleToggleActive = async (id: string, isActive: boolean) => {
    try {
      const { error } = await supabase
        .from("recurring_expenses")
        .update({ is_active: !isActive })
        .eq("id", id);

      if (error) throw error;
      fetchRecurring();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Delete this recurring expense?")) return;

    try {
      const { error } = await supabase
        .from("recurring_expenses")
        .delete()
        .eq("id", id);

      if (error) throw error;

      toast({
        title: "Deleted",
        description: "Recurring expense removed.",
      });
      fetchRecurring();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  return (
    <Card className="card-shadow">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="flex items-center gap-2">
          <RefreshCw className="w-5 h-5" />
          Recurring Expenses
        </CardTitle>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button size="sm">
              <Plus className="w-4 h-4 mr-2" />
              Add Recurring
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create Recurring Expense</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Category</Label>
                  <Select
                    value={formData.category}
                    onValueChange={(v) => setFormData({ ...formData, category: v })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map((cat) => (
                        <SelectItem key={cat.id} value={cat.name}>
                          {cat.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Amount</Label>
                  <Input
                    type="number"
                    value={formData.amount}
                    onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                    placeholder="0.00"
                  />
                </div>
              </div>

              <div>
                <Label>Vendor</Label>
                <Input
                  value={formData.vendor}
                  onChange={(e) => setFormData({ ...formData, vendor: e.target.value })}
                  placeholder="Vendor name"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Payment Method</Label>
                  <Select
                    value={formData.payment_method}
                    onValueChange={(v) => setFormData({ ...formData, payment_method: v })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {PAYMENT_METHODS.map((method) => (
                        <SelectItem key={method} value={method}>
                          {method}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Frequency</Label>
                  <Select
                    value={formData.frequency}
                    onValueChange={(v) => setFormData({ ...formData, frequency: v })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {FREQUENCIES.map((freq) => (
                        <SelectItem key={freq.value} value={freq.value}>
                          {freq.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Start Date</Label>
                  <Input
                    type="date"
                    value={formData.start_date}
                    onChange={(e) => setFormData({ ...formData, start_date: e.target.value })}
                  />
                </div>
                <div>
                  <Label>End Date (Optional)</Label>
                  <Input
                    type="date"
                    value={formData.end_date}
                    onChange={(e) => setFormData({ ...formData, end_date: e.target.value })}
                  />
                </div>
              </div>

              <div>
                <Label>Notes</Label>
                <Textarea
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  placeholder="Optional notes..."
                  rows={2}
                />
              </div>

              <div className="flex gap-2 justify-end">
                <Button variant="outline" onClick={() => setOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={handleCreate} disabled={saving}>
                  {saving && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                  Create
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="flex items-center justify-center py-8">
            <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
          </div>
        ) : recurring.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <RefreshCw className="w-10 h-10 mx-auto mb-2 opacity-50" />
            <p>No recurring expenses set up</p>
          </div>
        ) : (
          <div className="space-y-3">
            {recurring.map((item) => (
              <div
                key={item.id}
                className={`p-3 rounded-lg border ${
                  item.is_active ? "bg-muted/30" : "bg-muted/10 opacity-60"
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-medium truncate">{item.category}</span>
                      <Badge variant="secondary" className="text-xs">
                        {FREQUENCIES.find((f) => f.value === item.frequency)?.label}
                      </Badge>
                      {!item.is_active && (
                        <Badge variant="outline" className="text-xs">
                          Paused
                        </Badge>
                      )}
                    </div>
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <span>{formatCurrency(item.amount)}</span>
                      {item.vendor && <span>• {item.vendor}</span>}
                      <span>
                        Next: {format(new Date(item.next_run_date), "MMM dd")}
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleGenerateNow(item.id)}
                      disabled={generating === item.id || !item.is_active}
                    >
                      {generating === item.id ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : (
                        <RefreshCw className="w-4 h-4" />
                      )}
                    </Button>
                    <Switch
                      checked={item.is_active}
                      onCheckedChange={() => handleToggleActive(item.id, item.is_active)}
                    />
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-destructive hover:text-destructive"
                      onClick={() => handleDelete(item.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default RecurringExpenseManager;

import { useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { useActivityTracking } from '@/hooks/useActivityTracking';

export function ActivityTracker() {
  const { trackActivity } = useActivityTracking();
  const location = useLocation();

  // Track page views
  useEffect(() => {
    trackActivity('page_view', { path: location.pathname });
  }, [location.pathname]);

  return null;
}

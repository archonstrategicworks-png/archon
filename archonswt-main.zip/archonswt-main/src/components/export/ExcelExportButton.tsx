import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { FileSpreadsheet, Download, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useCurrency } from "@/hooks/useCurrency";
import {
  exportExpensesToExcel,
  exportAllProjectsToExcel,
  exportBankTransactionsToExcel,
} from "@/lib/excelExport";
import { supabase } from "@/integrations/supabase/client";

interface Expense {
  id: string;
  date: string;
  amount: number;
  payment_method: string;
  category: string;
  vendor: string | null;
  notes: string | null;
  source: string;
}

interface ExcelExportButtonProps {
  projectId?: string;
  projectName?: string;
  expenses?: Expense[];
  variant?: "project" | "all" | "bank";
}

const ExcelExportButton = ({
  projectId,
  projectName,
  expenses,
  variant = "project",
}: ExcelExportButtonProps) => {
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();
  const { symbol } = useCurrency();

  const handleExportProject = async () => {
    if (!expenses || !projectName) {
      toast({
        title: "No Data",
        description: "No expenses to export",
        variant: "destructive",
      });
      return;
    }

    if (expenses.length === 0) {
      toast({
        title: "No Data",
        description: "No expenses to export",
        variant: "destructive",
      });
      return;
    }

    exportExpensesToExcel(expenses, projectName, symbol);

    toast({
      title: "Export Complete",
      description: `Excel file downloaded for ${projectName}`,
    });
  };

  const handleExportAll = async () => {
    setLoading(true);
    try {
      // Fetch all projects
      const { data: projects, error: projectsError } = await supabase
        .from("projects")
        .select("*");

      if (projectsError) throw projectsError;

      // Fetch all expenses
      const { data: allExpenses, error: expensesError } = await supabase
        .from("expenses")
        .select("*");

      if (expensesError) throw expensesError;

      // Map expenses to projects
      const projectsWithExpenses = (projects || []).map((project) => ({
        ...project,
        expenses: (allExpenses || []).filter(
          (e) => e.project_id === project.id
        ),
      }));

      if (projectsWithExpenses.length === 0) {
        toast({
          title: "No Data",
          description: "No projects to export",
          variant: "destructive",
        });
        return;
      }

      exportAllProjectsToExcel(projectsWithExpenses, symbol);

      toast({
        title: "Export Complete",
        description: "All projects exported to Excel",
      });
    } catch (error) {
      console.error("Error exporting:", error);
      toast({
        title: "Export Failed",
        description: "Failed to export data",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleExportBank = async () => {
    setLoading(true);
    try {
      const { data: transactions, error } = await supabase
        .from("bank_transactions")
        .select("*")
        .order("date", { ascending: false });

      if (error) throw error;

      if (!transactions || transactions.length === 0) {
        toast({
          title: "No Data",
          description: "No bank transactions to export",
          variant: "destructive",
        });
        return;
      }

      exportBankTransactionsToExcel(transactions, symbol);

      toast({
        title: "Export Complete",
        description: "Bank transactions exported to Excel",
      });
    } catch (error) {
      console.error("Error exporting:", error);
      toast({
        title: "Export Failed",
        description: "Failed to export bank transactions",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  if (variant === "project") {
    return (
      <Button
        variant="secondary"
        onClick={handleExportProject}
        disabled={loading}
      >
        {loading ? (
          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
        ) : (
          <FileSpreadsheet className="w-4 h-4 mr-2" />
        )}
        Export Excel
      </Button>
    );
  }

  if (variant === "bank") {
    return (
      <Button variant="secondary" onClick={handleExportBank} disabled={loading}>
        {loading ? (
          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
        ) : (
          <FileSpreadsheet className="w-4 h-4 mr-2" />
        )}
        Export Excel
      </Button>
    );
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="secondary" disabled={loading}>
          {loading ? (
            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
          ) : (
            <FileSpreadsheet className="w-4 h-4 mr-2" />
          )}
          Export Excel
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        <DropdownMenuItem onClick={handleExportAll}>
          <Download className="w-4 h-4 mr-2" />
          All Projects
        </DropdownMenuItem>
        <DropdownMenuItem onClick={handleExportBank}>
          <Download className="w-4 h-4 mr-2" />
          Bank Transactions
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
};

export default ExcelExportButton;

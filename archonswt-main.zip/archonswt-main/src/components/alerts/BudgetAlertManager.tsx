import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { 
  Bell, 
  AlertTriangle, 
  Save,
  Loader2,
  Trash2,
  Mail
} from "lucide-react";

interface BudgetAlert {
  id: string;
  project_id: string;
  threshold_percentage: number;
  email_enabled: boolean;
  is_active: boolean;
  last_notified_at: string | null;
}

interface Project {
  id: string;
  project_name: string;
  budget: number | null;
}

interface BudgetAlertManagerProps {
  projectId: string;
  projectName: string;
  budget: number | null;
  currentSpent: number;
}

const BudgetAlertManager = ({ 
  projectId, 
  projectName, 
  budget, 
  currentSpent 
}: BudgetAlertManagerProps) => {
  const { toast } = useToast();
  const { user } = useAuth();
  const [alert, setAlert] = useState<BudgetAlert | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const [formData, setFormData] = useState({
    threshold_percentage: 80,
    email_enabled: true,
    is_active: true,
  });

  useEffect(() => {
    fetchAlert();
  }, [projectId]);

  const fetchAlert = async () => {
    if (!user) return;
    try {
      const { data, error } = await supabase
        .from("budget_alerts")
        .select("*")
        .eq("project_id", projectId)
        .eq("user_id", user.id)
        .maybeSingle();

      if (error) throw error;
      
      if (data) {
        setAlert(data);
        setFormData({
          threshold_percentage: data.threshold_percentage,
          email_enabled: data.email_enabled,
          is_active: data.is_active,
        });
      }
    } catch (error) {
      console.error("Error fetching alert:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    if (!user) return;
    
    setSaving(true);
    try {
      const alertData = {
        user_id: user.id,
        project_id: projectId,
        threshold_percentage: formData.threshold_percentage,
        email_enabled: formData.email_enabled,
        is_active: formData.is_active,
      };

      if (alert) {
        const { error } = await supabase
          .from("budget_alerts")
          .update(alertData)
          .eq("id", alert.id);

        if (error) throw error;
      } else {
        const { error } = await supabase
          .from("budget_alerts")
          .insert(alertData);

        if (error) throw error;
      }

      toast({ title: "Alert Settings Saved" });
      fetchAlert();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!alert) return;
    
    try {
      const { error } = await supabase
        .from("budget_alerts")
        .delete()
        .eq("id", alert.id);

      if (error) throw error;
      
      setAlert(null);
      setFormData({
        threshold_percentage: 80,
        email_enabled: true,
        is_active: true,
      });
      toast({ title: "Alert Removed" });
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const sendTestAlert = async () => {
    if (!user?.email) {
      toast({
        title: "Error",
        description: "No email address found",
        variant: "destructive",
      });
      return;
    }

    try {
      const { error } = await supabase.functions.invoke("send-report-email", {
        body: {
          type: "budget_alert",
          recipientEmail: user.email,
          projectName,
          threshold: formData.threshold_percentage,
          currentPercentage: budget ? Math.round((currentSpent / budget) * 100) : 0,
          spent: currentSpent,
          budget: budget,
        },
      });

      if (error) throw error;
      toast({ title: "Test Alert Sent", description: "Check your email" });
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  if (!budget) {
    return (
      <Card>
        <CardContent className="py-8 text-center text-muted-foreground">
          <AlertTriangle className="w-8 h-8 mx-auto mb-2 opacity-50" />
          <p>Set a budget for this project to enable alerts</p>
        </CardContent>
      </Card>
    );
  }

  const currentPercentage = Math.round((currentSpent / budget) * 100);
  const isOverThreshold = currentPercentage >= formData.threshold_percentage;

  if (loading) {
    return (
      <Card>
        <CardContent className="py-6">
          <Loader2 className="w-6 h-6 animate-spin mx-auto" />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-base">
          <Bell className="w-5 h-5" />
          Budget Alert Settings
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="p-3 rounded-lg bg-muted/50">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-muted-foreground">Current Usage</span>
            <Badge variant={isOverThreshold ? "destructive" : "secondary"}>
              {currentPercentage}%
            </Badge>
          </div>
          <div className="h-2 bg-muted rounded-full overflow-hidden">
            <div
              className={`h-full transition-all ${
                currentPercentage >= 100
                  ? "bg-destructive"
                  : currentPercentage >= formData.threshold_percentage
                  ? "bg-warning"
                  : "bg-primary"
              }`}
              style={{ width: `${Math.min(currentPercentage, 100)}%` }}
            />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="threshold">Alert Threshold (%)</Label>
          <div className="flex items-center gap-3">
            <Input
              id="threshold"
              type="number"
              min={1}
              max={100}
              value={formData.threshold_percentage}
              onChange={(e) =>
                setFormData({ ...formData, threshold_percentage: Number(e.target.value) })
              }
              className="w-24"
            />
            <span className="text-sm text-muted-foreground">
              Alert when spending reaches {formData.threshold_percentage}% of budget
            </span>
          </div>
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Mail className="w-4 h-4 text-muted-foreground" />
            <Label htmlFor="email_enabled" className="cursor-pointer">
              Email Notifications
            </Label>
          </div>
          <Switch
            id="email_enabled"
            checked={formData.email_enabled}
            onCheckedChange={(checked) =>
              setFormData({ ...formData, email_enabled: checked })
            }
          />
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Bell className="w-4 h-4 text-muted-foreground" />
            <Label htmlFor="is_active" className="cursor-pointer">
              Alert Active
            </Label>
          </div>
          <Switch
            id="is_active"
            checked={formData.is_active}
            onCheckedChange={(checked) =>
              setFormData({ ...formData, is_active: checked })
            }
          />
        </div>

        <div className="flex gap-2 pt-2">
          <Button onClick={handleSave} disabled={saving} className="flex-1">
            {saving ? (
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            ) : (
              <Save className="w-4 h-4 mr-2" />
            )}
            Save Settings
          </Button>
          {formData.email_enabled && (
            <Button variant="outline" onClick={sendTestAlert}>
              Test Alert
            </Button>
          )}
        </div>

        {alert && (
          <Button
            variant="ghost"
            className="w-full text-destructive hover:text-destructive"
            onClick={handleDelete}
          >
            <Trash2 className="w-4 h-4 mr-2" />
            Remove Alert
          </Button>
        )}
      </CardContent>
    </Card>
  );
};

export default BudgetAlertManager;

import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useLanguage } from "@/contexts/LanguageContext";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { UserPlus, Loader2, Users, X, Mail } from "lucide-react";

interface Collaborator {
  id: string;
  invited_email: string;
  role: string;
  status: string;
  created_at: string;
}

interface CollaboratorManagerProps {
  projectId: string;
  projectName: string;
}

const CollaboratorManager = ({ projectId, projectName }: CollaboratorManagerProps) => {
  const { user } = useAuth();
  const { t } = useLanguage();
  const { toast } = useToast();
  const [collaborators, setCollaborators] = useState<Collaborator[]>([]);
  const [loading, setLoading] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const [email, setEmail] = useState("");
  const [inviting, setInviting] = useState(false);

  const fetchCollaborators = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from("project_collaborators")
        .select("*")
        .eq("project_id", projectId)
        .order("created_at", { ascending: false });

      if (error) throw error;
      setCollaborators(data || []);
    } catch (error) {
      console.error("Error fetching collaborators:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleOpen = () => {
    setIsOpen(true);
    fetchCollaborators();
  };

  const inviteCollaborator = async () => {
    if (!email.trim() || !user) return;

    setInviting(true);
    try {
      // Check if email is already invited
      const existing = collaborators.find(c => c.invited_email === email);
      if (existing) {
        toast({
          title: "Already Invited",
          description: "This email has already been invited to this project.",
          variant: "destructive",
        });
        setInviting(false);
        return;
      }

      const { error } = await supabase.from("project_collaborators").insert({
        project_id: projectId,
        user_id: user.id, // Will be updated when user accepts
        invited_by: user.id,
        invited_email: email.trim(),
        role: "viewer",
        status: "pending",
      });

      if (error) throw error;

      // Send invitation email
      await supabase.functions.invoke("send-report-email", {
        body: {
          type: "invitation",
          recipientEmail: email.trim(),
          projectName,
          inviterEmail: user.email,
        },
      });

      toast({
        title: t("common.success"),
        description: `Invitation sent to ${email}`,
      });

      setEmail("");
      fetchCollaborators();
    } catch (error: any) {
      toast({
        title: t("common.error"),
        description: error.message || "Failed to send invitation",
        variant: "destructive",
      });
    } finally {
      setInviting(false);
    }
  };

  const removeCollaborator = async (id: string) => {
    try {
      const { error } = await supabase
        .from("project_collaborators")
        .delete()
        .eq("id", id);

      if (error) throw error;
      fetchCollaborators();
      toast({ title: t("common.success"), description: "Collaborator removed" });
    } catch (error) {
      toast({
        title: t("common.error"),
        description: "Failed to remove collaborator",
        variant: "destructive",
      });
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return <Badge variant="secondary">{t("common.pending")}</Badge>;
      case "accepted":
        return <Badge className="bg-success/10 text-success">{t("common.accepted")}</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" onClick={handleOpen}>
          <Users className="w-4 h-4 mr-2" />
          {t("project.collaborators")}
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Users className="w-5 h-5" />
            {t("project.collaborators")}
          </DialogTitle>
          <DialogDescription>
            {t("project.inviteEmail")}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="flex gap-2">
            <Input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="email@example.com"
              className="flex-1"
            />
            <Button onClick={inviteCollaborator} disabled={inviting || !email.trim()}>
              {inviting ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <UserPlus className="w-4 h-4" />
              )}
            </Button>
          </div>

          {loading ? (
            <div className="flex justify-center py-4">
              <Loader2 className="w-6 h-6 animate-spin" />
            </div>
          ) : collaborators.length === 0 ? (
            <p className="text-center text-muted-foreground py-4">
              No collaborators yet
            </p>
          ) : (
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {collaborators.map((collab) => (
                <div
                  key={collab.id}
                  className="flex items-center justify-between p-3 rounded-lg bg-muted/50"
                >
                  <div className="flex items-center gap-2">
                    <Mail className="w-4 h-4 text-muted-foreground" />
                    <span className="text-sm truncate max-w-[180px]">
                      {collab.invited_email}
                    </span>
                    {getStatusBadge(collab.status)}
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="text-destructive hover:text-destructive"
                    onClick={() => removeCollaborator(collab.id)}
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>
              ))}
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default CollaboratorManager;

import { useCurrency } from "@/hooks/useCurrency";
import { useLanguage } from "@/contexts/LanguageContext";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle } from "lucide-react";

interface BudgetProgressProps {
  budget: number | null;
  spent: number;
  alertThreshold?: number;
  compact?: boolean;
}

const BudgetProgress = ({
  budget,
  spent,
  alertThreshold = 80,
  compact = false,
}: BudgetProgressProps) => {
  const { format } = useCurrency();
  const { t } = useLanguage();

  if (!budget) {
    return compact ? null : (
      <p className="text-xs text-muted-foreground">{t("project.noBudget")}</p>
    );
  }

  const percentage = Math.min((spent / budget) * 100, 100);
  const remaining = budget - spent;
  const isOverBudget = spent > budget;
  const isWarning = percentage >= alertThreshold && !isOverBudget;

  const getProgressColor = () => {
    if (isOverBudget) return "bg-destructive";
    if (isWarning) return "bg-warning";
    return "bg-success";
  };

  if (compact) {
    return (
      <div className="space-y-1">
        <div className="flex items-center justify-between text-xs">
          <span className="text-muted-foreground">{t("project.budget")}</span>
          <span className="font-medium">
            {format(spent)} / {format(budget)}
          </span>
        </div>
        <Progress value={percentage} className="h-1.5" />
        {(isOverBudget || isWarning) && (
          <div className="flex items-center gap-1 text-xs">
            <AlertTriangle className={`w-3 h-3 ${isOverBudget ? "text-destructive" : "text-warning"}`} />
            <span className={isOverBudget ? "text-destructive" : "text-warning"}>
              {isOverBudget ? t("project.overBudget") : t("project.budgetWarning")}
            </span>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="space-y-3 p-4 rounded-lg bg-muted/50">
      <div className="flex items-center justify-between">
        <span className="font-medium">{t("project.budget")}</span>
        {isOverBudget && (
          <Badge variant="destructive" className="flex items-center gap-1">
            <AlertTriangle className="w-3 h-3" />
            {t("project.overBudget")}
          </Badge>
        )}
        {isWarning && (
          <Badge className="bg-warning/10 text-warning border-warning/20 flex items-center gap-1">
            <AlertTriangle className="w-3 h-3" />
            {t("project.budgetWarning")}
          </Badge>
        )}
      </div>

      <Progress value={percentage} className={`h-3 ${getProgressColor()}`} />

      <div className="grid grid-cols-3 gap-4 text-center">
        <div>
          <p className="text-xs text-muted-foreground">{t("project.budget")}</p>
          <p className="font-bold">{format(budget)}</p>
        </div>
        <div>
          <p className="text-xs text-muted-foreground">{t("project.spent")}</p>
          <p className="font-bold">{format(spent)}</p>
        </div>
        <div>
          <p className="text-xs text-muted-foreground">{t("project.remaining")}</p>
          <p className={`font-bold ${remaining < 0 ? "text-destructive" : ""}`}>
            {format(Math.abs(remaining))}
            {remaining < 0 && " over"}
          </p>
        </div>
      </div>
    </div>
  );
};

export default BudgetProgress;

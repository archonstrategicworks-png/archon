import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useCurrency } from "@/hooks/useCurrency";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Activity, Receipt, FolderPlus, Upload, ArrowUpDown } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

interface ActivityItem {
  id: string;
  type: "expense" | "project" | "upload";
  title: string;
  subtitle?: string;
  amount?: number;
  created_at: string;
}

const RecentActivityWidget = () => {
  const [activities, setActivities] = useState<ActivityItem[]>([]);
  const [loading, setLoading] = useState(true);
  const { format } = useCurrency();

  useEffect(() => {
    const fetchActivity = async () => {
      try {
        // Fetch recent expenses with project names
        const { data: expenses } = await supabase
          .from("expenses")
          .select("id, category, vendor, amount, created_at, projects(project_name)")
          .order("created_at", { ascending: false })
          .limit(5);

        // Fetch recent projects
        const { data: projects } = await supabase
          .from("projects")
          .select("id, project_name, client, created_at")
          .order("created_at", { ascending: false })
          .limit(3);

        // Fetch recent uploads
        const { data: uploads } = await supabase
          .from("uploads")
          .select("id, file_name, file_type, uploaded_at")
          .order("uploaded_at", { ascending: false })
          .limit(3);

        const activityItems: ActivityItem[] = [
          ...(expenses || []).map((e: any) => ({
            id: e.id,
            type: "expense" as const,
            title: e.vendor || e.category,
            subtitle: e.projects?.project_name,
            amount: Number(e.amount),
            created_at: e.created_at,
          })),
          ...(projects || []).map((p: any) => ({
            id: p.id,
            type: "project" as const,
            title: p.project_name,
            subtitle: p.client,
            created_at: p.created_at,
          })),
          ...(uploads || []).map((u: any) => ({
            id: u.id,
            type: "upload" as const,
            title: u.file_name || "File Upload",
            subtitle: u.file_type,
            created_at: u.uploaded_at,
          })),
        ];

        // Sort by date and take top 8
        activityItems.sort(
          (a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
        );

        setActivities(activityItems.slice(0, 8));
      } catch (error) {
        console.error("Error fetching activity:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchActivity();
  }, []);

  const getIcon = (type: ActivityItem["type"]) => {
    switch (type) {
      case "expense":
        return <Receipt className="w-4 h-4" />;
      case "project":
        return <FolderPlus className="w-4 h-4" />;
      case "upload":
        return <Upload className="w-4 h-4" />;
    }
  };

  const getBadgeVariant = (type: ActivityItem["type"]) => {
    switch (type) {
      case "expense":
        return "default";
      case "project":
        return "secondary";
      case "upload":
        return "outline";
    }
  };

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="w-5 h-5" />
            Recent Activity
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="flex items-center gap-3 animate-pulse">
                <div className="w-8 h-8 bg-muted rounded-full" />
                <div className="flex-1">
                  <div className="h-4 bg-muted rounded w-3/4 mb-1" />
                  <div className="h-3 bg-muted rounded w-1/2" />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Activity className="w-5 h-5" />
          Recent Activity
        </CardTitle>
      </CardHeader>
      <CardContent>
        {activities.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <ArrowUpDown className="w-8 h-8 mx-auto mb-2 opacity-50" />
            <p>No recent activity</p>
          </div>
        ) : (
          <div className="space-y-4">
            {activities.map((activity) => (
              <div key={`${activity.type}-${activity.id}`} className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                  {getIcon(activity.type)}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="font-medium text-sm truncate">{activity.title}</p>
                    <Badge variant={getBadgeVariant(activity.type)} className="text-xs">
                      {activity.type}
                    </Badge>
                  </div>
                  <p className="text-xs text-muted-foreground truncate">
                    {activity.subtitle && `${activity.subtitle} • `}
                    {formatDistanceToNow(new Date(activity.created_at), { addSuffix: true })}
                  </p>
                </div>
                {activity.amount !== undefined && (
                  <p className="text-sm font-medium text-right">
                    {format(activity.amount)}
                  </p>
                )}
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default RecentActivityWidget;

import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useCurrency } from "@/hooks/useCurrency";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { PieChart, TrendingUp } from "lucide-react";

interface CategorySummary {
  category: string;
  total: number;
  count: number;
  percentage: number;
}

const CATEGORY_COLORS: Record<string, string> = {
  Materials: "#3B82F6",
  Labor: "#10B981",
  Equipment: "#F59E0B",
  Travel: "#8B5CF6",
  Office: "#EC4899",
  Utilities: "#06B6D4",
  Marketing: "#F97316",
  Other: "#6B7280",
};

const ExpenseSummaryWidget = () => {
  const [summaries, setSummaries] = useState<CategorySummary[]>([]);
  const [totalAmount, setTotalAmount] = useState(0);
  const [loading, setLoading] = useState(true);
  const { format } = useCurrency();

  useEffect(() => {
    const fetchSummary = async () => {
      try {
        const { data: expenses } = await supabase
          .from("expenses")
          .select("category, amount");

        if (!expenses || expenses.length === 0) {
          setSummaries([]);
          setTotalAmount(0);
          setLoading(false);
          return;
        }

        const categoryMap = new Map<string, { total: number; count: number }>();
        let total = 0;

        expenses.forEach((expense) => {
          const amount = Number(expense.amount);
          total += amount;
          const existing = categoryMap.get(expense.category) || { total: 0, count: 0 };
          categoryMap.set(expense.category, {
            total: existing.total + amount,
            count: existing.count + 1,
          });
        });

        const summaryList: CategorySummary[] = Array.from(categoryMap.entries())
          .map(([category, data]) => ({
            category,
            total: data.total,
            count: data.count,
            percentage: (data.total / total) * 100,
          }))
          .sort((a, b) => b.total - a.total)
          .slice(0, 6);

        setSummaries(summaryList);
        setTotalAmount(total);
      } catch (error) {
        console.error("Error fetching expense summary:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchSummary();
  }, []);

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <PieChart className="w-5 h-5" />
            Expense Summary
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="space-y-2 animate-pulse">
                <div className="flex justify-between">
                  <div className="h-4 bg-muted rounded w-24" />
                  <div className="h-4 bg-muted rounded w-16" />
                </div>
                <div className="h-2 bg-muted rounded" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <PieChart className="w-5 h-5" />
          Expense Summary
        </CardTitle>
      </CardHeader>
      <CardContent>
        {summaries.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <TrendingUp className="w-8 h-8 mx-auto mb-2 opacity-50" />
            <p>No expenses recorded yet</p>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="text-center pb-4 border-b border-border">
              <p className="text-sm text-muted-foreground">Total Expenses</p>
              <p className="text-2xl font-bold">{format(totalAmount)}</p>
            </div>

            {summaries.map((summary) => (
              <div key={summary.category} className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="font-medium flex items-center gap-2">
                    <span
                      className="w-3 h-3 rounded-full"
                      style={{ backgroundColor: CATEGORY_COLORS[summary.category] || "#6B7280" }}
                    />
                    {summary.category}
                  </span>
                  <span className="text-muted-foreground">
                    {format(summary.total)} ({summary.count})
                  </span>
                </div>
                <Progress
                  value={summary.percentage}
                  className="h-2"
                  style={{
                    // @ts-ignore
                    "--progress-color": CATEGORY_COLORS[summary.category] || "#6B7280",
                  }}
                />
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default ExpenseSummaryWidget;

import { Link } from "react-router-dom";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { FolderOpen, Calendar, TrendingUp } from "lucide-react";
import { format } from "date-fns";
import { useCurrency } from "@/hooks/useCurrency";
import { useLanguage } from "@/contexts/LanguageContext";
import BudgetProgress from "@/components/project/BudgetProgress";

interface ProjectCardProps {
  id: string;
  name: string;
  client: string | null;
  startDate: string | null;
  status: string;
  totalExpenses: number;
  expenseCount: number;
  budget?: number | null;
}

const ProjectCard = ({ 
  id, 
  name, 
  client, 
  startDate, 
  status, 
  totalExpenses,
  expenseCount,
  budget
}: ProjectCardProps) => {
  const { format: formatCurrency } = useCurrency();
  const { t } = useLanguage();

  const statusColors: Record<string, string> = {
    Active: "bg-success/10 text-success border-success/20",
    Completed: "bg-primary/10 text-primary border-primary/20",
    "On Hold": "bg-warning/10 text-warning border-warning/20",
  };

  return (
    <div className="bg-card rounded-xl p-6 card-shadow hover:card-shadow-lg transition-all duration-300 animate-slide-up group">
      <div className="flex items-start justify-between mb-4">
        <div className="p-3 rounded-xl bg-primary/10 text-primary group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
          <FolderOpen className="w-6 h-6" />
        </div>
        <Badge className={`${statusColors[status]} border`}>
          {status}
        </Badge>
      </div>
      
      <h3 className="font-display font-bold text-lg text-foreground mb-1 line-clamp-1">
        {name}
      </h3>
      {client && (
        <p className="text-sm text-muted-foreground mb-4">{client}</p>
      )}
      
      <div className="flex items-center gap-4 text-sm text-muted-foreground mb-4">
        {startDate && (
          <div className="flex items-center gap-1.5">
            <Calendar className="w-4 h-4" />
            <span>{format(new Date(startDate), "MMM dd, yyyy")}</span>
          </div>
        )}
      </div>

      {budget && (
        <div className="mb-4">
          <BudgetProgress budget={budget} spent={totalExpenses} compact />
        </div>
      )}

      <div className="border-t border-border pt-4 mb-4">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-muted-foreground">{t("dashboard.totalExpenses")}</p>
            <p className="text-xl font-bold text-foreground font-display">
              {formatCurrency(totalExpenses)}
            </p>
          </div>
          <div className="text-right">
            <p className="text-sm text-muted-foreground">{t("project.entries")}</p>
            <p className="text-xl font-bold text-foreground font-display">
              {expenseCount}
            </p>
          </div>
        </div>
      </div>

      <Link to={`/project/${id}`}>
        <Button variant="outline" className="w-full group-hover:bg-primary group-hover:text-primary-foreground group-hover:border-primary">
          <TrendingUp className="w-4 h-4 mr-2" />
          {t("project.viewLedger")}
        </Button>
      </Link>
    </div>
  );
};

export default ProjectCard;

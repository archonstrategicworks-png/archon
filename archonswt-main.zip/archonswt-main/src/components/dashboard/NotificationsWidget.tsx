import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useCurrency } from "@/hooks/useCurrency";
import { useLanguage } from "@/contexts/LanguageContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  Bell, 
  AlertTriangle, 
  UserPlus, 
  Check, 
  X,
  ChevronRight 
} from "lucide-react";
import { Link } from "react-router-dom";
import { useToast } from "@/hooks/use-toast";

interface BudgetAlert {
  type: "budget";
  projectId: string;
  projectName: string;
  percentage: number;
  isOverBudget: boolean;
}

interface InvitationNotification {
  type: "invitation";
  id: string;
  projectId: string;
  projectName: string;
  invitedBy: string;
  status: string;
}

type Notification = BudgetAlert | InvitationNotification;

const NotificationsWidget = () => {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);
  const { format } = useCurrency();
  const { t } = useLanguage();
  const { toast } = useToast();

  const fetchNotifications = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      // Fetch projects with budget alerts
      const { data: projects, error: projectsError } = await supabase
        .from("projects")
        .select("*")
        .eq("user_id", user.id);

      if (projectsError) throw projectsError;

      // Fetch expenses to calculate budget usage
      const { data: expenses, error: expensesError } = await supabase
        .from("expenses")
        .select("project_id, amount");

      if (expensesError) throw expensesError;

      // Calculate budget alerts
      const budgetAlerts: BudgetAlert[] = [];
      (projects || []).forEach((project) => {
        if (project.budget) {
          const projectExpenses = (expenses || []).filter(
            (e) => e.project_id === project.id
          );
          const totalSpent = projectExpenses.reduce(
            (sum, e) => sum + Number(e.amount),
            0
          );
          const percentage = (totalSpent / project.budget) * 100;
          const threshold = project.budget_alert_threshold || 80;

          if (percentage >= threshold) {
            budgetAlerts.push({
              type: "budget",
              projectId: project.id,
              projectName: project.project_name,
              percentage: Math.round(percentage),
              isOverBudget: percentage > 100,
            });
          }
        }
      });

      // Fetch pending invitations
      const { data: invitations, error: invitationsError } = await supabase
        .from("project_collaborators")
        .select("id, project_id, invited_by, status, projects(project_name)")
        .eq("user_id", user.id)
        .eq("status", "pending");

      if (invitationsError) throw invitationsError;

      const invitationNotifications: InvitationNotification[] = (
        invitations || []
      ).map((inv: any) => ({
        type: "invitation",
        id: inv.id,
        projectId: inv.project_id,
        projectName: inv.projects?.project_name || "Unknown Project",
        invitedBy: inv.invited_by,
        status: inv.status,
      }));

      setNotifications([...budgetAlerts, ...invitationNotifications]);
    } catch (error) {
      console.error("Error fetching notifications:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchNotifications();
  }, []);

  const handleInvitationResponse = async (
    invitationId: string,
    accept: boolean
  ) => {
    try {
      const { error } = await supabase
        .from("project_collaborators")
        .update({ status: accept ? "accepted" : "rejected" })
        .eq("id", invitationId);

      if (error) throw error;

      toast({
        title: accept ? "Invitation Accepted" : "Invitation Declined",
        description: accept
          ? "You now have access to this project"
          : "Invitation has been declined",
      });

      fetchNotifications();
    } catch (error) {
      console.error("Error responding to invitation:", error);
      toast({
        title: "Error",
        description: "Failed to process invitation",
        variant: "destructive",
      });
    }
  };

  if (loading) {
    return (
      <Card className="card-shadow">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bell className="w-5 h-5" />
            Notifications
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-16 w-full rounded-lg" />
          ))}
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="card-shadow">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Bell className="w-5 h-5" />
          Notifications
          {notifications.length > 0 && (
            <Badge variant="destructive" className="ml-2">
              {notifications.length}
            </Badge>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent>
        {notifications.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <Bell className="w-10 h-10 mx-auto mb-2 opacity-50" />
            <p>No notifications</p>
          </div>
        ) : (
          <div className="space-y-3">
            {notifications.map((notification, index) => (
              <div
                key={index}
                className="p-3 rounded-lg bg-muted/50 hover:bg-muted transition-colors"
              >
                {notification.type === "budget" && (
                  <div className="flex items-start gap-3">
                    <div
                      className={`p-2 rounded-lg ${
                        notification.isOverBudget
                          ? "bg-destructive/10 text-destructive"
                          : "bg-warning/10 text-warning"
                      }`}
                    >
                      <AlertTriangle className="w-4 h-4" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">
                        {notification.projectName}
                      </p>
                      <p
                        className={`text-xs ${
                          notification.isOverBudget
                            ? "text-destructive"
                            : "text-warning"
                        }`}
                      >
                        {notification.isOverBudget
                          ? `Over budget by ${notification.percentage - 100}%`
                          : `Budget usage at ${notification.percentage}%`}
                      </p>
                    </div>
                    <Link to={`/project/${notification.projectId}`}>
                      <Button variant="ghost" size="sm">
                        <ChevronRight className="w-4 h-4" />
                      </Button>
                    </Link>
                  </div>
                )}

                {notification.type === "invitation" && (
                  <div className="flex items-start gap-3">
                    <div className="p-2 rounded-lg bg-primary/10 text-primary">
                      <UserPlus className="w-4 h-4" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">
                        Project Invitation
                      </p>
                      <p className="text-xs text-muted-foreground">
                        You're invited to "{notification.projectName}"
                      </p>
                    </div>
                    <div className="flex gap-1">
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-8 w-8 p-0 text-success hover:text-success hover:bg-success/10"
                        onClick={() =>
                          handleInvitationResponse(notification.id, true)
                        }
                      >
                        <Check className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-8 w-8 p-0 text-destructive hover:text-destructive hover:bg-destructive/10"
                        onClick={() =>
                          handleInvitationResponse(notification.id, false)
                        }
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default NotificationsWidget;

import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { 
  FileText, 
  Upload, 
  Loader2, 
  CheckCircle, 
  AlertCircle,
  ArrowRight,
  TrendingDown,
  TrendingUp
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { format } from "date-fns";

interface Transaction {
  date: string;
  description: string;
  amount: string;
  type: "debit" | "credit";
  suggested_category: string;
}

interface BankStatementUploadProps {
  onTransactionsImported: () => void;
}

const BankStatementUpload = ({ onTransactionsImported }: BankStatementUploadProps) => {
  const { toast } = useToast();
  const { user } = useAuth();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const [processing, setProcessing] = useState(false);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [importing, setImporting] = useState(false);

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user) return;

    // Preview
    const reader = new FileReader();
    reader.onloadend = () => {
      setPreviewUrl(reader.result as string);
    };
    reader.readAsDataURL(file);

    // Upload and process
    setUploading(true);
    setTransactions([]);
    
    try {
      const fileExt = file.name.split(".").pop();
      const fileName = `${user.id}/bank-statements/${Date.now()}.${fileExt}`;

      const { error: uploadError } = await supabase.storage
        .from("receipts")
        .upload(fileName, file);

      if (uploadError) throw uploadError;

      const { data: urlData } = supabase.storage
        .from("receipts")
        .getPublicUrl(fileName);

      // Save to uploads table
      await supabase.from("uploads").insert({
        file_type: "Bank Statement",
        file_url: urlData.publicUrl,
        file_name: file.name,
        user_id: user.id,
      });

      toast({
        title: "Upload Complete",
        description: "Processing bank statement with AI...",
      });

      // Process with AI
      setProcessing(true);
      const base64 = await new Promise<string>((resolve) => {
        const r = new FileReader();
        r.onloadend = () => resolve((r.result as string).split(",")[1]);
        r.readAsDataURL(file);
      });

      const { data, error } = await supabase.functions.invoke("process-bank-statement", {
        body: { image: base64 },
      });

      if (error) throw error;

      if (data?.transactions && data.transactions.length > 0) {
        setTransactions(data.transactions);
        toast({
          title: "Statement Processed",
          description: `Found ${data.transactions.length} transactions.`,
        });
      } else if (data?.error) {
        toast({
          title: "Processing Issue",
          description: data.error,
          variant: "destructive",
        });
      } else {
        toast({
          title: "No Transactions Found",
          description: "Could not detect any transactions in this statement.",
          variant: "destructive",
        });
      }
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to process bank statement.",
        variant: "destructive",
      });
    } finally {
      setUploading(false);
      setProcessing(false);
    }
  };

  const importTransactions = async () => {
    if (!user || transactions.length === 0) return;

    setImporting(true);
    try {
      // Only import debit transactions (expenses)
      const debitTransactions = transactions.filter(t => t.type === "debit");
      
      const bankTransactionsToInsert = debitTransactions.map(t => ({
        date: t.date,
        description: t.description,
        amount: parseFloat(t.amount),
        user_id: user.id,
        confidence_score: 0.85, // AI confidence
      }));

      const { error } = await supabase
        .from("bank_transactions")
        .insert(bankTransactionsToInsert);

      if (error) throw error;

      toast({
        title: "Transactions Imported",
        description: `${debitTransactions.length} transactions added for matching.`,
      });

      resetUpload();
      onTransactionsImported();
    } catch (error: any) {
      toast({
        title: "Import Failed",
        description: error.message || "Failed to import transactions.",
        variant: "destructive",
      });
    } finally {
      setImporting(false);
    }
  };

  const resetUpload = () => {
    setPreviewUrl(null);
    setTransactions([]);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const formatCurrency = (amount: string) => {
    return new Intl.NumberFormat("en-IN", {
      style: "currency",
      currency: "INR",
      maximumFractionDigits: 0,
    }).format(parseFloat(amount));
  };

  const totalDebits = transactions
    .filter(t => t.type === "debit")
    .reduce((sum, t) => sum + parseFloat(t.amount), 0);

  const totalCredits = transactions
    .filter(t => t.type === "credit")
    .reduce((sum, t) => sum + parseFloat(t.amount), 0);

  return (
    <div className="space-y-6">
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileSelect}
        accept="image/*,.pdf"
        className="hidden"
      />

      {!previewUrl ? (
        <Button
          size="lg"
          variant="outline"
          onClick={() => fileInputRef.current?.click()}
          disabled={uploading}
          className="w-full h-32 flex-col gap-3 border-dashed border-2"
        >
          <FileText className="w-8 h-8" />
          <span className="text-base">Upload Bank Statement</span>
          <span className="text-sm text-muted-foreground">PDF or Image</span>
        </Button>
      ) : (
        <div className="space-y-6">
          {/* Preview */}
          <Card className="overflow-hidden">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-lg">
                <FileText className="w-5 h-5 text-primary" />
                Statement Preview
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="relative aspect-[16/9] rounded-lg overflow-hidden bg-muted">
                <img
                  src={previewUrl}
                  alt="Bank statement preview"
                  className="w-full h-full object-contain"
                />
                {(uploading || processing) && (
                  <div className="absolute inset-0 bg-background/80 flex items-center justify-center">
                    <div className="text-center space-y-3">
                      <Loader2 className="w-10 h-10 animate-spin text-primary mx-auto" />
                      <p className="font-medium">
                        {uploading ? "Uploading..." : "Extracting transactions with AI..."}
                      </p>
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Transactions Found */}
          {transactions.length > 0 && (
            <Card className="border-green-500/30 bg-green-50/50">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2 text-lg text-green-700">
                    <CheckCircle className="w-5 h-5" />
                    {transactions.length} Transactions Found
                  </CardTitle>
                  <div className="flex gap-4 text-sm">
                    <span className="flex items-center gap-1 text-red-600">
                      <TrendingDown className="w-4 h-4" />
                      Debits: {formatCurrency(totalDebits.toString())}
                    </span>
                    <span className="flex items-center gap-1 text-green-600">
                      <TrendingUp className="w-4 h-4" />
                      Credits: {formatCurrency(totalCredits.toString())}
                    </span>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="rounded-lg border overflow-hidden mb-4">
                  <Table>
                    <TableHeader>
                      <TableRow className="bg-muted/50">
                        <TableHead>Date</TableHead>
                        <TableHead>Description</TableHead>
                        <TableHead>Category</TableHead>
                        <TableHead className="text-right">Amount</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {transactions.slice(0, 10).map((t, idx) => (
                        <TableRow key={idx}>
                          <TableCell className="font-medium">
                            {format(new Date(t.date), "MMM dd")}
                          </TableCell>
                          <TableCell className="max-w-[200px] truncate">
                            {t.description}
                          </TableCell>
                          <TableCell>
                            <Badge variant="secondary" className="text-xs">
                              {t.suggested_category}
                            </Badge>
                          </TableCell>
                          <TableCell className={`text-right font-bold ${
                            t.type === "debit" ? "text-red-600" : "text-green-600"
                          }`}>
                            {t.type === "debit" ? "-" : "+"}{formatCurrency(t.amount)}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>

                {transactions.length > 10 && (
                  <p className="text-sm text-muted-foreground text-center mb-4">
                    Showing 10 of {transactions.length} transactions
                  </p>
                )}

                <div className="flex gap-3">
                  <Button
                    onClick={importTransactions}
                    disabled={importing}
                    className="flex-1"
                  >
                    {importing ? (
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    ) : (
                      <ArrowRight className="w-4 h-4 mr-2" />
                    )}
                    Import {transactions.filter(t => t.type === "debit").length} Debit Transactions
                  </Button>
                  <Button variant="outline" onClick={resetUpload}>
                    Cancel
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* No transactions but finished processing */}
          {transactions.length === 0 && !processing && !uploading && (
            <Card className="border-yellow-500/30 bg-yellow-50/50">
              <CardContent className="pt-6">
                <div className="flex items-center gap-3 text-yellow-700">
                  <AlertCircle className="w-5 h-5" />
                  <div>
                    <p className="font-medium">No transactions detected</p>
                    <p className="text-sm">Try uploading a clearer image of your bank statement.</p>
                  </div>
                </div>
                <Button variant="outline" onClick={resetUpload} className="mt-4">
                  Try Another File
                </Button>
              </CardContent>
            </Card>
          )}
        </div>
      )}
    </div>
  );
};

export default BankStatementUpload;

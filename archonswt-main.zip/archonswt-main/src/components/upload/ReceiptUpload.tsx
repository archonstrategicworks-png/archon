import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Camera, Upload, FileImage, Loader2, CheckCircle } from "lucide-react";
import ExpenseForm from "@/components/forms/ExpenseForm";

interface ReceiptUploadProps {
  projectId: string;
  onSuccess: () => void;
}

interface ExtractedData {
  date: string;
  amount: string;
  vendor: string;
}

const ReceiptUpload = ({ projectId, onSuccess }: ReceiptUploadProps) => {
  const { toast } = useToast();
  const { user } = useAuth();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const [processing, setProcessing] = useState(false);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [extractedData, setExtractedData] = useState<ExtractedData | null>(null);

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user) return;

    // Preview
    const reader = new FileReader();
    reader.onloadend = () => {
      setPreviewUrl(reader.result as string);
    };
    reader.readAsDataURL(file);

    // Upload and process
    setUploading(true);
    try {
      const fileExt = file.name.split(".").pop();
      const fileName = `${user.id}/${Date.now()}.${fileExt}`;
      const filePath = fileName;

      const { error: uploadError } = await supabase.storage
        .from("receipts")
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      // Use signed URL since bucket is private
      const { data: urlData, error: urlError } = await supabase.storage
        .from("receipts")
        .createSignedUrl(filePath, 60 * 60 * 24 * 365); // 1 year expiry

      if (urlError) throw urlError;

      // Save to uploads table
      await supabase.from("uploads").insert({
        file_type: "Receipt",
        file_url: urlData?.signedUrl || '',
        file_name: file.name,
        user_id: user.id,
      });

      toast({
        title: "Upload Complete",
        description: "Processing receipt with AI...",
      });

      // Process with AI
      setProcessing(true);
      const base64 = await new Promise<string>((resolve) => {
        const r = new FileReader();
        r.onloadend = () => resolve((r.result as string).split(",")[1]);
        r.readAsDataURL(file);
      });

      const { data, error } = await supabase.functions.invoke("process-receipt", {
        body: { image: base64 },
      });

      if (error) throw error;

      if (data?.extracted) {
        setExtractedData(data.extracted);
        toast({
          title: "Receipt Processed",
          description: "Review the extracted data below.",
        });
      }
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to process receipt.",
        variant: "destructive",
      });
    } finally {
      setUploading(false);
      setProcessing(false);
    }
  };

  const resetUpload = () => {
    setPreviewUrl(null);
    setExtractedData(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const handleSuccess = () => {
    resetUpload();
    onSuccess();
  };

  return (
    <div className="space-y-6">
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileSelect}
        accept="image/*"
        capture="environment"
        className="hidden"
      />

      {!previewUrl ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Button
            size="lg"
            variant="navy"
            onClick={() => fileInputRef.current?.click()}
            disabled={uploading}
            className="h-32 flex-col gap-3"
          >
            <Camera className="w-8 h-8" />
            <span className="text-base">Take Photo</span>
          </Button>
          <Button
            size="lg"
            variant="outline"
            onClick={() => fileInputRef.current?.click()}
            disabled={uploading}
            className="h-32 flex-col gap-3"
          >
            <Upload className="w-8 h-8" />
            <span className="text-base">Upload File</span>
          </Button>
        </div>
      ) : (
        <div className="space-y-6">
          <Card className="overflow-hidden">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-lg">
                <FileImage className="w-5 h-5 text-primary" />
                Receipt Preview
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="relative aspect-[4/3] rounded-lg overflow-hidden bg-muted">
                <img
                  src={previewUrl}
                  alt="Receipt preview"
                  className="w-full h-full object-contain"
                />
                {(uploading || processing) && (
                  <div className="absolute inset-0 bg-background/80 flex items-center justify-center">
                    <div className="text-center space-y-3">
                      <Loader2 className="w-10 h-10 animate-spin text-primary mx-auto" />
                      <p className="font-medium">
                        {uploading ? "Uploading..." : "Extracting data with AI..."}
                      </p>
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {extractedData && (
            <Card className="border-green-500/30 bg-green-50/50">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-lg text-green-700">
                  <CheckCircle className="w-5 h-5" />
                  Extracted Data - Review & Confirm
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ExpenseForm
                  projectId={projectId}
                  onSuccess={handleSuccess}
                  onCancel={resetUpload}
                  initialData={extractedData}
                />
              </CardContent>
            </Card>
          )}

          {!extractedData && !uploading && !processing && (
            <Button variant="outline" onClick={resetUpload} className="w-full">
              Upload Another Receipt
            </Button>
          )}
        </div>
      )}
    </div>
  );
};

export default ReceiptUpload;

import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useLanguage } from "@/contexts/LanguageContext";
import { useCurrency } from "@/hooks/useCurrency";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Mail, Loader2, Send } from "lucide-react";

interface Expense {
  date: string;
  category: string;
  vendor: string | null;
  amount: number;
  payment_method: string;
}

interface EmailReportDialogProps {
  projectId?: string;
  projectName?: string;
  expenses: Expense[];
  totalAmount: number;
}

const EmailReportDialog = ({
  projectId,
  projectName,
  expenses,
  totalAmount,
}: EmailReportDialogProps) => {
  const { t } = useLanguage();
  const { format } = useCurrency();
  const { toast } = useToast();
  const [isOpen, setIsOpen] = useState(false);
  const [sending, setSending] = useState(false);
  const [recipientEmail, setRecipientEmail] = useState("");
  const [subject, setSubject] = useState(
    projectName ? `Expense Report: ${projectName}` : "Expense Report"
  );
  const [message, setMessage] = useState("");
  const [reportType, setReportType] = useState<"full" | "summary">("summary");

  const handleSend = async () => {
    if (!recipientEmail.trim()) {
      toast({
        title: t("common.error"),
        description: "Please enter a recipient email",
        variant: "destructive",
      });
      return;
    }

    setSending(true);
    try {
      const { error } = await supabase.functions.invoke("send-report-email", {
        body: {
          type: "report",
          recipientEmail: recipientEmail.trim(),
          subject,
          message,
          projectName: projectName || "All Projects",
          reportType,
          expenses: reportType === "full" ? expenses : undefined,
          summary: {
            totalAmount: format(totalAmount),
            expenseCount: expenses.length,
            categoryBreakdown: expenses.reduce((acc, e) => {
              acc[e.category] = (acc[e.category] || 0) + Number(e.amount);
              return acc;
            }, {} as Record<string, number>),
          },
        },
      });

      if (error) throw error;

      toast({
        title: t("common.success"),
        description: t("email.success"),
      });
      setIsOpen(false);
      setRecipientEmail("");
      setMessage("");
    } catch (error: any) {
      toast({
        title: t("common.error"),
        description: error.message || "Failed to send email",
        variant: "destructive",
      });
    } finally {
      setSending(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm">
          <Mail className="w-4 h-4 mr-2" />
          {t("email.sendReport")}
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Mail className="w-5 h-5" />
            {t("email.sendReport")}
          </DialogTitle>
          <DialogDescription>
            Send expense report via email
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="recipient">{t("email.recipient")}</Label>
            <Input
              id="recipient"
              type="email"
              value={recipientEmail}
              onChange={(e) => setRecipientEmail(e.target.value)}
              placeholder="recipient@example.com"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="subject">{t("email.subject")}</Label>
            <Input
              id="subject"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label>Report Type</Label>
            <Select value={reportType} onValueChange={(v) => setReportType(v as "full" | "summary")}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="summary">Summary Only</SelectItem>
                <SelectItem value="full">{t("email.fullReport")}</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="message">Additional Message (Optional)</Label>
            <Textarea
              id="message"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Add any additional notes..."
              rows={3}
            />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => setIsOpen(false)}>
            {t("common.cancel")}
          </Button>
          <Button onClick={handleSend} disabled={sending}>
            {sending ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                {t("email.sending")}
              </>
            ) : (
              <>
                <Send className="w-4 h-4 mr-2" />
                Send
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default EmailReportDialog;

import { useState, useEffect } from 'react';
import { Bell, BellOff, Mail, Loader2, AlertCircle } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { usePushNotifications } from '@/hooks/usePushNotifications';
import { useAuth } from '@/contexts/AuthContext';
import { useProfile } from '@/hooks/useProfile';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export const NotificationPreferences = () => {
  const { user } = useAuth();
  const { profile, refetchProfile } = useProfile();
  const { isSupported, permission, isSubscribed, isLoading: pushLoading, subscribe, unsubscribe } = usePushNotifications();
  
  const [emailEnabled, setEmailEnabled] = useState(true);
  const [notificationEmail, setNotificationEmail] = useState('');
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    if (profile) {
      setEmailEnabled((profile as any).email_notifications_enabled ?? true);
      setNotificationEmail((profile as any).notification_email || user?.email || '');
    }
  }, [profile, user]);

  const handlePushToggle = async () => {
    if (isSubscribed) {
      await unsubscribe();
    } else {
      await subscribe();
    }
  };

  const handleEmailToggle = async (enabled: boolean) => {
    setEmailEnabled(enabled);
    await saveEmailPreferences(enabled, notificationEmail);
  };

  const saveEmailPreferences = async (enabled: boolean, email: string) => {
    if (!user) return;
    
    setIsSaving(true);
    try {
      const { error } = await supabase
        .from('profiles')
        .update({
          email_notifications_enabled: enabled,
          notification_email: email
        })
        .eq('user_id', user.id);

      if (error) throw error;
      toast.success('Notification preferences saved');
      refetchProfile();
    } catch (error) {
      console.error('Error saving preferences:', error);
      toast.error('Failed to save preferences');
    } finally {
      setIsSaving(false);
    }
  };

  const handleEmailSave = () => {
    saveEmailPreferences(emailEnabled, notificationEmail);
  };

  if (!user) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bell className="h-5 w-5" />
            Notification Preferences
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">
            Please log in to manage notification settings.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Bell className="h-5 w-5 text-gold" />
          Notification Preferences
        </CardTitle>
        <CardDescription>
          Choose how you want to receive notifications
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Push Notifications Section */}
        <div className="space-y-4">
          <h4 className="font-medium flex items-center gap-2">
            <Bell className="h-4 w-4" />
            Push Notifications
          </h4>
          
          {!isSupported ? (
            <div className="flex items-center gap-2 text-muted-foreground p-3 bg-muted rounded-lg">
              <AlertCircle className="h-4 w-4" />
              <p className="text-sm">
                Push notifications are not supported in this browser.
              </p>
            </div>
          ) : permission === 'denied' ? (
            <div className="flex items-start gap-2 p-3 bg-destructive/10 border border-destructive/20 rounded-lg">
              <AlertCircle className="h-4 w-4 text-destructive mt-0.5" />
              <div className="text-sm">
                <p className="font-medium text-destructive">Notifications Blocked</p>
                <p className="text-muted-foreground mt-1">
                  Enable notifications in your browser settings.
                </p>
              </div>
            </div>
          ) : (
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="push-notifications" className="text-base">
                  Browser Push Notifications
                </Label>
                <p className="text-sm text-muted-foreground">
                  Receive instant alerts in your browser
                </p>
              </div>
              <div className="flex items-center gap-2">
                {pushLoading && <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />}
                <Switch
                  id="push-notifications"
                  checked={isSubscribed}
                  onCheckedChange={handlePushToggle}
                  disabled={pushLoading}
                />
              </div>
            </div>
          )}
          
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <span className={`h-2 w-2 rounded-full ${isSubscribed ? 'bg-green-500' : 'bg-muted-foreground'}`} />
            {isSubscribed ? 'Push notifications enabled' : 'Push notifications disabled'}
          </div>
        </div>

        <Separator />

        {/* Email Notifications Section */}
        <div className="space-y-4">
          <h4 className="font-medium flex items-center gap-2">
            <Mail className="h-4 w-4" />
            Email Notifications
          </h4>
          
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="email-notifications" className="text-base">
                Email Notifications
              </Label>
              <p className="text-sm text-muted-foreground">
                Receive updates via email
              </p>
            </div>
            <div className="flex items-center gap-2">
              {isSaving && <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />}
              <Switch
                id="email-notifications"
                checked={emailEnabled}
                onCheckedChange={handleEmailToggle}
                disabled={isSaving}
              />
            </div>
          </div>

          {emailEnabled && (
            <div className="space-y-2">
              <Label htmlFor="notification-email">Notification Email</Label>
              <div className="flex gap-2">
                <Input
                  id="notification-email"
                  type="email"
                  value={notificationEmail}
                  onChange={(e) => setNotificationEmail(e.target.value)}
                  placeholder="your@email.com"
                  className="flex-1"
                />
                <Button 
                  onClick={handleEmailSave}
                  disabled={isSaving}
                  size="sm"
                >
                  Save
                </Button>
              </div>
              <p className="text-xs text-muted-foreground">
                This email will be used for all notification emails.
              </p>
            </div>
          )}
          
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <span className={`h-2 w-2 rounded-full ${emailEnabled ? 'bg-green-500' : 'bg-muted-foreground'}`} />
            {emailEnabled ? 'Email notifications enabled' : 'Email notifications disabled'}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

import { useState, useEffect } from 'react';
import { Bell, BellOff, X, Shield } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { usePushNotifications } from '@/hooks/usePushNotifications';
import { useAuth } from '@/contexts/AuthContext';
import { motion, AnimatePresence } from 'framer-motion';

export const PushNotificationConsent = () => {
  const { user } = useAuth();
  const { isSupported, permission, isSubscribed, isLoading, subscribe, unsubscribe } = usePushNotifications();
  const [showPrompt, setShowPrompt] = useState(false);
  const [dismissed, setDismissed] = useState(false);

  useEffect(() => {
    // Show prompt after 3 seconds if user is logged in, notifications are supported,
    // and user hasn't subscribed or dismissed
    const timer = setTimeout(() => {
      if (user && isSupported && permission === 'default' && !isSubscribed && !dismissed) {
        const hasSeenPrompt = localStorage.getItem('push_notification_prompt_seen');
        if (!hasSeenPrompt) {
          setShowPrompt(true);
        }
      }
    }, 3000);

    return () => clearTimeout(timer);
  }, [user, isSupported, permission, isSubscribed, dismissed]);

  const handleAccept = async () => {
    await subscribe();
    setShowPrompt(false);
    localStorage.setItem('push_notification_prompt_seen', 'true');
  };

  const handleDismiss = () => {
    setShowPrompt(false);
    setDismissed(true);
    localStorage.setItem('push_notification_prompt_seen', 'true');
  };

  if (!showPrompt) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: 50 }}
        className="fixed bottom-4 right-4 z-50 max-w-sm"
      >
        <Card className="bg-card border-2 border-gold/30 p-4 shadow-lg shadow-gold/10">
          <div className="flex items-start gap-3">
            <div className="p-2 bg-gold/20 rounded-full">
              <Bell className="h-5 w-5 text-gold" />
            </div>
            <div className="flex-1">
              <div className="flex items-center justify-between mb-2">
                <h4 className="font-semibold text-foreground">Enable Notifications</h4>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-6 w-6 -mt-1 -mr-1"
                  onClick={handleDismiss}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
              <p className="text-sm text-muted-foreground mb-3">
                Stay informed about budget alerts, expense updates, and important project notifications.
              </p>
              <div className="flex items-center gap-2 text-xs text-muted-foreground mb-3">
                <Shield className="h-3 w-3" />
                <span>Your data is secure and encrypted</span>
              </div>
              <div className="flex gap-2">
                <Button
                  size="sm"
                  onClick={handleAccept}
                  disabled={isLoading}
                  className="bg-gold hover:bg-gold/90 text-primary"
                >
                  {isLoading ? 'Enabling...' : 'Enable'}
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={handleDismiss}
                >
                  Not Now
                </Button>
              </div>
            </div>
          </div>
        </Card>
      </motion.div>
    </AnimatePresence>
  );
};

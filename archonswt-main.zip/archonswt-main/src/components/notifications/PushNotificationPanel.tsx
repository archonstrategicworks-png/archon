import { useState, useEffect } from 'react';
import { Bell, Send, Users, History, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';
import { format } from 'date-fns';

interface NotificationHistory {
  id: string;
  title: string;
  body: string;
  sent_to_count: number;
  created_at: string;
}

export const PushNotificationPanel = () => {
  const { user } = useAuth();
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [subscriberCount, setSubscriberCount] = useState(0);
  const [history, setHistory] = useState<NotificationHistory[]>([]);
  const [isLoadingHistory, setIsLoadingHistory] = useState(true);

  useEffect(() => {
    fetchSubscriberCount();
    fetchHistory();
  }, []);

  const fetchSubscriberCount = async () => {
    const { count, error } = await supabase
      .from('push_subscriptions')
      .select('*', { count: 'exact', head: true });

    if (!error && count !== null) {
      setSubscriberCount(count);
    }
  };

  const fetchHistory = async () => {
    setIsLoadingHistory(true);
    const { data, error } = await supabase
      .from('push_notifications')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(10);

    if (!error && data) {
      setHistory(data);
    }
    setIsLoadingHistory(false);
  };

  const sendNotification = async () => {
    if (!user || !title.trim() || !body.trim()) {
      toast.error('Please fill in title and message');
      return;
    }

    setIsSending(true);
    try {
      // Get all subscriptions
      const { data: subscriptions, error: subError } = await supabase
        .from('push_subscriptions')
        .select('*');

      if (subError) throw subError;

      // For browser-based push, we'll simulate sending by storing the notification
      // In production, you'd use a backend service to send actual push notifications
      const { error: notifError } = await supabase
        .from('push_notifications')
        .insert({
          sender_id: user.id,
          title: title.trim(),
          body: body.trim(),
          sent_to_count: subscriptions?.length || 0
        });

      if (notifError) throw notifError;

      // Show local notification for demo purposes
      if ('Notification' in window && Notification.permission === 'granted') {
        new Notification(title, {
          body: body,
          icon: '/favicon.ico'
        });
      }

      toast.success(`Notification sent to ${subscriptions?.length || 0} subscribers`);
      setTitle('');
      setBody('');
      fetchHistory();
    } catch (error) {
      console.error('Error sending notification:', error);
      toast.error('Failed to send notification');
    } finally {
      setIsSending(false);
    }
  };

  return (
    <div className="grid gap-6 md:grid-cols-2">
      {/* Send Notification Card */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bell className="h-5 w-5 text-gold" />
            Send Push Notification
          </CardTitle>
          <CardDescription>
            Broadcast a notification to all subscribed users
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center gap-2 p-3 bg-muted rounded-lg">
            <Users className="h-4 w-4 text-muted-foreground" />
            <span className="text-sm text-muted-foreground">
              <span className="font-medium text-foreground">{subscriberCount}</span> subscribers
            </span>
          </div>

          <div className="space-y-2">
            <Label htmlFor="notification-title">Title</Label>
            <Input
              id="notification-title"
              placeholder="Notification title..."
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              maxLength={100}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="notification-body">Message</Label>
            <Textarea
              id="notification-body"
              placeholder="Notification message..."
              value={body}
              onChange={(e) => setBody(e.target.value)}
              rows={4}
              maxLength={500}
            />
          </div>

          <Button
            onClick={sendNotification}
            disabled={isSending || !title.trim() || !body.trim()}
            className="w-full bg-gold hover:bg-gold/90 text-primary"
          >
            {isSending ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Sending...
              </>
            ) : (
              <>
                <Send className="mr-2 h-4 w-4" />
                Send Notification
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      {/* Notification History Card */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <History className="h-5 w-5 text-gold" />
            Recent Notifications
          </CardTitle>
          <CardDescription>
            History of sent push notifications
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoadingHistory ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
            </div>
          ) : history.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <Bell className="h-8 w-8 mx-auto mb-2 opacity-50" />
              <p>No notifications sent yet</p>
            </div>
          ) : (
            <ScrollArea className="h-[300px]">
              <div className="space-y-4">
                {history.map((item, index) => (
                  <div key={item.id}>
                    <div className="space-y-1">
                      <div className="flex items-start justify-between gap-2">
                        <h4 className="font-medium text-sm line-clamp-1">{item.title}</h4>
                        <Badge variant="secondary" className="shrink-0">
                          {item.sent_to_count} sent
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground line-clamp-2">{item.body}</p>
                      <p className="text-xs text-muted-foreground">
                        {format(new Date(item.created_at), 'MMM d, yyyy HH:mm')}
                      </p>
                    </div>
                    {index < history.length - 1 && <Separator className="mt-4" />}
                  </div>
                ))}
              </div>
            </ScrollArea>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

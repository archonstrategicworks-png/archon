import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useCurrency } from "@/hooks/useCurrency";
import { generatePDFReport } from "@/lib/pdfExport";
import { FileDown, Loader2, FileText } from "lucide-react";

interface ReportTemplate {
  id: string;
  name: string;
  description: string | null;
  columns: string[];
  group_by: string | null;
  include_charts: boolean;
  date_range: string;
}

interface Project {
  id: string;
  project_name: string;
}

interface Expense {
  id: string;
  date: string;
  amount: number;
  category: string;
  vendor: string | null;
  payment_method: string;
  notes: string | null;
  tags?: string[] | null;
  approval_status?: string;
  project_id: string;
}

const PDFExportDialog = () => {
  const { toast } = useToast();
  const { user } = useAuth();
  const { currency } = useCurrency();
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [templates, setTemplates] = useState<ReportTemplate[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [selectedTemplate, setSelectedTemplate] = useState<string>("");
  const [selectedProject, setSelectedProject] = useState<string>("");

  useEffect(() => {
    if (open) {
      fetchData();
    }
  }, [open]);

  const fetchData = async () => {
    if (!user) return;
    setLoading(true);
    try {
      const [templatesRes, projectsRes] = await Promise.all([
        supabase.from("report_templates").select("*").order("name"),
        supabase.from("projects").select("id, project_name").order("project_name"),
      ]);

      if (templatesRes.error) throw templatesRes.error;
      if (projectsRes.error) throw projectsRes.error;

      setTemplates(templatesRes.data || []);
      setProjects(projectsRes.data || []);
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleExport = async () => {
    if (!selectedTemplate || !selectedProject) {
      toast({
        title: "Missing Selection",
        description: "Please select both a template and a project",
        variant: "destructive",
      });
      return;
    }

    setExporting(true);
    try {
      const template = templates.find((t) => t.id === selectedTemplate);
      const project = projects.find((p) => p.id === selectedProject);

      if (!template || !project) throw new Error("Invalid selection");

      const { data: expenses, error } = await supabase
        .from("expenses")
        .select("*")
        .eq("project_id", selectedProject)
        .order("date", { ascending: false });

      if (error) throw error;

      const totalAmount = (expenses || []).reduce((sum, e) => sum + Number(e.amount), 0);

      generatePDFReport({
        template,
        expenses: expenses || [],
        projectName: project.project_name,
        totalAmount,
        currency,
      });

      toast({
        title: "PDF Generated",
        description: "Your report has been downloaded",
      });
      setOpen(false);
    } catch (error: any) {
      toast({
        title: "Export Failed",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setExporting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline">
          <FileDown className="w-4 h-4 mr-2" />
          Export PDF
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5" />
            Export PDF Report
          </DialogTitle>
        </DialogHeader>

        {loading ? (
          <div className="py-8 flex items-center justify-center">
            <Loader2 className="w-6 h-6 animate-spin" />
          </div>
        ) : templates.length === 0 ? (
          <div className="py-8 text-center text-muted-foreground">
            <FileText className="w-10 h-10 mx-auto mb-2 opacity-50" />
            <p>No templates available.</p>
            <p className="text-sm">Create a template first in the Templates tab.</p>
          </div>
        ) : (
          <div className="space-y-4 pt-4">
            <div className="space-y-2">
              <Label>Select Template</Label>
              <Select value={selectedTemplate} onValueChange={setSelectedTemplate}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose a template" />
                </SelectTrigger>
                <SelectContent>
                  {templates.map((template) => (
                    <SelectItem key={template.id} value={template.id}>
                      {template.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {selectedTemplate && (
                <p className="text-xs text-muted-foreground">
                  {templates.find((t) => t.id === selectedTemplate)?.description}
                </p>
              )}
            </div>

            <div className="space-y-2">
              <Label>Select Project</Label>
              <Select value={selectedProject} onValueChange={setSelectedProject}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose a project" />
                </SelectTrigger>
                <SelectContent>
                  {projects.map((project) => (
                    <SelectItem key={project.id} value={project.id}>
                      {project.project_name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <Button
              onClick={handleExport}
              disabled={!selectedTemplate || !selectedProject || exporting}
              className="w-full"
            >
              {exporting ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  <FileDown className="w-4 h-4 mr-2" />
                  Generate PDF
                </>
              )}
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};

export default PDFExportDialog;

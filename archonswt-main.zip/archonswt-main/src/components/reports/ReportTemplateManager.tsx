import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { 
  FileText, 
  Plus, 
  Trash2, 
  Edit, 
  Copy,
  Save,
  Loader2,
  BarChart3
} from "lucide-react";

interface ReportTemplate {
  id: string;
  name: string;
  description: string | null;
  columns: string[];
  filters: unknown;
  group_by: string | null;
  include_charts: boolean;
  date_range: string;
  created_at: string;
}

const AVAILABLE_COLUMNS = [
  { id: "date", label: "Date" },
  { id: "vendor", label: "Vendor" },
  { id: "category", label: "Category" },
  { id: "amount", label: "Amount" },
  { id: "payment_method", label: "Payment Method" },
  { id: "notes", label: "Notes" },
  { id: "tags", label: "Tags" },
  { id: "approval_status", label: "Approval Status" },
];

const DATE_RANGES = [
  { id: "all", label: "All Time" },
  { id: "today", label: "Today" },
  { id: "week", label: "This Week" },
  { id: "month", label: "This Month" },
  { id: "quarter", label: "This Quarter" },
  { id: "year", label: "This Year" },
];

const GROUP_BY_OPTIONS = [
  { id: "", label: "None" },
  { id: "category", label: "Category" },
  { id: "payment_method", label: "Payment Method" },
  { id: "vendor", label: "Vendor" },
  { id: "date", label: "Date" },
];

const ReportTemplateManager = () => {
  const { toast } = useToast();
  const { user } = useAuth();
  const [templates, setTemplates] = useState<ReportTemplate[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingTemplate, setEditingTemplate] = useState<ReportTemplate | null>(null);

  const [formData, setFormData] = useState({
    name: "",
    description: "",
    columns: ["date", "vendor", "category", "amount"],
    group_by: "",
    include_charts: false,
    date_range: "month",
  });

  useEffect(() => {
    fetchTemplates();
  }, []);

  const fetchTemplates = async () => {
    if (!user) return;
    try {
      const { data, error } = await supabase
        .from("report_templates")
        .select("*")
        .order("created_at", { ascending: false });

      if (error) throw error;
      setTemplates(data || []);
    } catch (error) {
      console.error("Error fetching templates:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    if (!user || !formData.name.trim()) {
      toast({
        title: "Error",
        description: "Template name is required",
        variant: "destructive",
      });
      return;
    }

    setSaving(true);
    try {
      const templateData = {
        user_id: user.id,
        name: formData.name,
        description: formData.description || null,
        columns: formData.columns,
        group_by: formData.group_by || null,
        include_charts: formData.include_charts,
        date_range: formData.date_range,
        filters: {},
      };

      if (editingTemplate) {
        const { error } = await supabase
          .from("report_templates")
          .update(templateData)
          .eq("id", editingTemplate.id);

        if (error) throw error;
        toast({ title: "Template Updated" });
      } else {
        const { error } = await supabase
          .from("report_templates")
          .insert(templateData);

        if (error) throw error;
        toast({ title: "Template Created" });
      }

      setIsDialogOpen(false);
      resetForm();
      fetchTemplates();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  const handleEdit = (template: ReportTemplate) => {
    setEditingTemplate(template);
    setFormData({
      name: template.name,
      description: template.description || "",
      columns: template.columns,
      group_by: template.group_by || "",
      include_charts: template.include_charts,
      date_range: template.date_range,
    });
    setIsDialogOpen(true);
  };

  const handleDuplicate = async (template: ReportTemplate) => {
    if (!user) return;
    try {
      const insertData = {
        user_id: user.id,
        name: `${template.name} (Copy)`,
        description: template.description,
        columns: template.columns,
        group_by: template.group_by,
        include_charts: template.include_charts,
        date_range: template.date_range,
        filters: template.filters,
      };
      const { error } = await supabase.from("report_templates").insert(insertData as any);

      if (error) throw error;
      toast({ title: "Template Duplicated" });
      fetchTemplates();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const handleDelete = async (id: string) => {
    try {
      const { error } = await supabase
        .from("report_templates")
        .delete()
        .eq("id", id);

      if (error) throw error;
      toast({ title: "Template Deleted" });
      fetchTemplates();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const resetForm = () => {
    setEditingTemplate(null);
    setFormData({
      name: "",
      description: "",
      columns: ["date", "vendor", "category", "amount"],
      group_by: "",
      include_charts: false,
      date_range: "month",
    });
  };

  const toggleColumn = (columnId: string) => {
    setFormData((prev) => ({
      ...prev,
      columns: prev.columns.includes(columnId)
        ? prev.columns.filter((c) => c !== columnId)
        : [...prev.columns, columnId],
    }));
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="py-10">
          <div className="flex items-center justify-center">
            <Loader2 className="w-6 h-6 animate-spin" />
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="flex items-center gap-2">
          <FileText className="w-5 h-5" />
          Report Templates
        </CardTitle>
        <Dialog open={isDialogOpen} onOpenChange={(open) => {
          setIsDialogOpen(open);
          if (!open) resetForm();
        }}>
          <DialogTrigger asChild>
            <Button size="sm">
              <Plus className="w-4 h-4 mr-2" />
              New Template
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle>
                {editingTemplate ? "Edit Template" : "Create Report Template"}
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4 pt-4">
              <div className="space-y-2">
                <Label htmlFor="name">Template Name *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Monthly Expense Report"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Detailed monthly breakdown of all expenses"
                  rows={2}
                />
              </div>

              <div className="space-y-2">
                <Label>Columns to Include</Label>
                <div className="grid grid-cols-2 gap-2">
                  {AVAILABLE_COLUMNS.map((col) => (
                    <div key={col.id} className="flex items-center space-x-2">
                      <Checkbox
                        id={col.id}
                        checked={formData.columns.includes(col.id)}
                        onCheckedChange={() => toggleColumn(col.id)}
                      />
                      <label htmlFor={col.id} className="text-sm cursor-pointer">
                        {col.label}
                      </label>
                    </div>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Date Range</Label>
                  <Select
                    value={formData.date_range}
                    onValueChange={(value) => setFormData({ ...formData, date_range: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {DATE_RANGES.map((range) => (
                        <SelectItem key={range.id} value={range.id}>
                          {range.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Group By</Label>
                  <Select
                    value={formData.group_by}
                    onValueChange={(value) => setFormData({ ...formData, group_by: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="None" />
                    </SelectTrigger>
                    <SelectContent>
                      {GROUP_BY_OPTIONS.map((opt) => (
                        <SelectItem key={opt.id} value={opt.id}>
                          {opt.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="include_charts"
                  checked={formData.include_charts}
                  onCheckedChange={(checked) =>
                    setFormData({ ...formData, include_charts: checked as boolean })
                  }
                />
                <label htmlFor="include_charts" className="text-sm cursor-pointer flex items-center gap-2">
                  <BarChart3 className="w-4 h-4" />
                  Include Charts
                </label>
              </div>

              <Button onClick={handleSave} disabled={saving} className="w-full">
                {saving ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <Save className="w-4 h-4 mr-2" />
                )}
                {editingTemplate ? "Update Template" : "Save Template"}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </CardHeader>
      <CardContent>
        {templates.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <FileText className="w-10 h-10 mx-auto mb-2 opacity-50" />
            <p>No templates yet. Create your first report template.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {templates.map((template) => (
              <div
                key={template.id}
                className="p-4 rounded-lg border bg-card hover:bg-muted/50 transition-colors"
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1 min-w-0">
                    <h4 className="font-medium truncate">{template.name}</h4>
                    {template.description && (
                      <p className="text-sm text-muted-foreground mt-1 line-clamp-1">
                        {template.description}
                      </p>
                    )}
                    <div className="flex flex-wrap gap-1 mt-2">
                      <Badge variant="outline" className="text-xs">
                        {DATE_RANGES.find((r) => r.id === template.date_range)?.label}
                      </Badge>
                      <Badge variant="outline" className="text-xs">
                        {template.columns.length} columns
                      </Badge>
                      {template.include_charts && (
                        <Badge variant="outline" className="text-xs">
                          <BarChart3 className="w-3 h-3 mr-1" />
                          Charts
                        </Badge>
                      )}
                    </div>
                  </div>
                  <div className="flex gap-1 ml-2">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8"
                      onClick={() => handleEdit(template)}
                    >
                      <Edit className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8"
                      onClick={() => handleDuplicate(template)}
                    >
                      <Copy className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 text-destructive hover:text-destructive"
                      onClick={() => handleDelete(template.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default ReportTemplateManager;

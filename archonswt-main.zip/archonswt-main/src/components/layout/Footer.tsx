import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Lock, Shield, MapPin, Globe, Mail, Phone, Linkedin, Loader2 } from "lucide-react";

interface GeoData {
  ip: string;
  city?: string;
  region?: string;
  country?: string;
}

const Footer = () => {
  const [geoData, setGeoData] = useState<GeoData | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchGeoData = async () => {
      setIsLoading(true);
      try {
        const response = await fetch("https://ipapi.co/json/");
        const data = await response.json();
        setGeoData({
          ip: data.ip,
          city: data.city,
          region: data.region,
          country: data.country_name,
        });
      } catch (error) {
        console.error("Failed to fetch geo data:", error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchGeoData();
  }, []);

  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-primary text-primary-foreground mt-auto">
      {/* Security Banner */}
      <div className="bg-destructive/90 text-destructive-foreground py-2">
        <div className="container flex flex-col sm:flex-row items-center justify-center gap-2 text-center text-sm font-medium">
          <div className="flex items-center gap-2">
            <Shield className="h-4 w-4" />
            <span>⚠️ YOU ARE UNDER SURVEILLANCE ⚠️</span>
            <Shield className="h-4 w-4" />
          </div>
        </div>
      </div>

      {/* Main Footer Content */}
      <div className="container py-8 sm:py-12">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="space-y-4">
            <h3 className="text-lg font-bold text-gold">Archon Strategic Works</h3>
            <p className="text-sm text-primary-foreground/80">
              Professional expense tracking and financial management solutions for businesses of all sizes.
            </p>
            <div className="flex items-center gap-2 text-sm">
              <Lock className="h-4 w-4 text-gold" />
              <Lock className="h-4 w-4 text-gold" />
              <span className="text-gold font-medium">This site is secured</span>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-4">
            <h4 className="text-md font-semibold text-gold">Quick Links</h4>
            <nav className="flex flex-col gap-2 text-sm">
              <Link to="/" className="hover:text-gold transition-colors">Dashboard</Link>
              <Link to="/projects" className="hover:text-gold transition-colors">Projects</Link>
              <Link to="/analytics" className="hover:text-gold transition-colors">Analytics</Link>
              <Link to="/settings" className="hover:text-gold transition-colors">Settings</Link>
              <Link to="/admin" className="hover:text-gold transition-colors">Admin Panel</Link>
            </nav>
          </div>

          {/* Contact Info */}
          <div className="space-y-4">
            <h4 className="text-md font-semibold text-gold">Contact Us</h4>
            <div className="flex flex-col gap-2 text-sm">
              <a href="mailto:info@archonworks.com" className="flex items-center gap-2 hover:text-gold transition-colors">
                <Mail className="h-4 w-4" />
                info@archonworks.com
              </a>
              <a href="tel:+8801923999956" className="flex items-center gap-2 hover:text-gold transition-colors">
                <Phone className="h-4 w-4" />
                +880 1923 999956
              </a>
            </div>
            {/* Social Media */}
            <div className="flex items-center gap-4 pt-2">
              <a href="https://www.linkedin.com/in/kaziafnanibnealam/" target="_blank" rel="noopener noreferrer" className="hover:text-gold transition-colors" aria-label="LinkedIn">
                <Linkedin className="h-5 w-5" />
              </a>
            </div>
          </div>

          {/* User Location & Security */}
          <div className="space-y-4">
            <h4 className="text-md font-semibold text-gold">Your Session</h4>
            <div className="space-y-2 text-sm">
              {isLoading ? (
                <div className="flex items-center gap-3 text-primary-foreground/60">
                  <div className="relative">
                    <Globe className="h-5 w-5 text-gold animate-pulse" />
                    <Loader2 className="absolute -top-1 -right-1 h-3 w-3 text-gold animate-spin" />
                  </div>
                  <div className="space-y-1">
                    <div className="h-3 w-24 bg-primary-foreground/20 rounded animate-pulse" />
                    <div className="h-3 w-32 bg-primary-foreground/20 rounded animate-pulse" />
                  </div>
                </div>
              ) : geoData ? (
                <>
                  <div className="flex items-center gap-2">
                    <Globe className="h-4 w-4 text-gold" />
                    <span>IP: {geoData.ip}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <MapPin className="h-4 w-4 text-gold" />
                    <span>
                      {[geoData.city, geoData.region, geoData.country]
                        .filter(Boolean)
                        .join(", ")}
                    </span>
                  </div>
                </>
              ) : (
                <div className="flex items-center gap-2 text-primary-foreground/60">
                  <Globe className="h-4 w-4" />
                  <span>Location unavailable</span>
                </div>
              )}
              <div className="flex items-center gap-2 pt-2 text-gold">
                <Shield className="h-4 w-4" />
                <span className="font-medium">Session Monitored</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Attribution & Bottom Bar */}
      <div className="border-t border-primary-foreground/20">
        <div className="container py-4 space-y-3">
          {/* Attribution */}
          <div className="text-center text-sm text-primary-foreground/70">
            <p>
              Concept, Design & Direction by{" "}
              <a 
                href="https://www.linkedin.com/in/kaziafnanibnealam/" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-gold hover:text-gold-light transition-colors font-medium"
              >
                Kazi Afnan
              </a>
            </p>
          </div>
          
          {/* Copyright & Links */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-sm text-primary-foreground/70">
            <p>© {currentYear} Archon Strategic Works. All rights reserved.</p>
            <div className="flex items-center gap-4">
              <Link to="#" className="hover:text-gold transition-colors">Privacy Policy</Link>
              <Link to="#" className="hover:text-gold transition-colors">Terms of Service</Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;

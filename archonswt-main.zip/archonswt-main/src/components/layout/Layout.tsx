import { ReactNode } from "react";
import Header from "./Header";
import Footer from "./Footer";
import logo from "@/assets/logo.jpg";

interface LayoutProps {
  children: ReactNode;
}

const Layout = ({ children }: LayoutProps) => {
  return (
    <div className="min-h-screen bg-background relative overflow-hidden flex flex-col">
      {/* Background Watermark */}
      <div 
        className="fixed inset-0 pointer-events-none z-0 flex items-center justify-center"
        aria-hidden="true"
      >
        <img 
          src={logo} 
          alt="" 
          className="w-[60vw] max-w-[600px] h-auto opacity-[0.03] dark:opacity-[0.05] select-none"
        />
      </div>
      
      <div className="relative z-10 flex-1 flex flex-col">
        <Header />
        <main className="container py-4 sm:py-6 px-4 sm:px-6 lg:px-8 flex-1">
          {children}
        </main>
        <Footer />
      </div>
    </div>
  );
};

export default Layout;

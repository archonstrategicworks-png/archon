import { useState } from "react";
import { useExchangeRates, CURRENCIES, Currency, formatCurrencyAmount } from "@/hooks/useExchangeRates";
import { useCurrency } from "@/hooks/useCurrency";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { RefreshCw, ArrowRightLeft, TrendingUp, Loader2 } from "lucide-react";
import { format } from "date-fns";

const CurrencyConverter = () => {
  const { convert, getRate, loading, lastUpdated, refreshRates } = useExchangeRates();
  const { currency: userCurrency } = useCurrency();
  const [amount, setAmount] = useState("1000");
  const [fromCurrency, setFromCurrency] = useState<Currency>(userCurrency as Currency);
  const [toCurrency, setToCurrency] = useState<Currency>("USD");
  const [refreshing, setRefreshing] = useState(false);

  const handleRefresh = async () => {
    setRefreshing(true);
    await refreshRates();
    setRefreshing(false);
  };

  const handleSwap = () => {
    const temp = fromCurrency;
    setFromCurrency(toCurrency);
    setToCurrency(temp);
  };

  const numAmount = parseFloat(amount) || 0;
  const convertedAmount = convert(numAmount, fromCurrency, toCurrency);
  const rate = getRate(fromCurrency, toCurrency);

  return (
    <Card className="card-shadow">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="flex items-center gap-2">
          <TrendingUp className="w-5 h-5" />
          Currency Converter
        </CardTitle>
        <Button
          variant="ghost"
          size="sm"
          onClick={handleRefresh}
          disabled={refreshing || loading}
        >
          {refreshing ? (
            <Loader2 className="w-4 h-4 animate-spin" />
          ) : (
            <RefreshCw className="w-4 h-4" />
          )}
        </Button>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-[1fr,auto,1fr] gap-2 items-end">
          <div>
            <Label className="text-xs">Amount</Label>
            <Input
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="text-lg font-bold"
            />
            <Select
              value={fromCurrency}
              onValueChange={(v) => setFromCurrency(v as Currency)}
            >
              <SelectTrigger className="mt-2">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {CURRENCIES.map((c) => (
                  <SelectItem key={c.code} value={c.code}>
                    {c.symbol} {c.code} - {c.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <Button
            variant="ghost"
            size="icon"
            onClick={handleSwap}
            className="mb-1"
          >
            <ArrowRightLeft className="w-4 h-4" />
          </Button>

          <div>
            <Label className="text-xs">Converted</Label>
            <div className="h-10 flex items-center px-3 bg-muted rounded-md text-lg font-bold">
              {loading ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                formatCurrencyAmount(convertedAmount, toCurrency)
              )}
            </div>
            <Select
              value={toCurrency}
              onValueChange={(v) => setToCurrency(v as Currency)}
            >
              <SelectTrigger className="mt-2">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {CURRENCIES.map((c) => (
                  <SelectItem key={c.code} value={c.code}>
                    {c.symbol} {c.code} - {c.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {rate && (
          <div className="text-sm text-muted-foreground text-center pt-2 border-t">
            1 {fromCurrency} = {rate.toFixed(4)} {toCurrency}
            {lastUpdated && (
              <span className="block text-xs mt-1">
                Updated: {format(lastUpdated, "MMM dd, HH:mm")}
              </span>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default CurrencyConverter;

import { useState, useRef } from "react";
import { useCurrency } from "@/hooks/useCurrency";
import { useLanguage } from "@/contexts/LanguageContext";
import { useProfile } from "@/hooks/useProfile";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { FileText, Download, Printer } from "lucide-react";

interface Expense {
  id: string;
  date: string;
  amount: number;
  category: string;
  vendor: string | null;
  notes: string | null;
}

interface InvoiceGeneratorProps {
  projectName: string;
  clientName: string | null;
  expenses: Expense[];
  totalAmount: number;
}

const InvoiceGenerator = ({
  projectName,
  clientName,
  expenses,
  totalAmount,
}: InvoiceGeneratorProps) => {
  const { format, currency, symbol } = useCurrency();
  const { t } = useLanguage();
  const { profile } = useProfile();
  const printRef = useRef<HTMLDivElement>(null);

  const [open, setOpen] = useState(false);
  const [invoiceData, setInvoiceData] = useState({
    invoiceNumber: `INV-${Date.now().toString().slice(-6)}`,
    issueDate: new Date().toISOString().split("T")[0],
    dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)
      .toISOString()
      .split("T")[0],
    clientName: clientName || "",
    clientAddress: "",
    notes: "",
    taxRate: 0,
  });

  const subtotal = totalAmount;
  const taxAmount = (subtotal * invoiceData.taxRate) / 100;
  const grandTotal = subtotal + taxAmount;

  const handlePrint = () => {
    const printContent = printRef.current;
    if (!printContent) return;

    const printWindow = window.open("", "_blank");
    if (!printWindow) return;

    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>Invoice ${invoiceData.invoiceNumber}</title>
          <style>
            * { box-sizing: border-box; margin: 0; padding: 0; }
            body { font-family: 'Segoe UI', Arial, sans-serif; padding: 40px; color: #1a1a1a; }
            .invoice-container { max-width: 800px; margin: 0 auto; }
            .header { display: flex; justify-content: space-between; margin-bottom: 40px; padding-bottom: 20px; border-bottom: 2px solid #e5e5e5; }
            .company-info h1 { font-size: 28px; font-weight: 700; color: #0ea5e9; margin-bottom: 8px; }
            .company-info p { color: #666; font-size: 14px; }
            .invoice-details { text-align: right; }
            .invoice-details h2 { font-size: 32px; font-weight: 300; color: #333; margin-bottom: 8px; }
            .invoice-details p { color: #666; font-size: 14px; margin: 4px 0; }
            .client-section { display: flex; justify-content: space-between; margin-bottom: 40px; }
            .client-info h3, .project-info h3 { font-size: 12px; text-transform: uppercase; color: #999; margin-bottom: 8px; letter-spacing: 1px; }
            .client-info p, .project-info p { font-size: 14px; margin: 4px 0; }
            table { width: 100%; border-collapse: collapse; margin-bottom: 30px; }
            th { background: #f8f9fa; padding: 12px; text-align: left; font-size: 12px; text-transform: uppercase; color: #666; border-bottom: 2px solid #e5e5e5; }
            td { padding: 12px; border-bottom: 1px solid #eee; font-size: 14px; }
            .amount { text-align: right; }
            .totals { display: flex; justify-content: flex-end; }
            .totals-table { width: 300px; }
            .totals-table tr td { padding: 8px 12px; }
            .totals-table .label { color: #666; }
            .totals-table .value { text-align: right; font-weight: 500; }
            .grand-total { background: #0ea5e9; color: white !important; font-size: 18px !important; font-weight: 700 !important; }
            .grand-total td { padding: 16px 12px !important; }
            .notes { margin-top: 40px; padding: 20px; background: #f8f9fa; border-radius: 8px; }
            .notes h3 { font-size: 12px; text-transform: uppercase; color: #999; margin-bottom: 8px; }
            .footer { margin-top: 60px; text-align: center; color: #999; font-size: 12px; padding-top: 20px; border-top: 1px solid #eee; }
            @media print { body { padding: 20px; } }
          </style>
        </head>
        <body>
          ${printContent.innerHTML}
        </body>
      </html>
    `);
    printWindow.document.close();
    printWindow.print();
  };

  const handleDownloadPDF = () => {
    handlePrint();
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline">
          <FileText className="w-4 h-4 mr-2" />
          Generate Invoice
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Generate Invoice</DialogTitle>
        </DialogHeader>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
          <div className="space-y-4">
            <div>
              <Label>Invoice Number</Label>
              <Input
                value={invoiceData.invoiceNumber}
                onChange={(e) =>
                  setInvoiceData({ ...invoiceData, invoiceNumber: e.target.value })
                }
              />
            </div>
            <div>
              <Label>Issue Date</Label>
              <Input
                type="date"
                value={invoiceData.issueDate}
                onChange={(e) =>
                  setInvoiceData({ ...invoiceData, issueDate: e.target.value })
                }
              />
            </div>
            <div>
              <Label>Due Date</Label>
              <Input
                type="date"
                value={invoiceData.dueDate}
                onChange={(e) =>
                  setInvoiceData({ ...invoiceData, dueDate: e.target.value })
                }
              />
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <Label>Client Name</Label>
              <Input
                value={invoiceData.clientName}
                onChange={(e) =>
                  setInvoiceData({ ...invoiceData, clientName: e.target.value })
                }
                placeholder="Client name"
              />
            </div>
            <div>
              <Label>Client Address</Label>
              <Textarea
                value={invoiceData.clientAddress}
                onChange={(e) =>
                  setInvoiceData({ ...invoiceData, clientAddress: e.target.value })
                }
                placeholder="Client address"
                rows={3}
              />
            </div>
            <div>
              <Label>Tax Rate (%)</Label>
              <Input
                type="number"
                min="0"
                max="100"
                value={invoiceData.taxRate}
                onChange={(e) =>
                  setInvoiceData({
                    ...invoiceData,
                    taxRate: parseFloat(e.target.value) || 0,
                  })
                }
              />
            </div>
          </div>
        </div>

        <div>
          <Label>Notes</Label>
          <Textarea
            value={invoiceData.notes}
            onChange={(e) =>
              setInvoiceData({ ...invoiceData, notes: e.target.value })
            }
            placeholder="Payment terms, bank details, thank you note, etc."
            rows={2}
          />
        </div>

        {/* Invoice Preview */}
        <div
          ref={printRef}
          className="mt-6 p-8 bg-white border rounded-lg text-foreground"
        >
          <div className="invoice-container">
            {/* Header */}
            <div className="flex justify-between items-start mb-8 pb-6 border-b-2">
              <div>
                <h1 className="text-2xl font-bold text-primary mb-1">
                  {profile?.company_name || profile?.display_name || "Your Company"}
                </h1>
                <p className="text-muted-foreground text-sm">
                  Professional Project Expense Invoice
                </p>
              </div>
              <div className="text-right">
                <h2 className="text-3xl font-light text-foreground mb-1">INVOICE</h2>
                <p className="text-muted-foreground text-sm">
                  #{invoiceData.invoiceNumber}
                </p>
                <p className="text-muted-foreground text-sm">
                  Date: {invoiceData.issueDate}
                </p>
                <p className="text-muted-foreground text-sm">
                  Due: {invoiceData.dueDate}
                </p>
              </div>
            </div>

            {/* Client & Project Info */}
            <div className="flex justify-between mb-8">
              <div>
                <h3 className="text-xs uppercase text-muted-foreground tracking-wider mb-2">
                  Bill To
                </h3>
                <p className="font-medium">{invoiceData.clientName || "Client Name"}</p>
                {invoiceData.clientAddress && (
                  <p className="text-sm text-muted-foreground whitespace-pre-line">
                    {invoiceData.clientAddress}
                  </p>
                )}
              </div>
              <div className="text-right">
                <h3 className="text-xs uppercase text-muted-foreground tracking-wider mb-2">
                  Project
                </h3>
                <p className="font-medium">{projectName}</p>
              </div>
            </div>

            {/* Items Table */}
            <table className="w-full mb-6">
              <thead>
                <tr className="bg-muted">
                  <th className="p-3 text-left text-xs uppercase text-muted-foreground">
                    Date
                  </th>
                  <th className="p-3 text-left text-xs uppercase text-muted-foreground">
                    Category
                  </th>
                  <th className="p-3 text-left text-xs uppercase text-muted-foreground">
                    Description
                  </th>
                  <th className="p-3 text-right text-xs uppercase text-muted-foreground">
                    Amount
                  </th>
                </tr>
              </thead>
              <tbody>
                {expenses.map((expense) => (
                  <tr key={expense.id} className="border-b">
                    <td className="p-3 text-sm">{expense.date}</td>
                    <td className="p-3 text-sm">{expense.category}</td>
                    <td className="p-3 text-sm">
                      {expense.vendor || expense.notes || "-"}
                    </td>
                    <td className="p-3 text-sm text-right font-medium">
                      {format(expense.amount)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>

            {/* Totals */}
            <div className="flex justify-end">
              <table className="w-72">
                <tbody>
                  <tr>
                    <td className="p-2 text-muted-foreground">Subtotal</td>
                    <td className="p-2 text-right font-medium">{format(subtotal)}</td>
                  </tr>
                  {invoiceData.taxRate > 0 && (
                    <tr>
                      <td className="p-2 text-muted-foreground">
                        Tax ({invoiceData.taxRate}%)
                      </td>
                      <td className="p-2 text-right font-medium">
                        {format(taxAmount)}
                      </td>
                    </tr>
                  )}
                  <tr className="bg-primary text-primary-foreground">
                    <td className="p-4 font-bold text-lg">Grand Total</td>
                    <td className="p-4 text-right font-bold text-lg">
                      {format(grandTotal)}
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>

            {/* Notes */}
            {invoiceData.notes && (
              <div className="mt-8 p-4 bg-muted rounded-lg">
                <h3 className="text-xs uppercase text-muted-foreground tracking-wider mb-2">
                  Notes
                </h3>
                <p className="text-sm whitespace-pre-line">{invoiceData.notes}</p>
              </div>
            )}

            {/* Footer */}
            <div className="mt-12 pt-4 border-t text-center text-muted-foreground text-xs">
              <p>Thank you for your business!</p>
              <p>Generated by Project Expense Tracker</p>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="flex gap-3 justify-end mt-4">
          <Button variant="outline" onClick={() => setOpen(false)}>
            Cancel
          </Button>
          <Button variant="secondary" onClick={handlePrint}>
            <Printer className="w-4 h-4 mr-2" />
            Print
          </Button>
          <Button onClick={handleDownloadPDF}>
            <Download className="w-4 h-4 mr-2" />
            Download PDF
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default InvoiceGenerator;

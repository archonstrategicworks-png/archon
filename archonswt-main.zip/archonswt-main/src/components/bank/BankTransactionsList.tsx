import { useEffect, useState } from "react";
import { format } from "date-fns";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { CheckCircle, Link2, Trash2, Loader2 } from "lucide-react";

interface BankTransaction {
  id: string;
  date: string;
  description: string | null;
  amount: number;
  matched_expense_id: string | null;
  confidence_score: number | null;
}

interface Project {
  id: string;
  project_name: string;
}

interface BankTransactionsListProps {
  refreshKey: number;
}

const BankTransactionsList = ({ refreshKey }: BankTransactionsListProps) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [transactions, setTransactions] = useState<BankTransaction[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState<string | null>(null);

  const fetchData = async () => {
    if (!user) return;

    try {
      const [transactionsRes, projectsRes] = await Promise.all([
        supabase
          .from("bank_transactions")
          .select("*")
          .eq("user_id", user.id)
          .order("date", { ascending: false }),
        supabase
          .from("projects")
          .select("id, project_name")
          .eq("user_id", user.id)
          .order("project_name"),
      ]);

      if (transactionsRes.error) throw transactionsRes.error;
      if (projectsRes.error) throw projectsRes.error;

      setTransactions(transactionsRes.data || []);
      setProjects(projectsRes.data || []);
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [user, refreshKey]);

  const createExpenseFromTransaction = async (transaction: BankTransaction, projectId: string) => {
    if (!user) return;

    setCreating(transaction.id);
    try {
      // Create expense
      const { data: expense, error: expenseError } = await supabase
        .from("expenses")
        .insert({
          project_id: projectId,
          date: transaction.date,
          amount: transaction.amount,
          payment_method: "Bank",
          category: "Misc",
          vendor: transaction.description || "Bank Transaction",
          notes: `Imported from bank statement`,
          source: "Bank OCR",
        })
        .select()
        .single();

      if (expenseError) throw expenseError;

      // Update bank transaction with matched expense
      const { error: updateError } = await supabase
        .from("bank_transactions")
        .update({ matched_expense_id: expense.id })
        .eq("id", transaction.id);

      if (updateError) throw updateError;

      toast({
        title: "Expense Created",
        description: "Transaction linked to project expense.",
      });

      fetchData();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to create expense.",
        variant: "destructive",
      });
    } finally {
      setCreating(null);
    }
  };

  const deleteTransaction = async (id: string) => {
    if (!confirm("Delete this bank transaction?")) return;

    try {
      const { error } = await supabase
        .from("bank_transactions")
        .delete()
        .eq("id", id);

      if (error) throw error;

      toast({
        title: "Deleted",
        description: "Transaction removed.",
      });

      fetchData();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to delete.",
        variant: "destructive",
      });
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("en-IN", {
      style: "currency",
      currency: "INR",
      maximumFractionDigits: 0,
    }).format(amount);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (transactions.length === 0) {
    return (
      <div className="text-center py-12 bg-muted/30 rounded-xl">
        <p className="text-muted-foreground">No bank transactions imported yet.</p>
        <p className="text-sm text-muted-foreground mt-1">
          Upload a bank statement to get started.
        </p>
      </div>
    );
  }

  const unmatchedCount = transactions.filter(t => !t.matched_expense_id).length;

  return (
    <div className="space-y-4">
      {unmatchedCount > 0 && (
        <div className="flex items-center gap-2 text-sm text-amber-600 bg-amber-50 px-4 py-2 rounded-lg">
          <span className="font-medium">{unmatchedCount} unmatched transactions</span>
          <span className="text-muted-foreground">- Select a project to create expenses</span>
        </div>
      )}

      <div className="rounded-xl border bg-card overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="bg-muted/50">
              <TableHead className="font-semibold">Date</TableHead>
              <TableHead className="font-semibold">Description</TableHead>
              <TableHead className="font-semibold text-right">Amount</TableHead>
              <TableHead className="font-semibold">Status</TableHead>
              <TableHead className="font-semibold">Link to Project</TableHead>
              <TableHead className="w-12"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {transactions.map((transaction) => (
              <TableRow key={transaction.id}>
                <TableCell className="font-medium">
                  {format(new Date(transaction.date), "MMM dd, yyyy")}
                </TableCell>
                <TableCell className="max-w-[200px] truncate">
                  {transaction.description || "-"}
                </TableCell>
                <TableCell className="text-right font-bold text-red-600">
                  -{formatCurrency(transaction.amount)}
                </TableCell>
                <TableCell>
                  {transaction.matched_expense_id ? (
                    <Badge className="bg-green-100 text-green-700 border-green-200">
                      <CheckCircle className="w-3 h-3 mr-1" />
                      Matched
                    </Badge>
                  ) : (
                    <Badge variant="secondary" className="bg-amber-100 text-amber-700">
                      Unmatched
                    </Badge>
                  )}
                </TableCell>
                <TableCell>
                  {!transaction.matched_expense_id && (
                    <div className="flex items-center gap-2">
                      <Select
                        onValueChange={(projectId) => 
                          createExpenseFromTransaction(transaction, projectId)
                        }
                        disabled={creating === transaction.id}
                      >
                        <SelectTrigger className="w-[180px] h-9">
                          {creating === transaction.id ? (
                            <Loader2 className="w-4 h-4 animate-spin" />
                          ) : (
                            <SelectValue placeholder="Select project..." />
                          )}
                        </SelectTrigger>
                        <SelectContent>
                          {projects.map((project) => (
                            <SelectItem key={project.id} value={project.id}>
                              {project.project_name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  )}
                  {transaction.matched_expense_id && (
                    <span className="text-sm text-muted-foreground flex items-center gap-1">
                      <Link2 className="w-3 h-3" />
                      Linked
                    </span>
                  )}
                </TableCell>
                <TableCell>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 text-muted-foreground hover:text-destructive"
                    onClick={() => deleteTransaction(transaction.id)}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
};

export default BankTransactionsList;

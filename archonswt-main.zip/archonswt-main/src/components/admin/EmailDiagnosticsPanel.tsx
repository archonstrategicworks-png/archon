import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { 
  Mail, RefreshCw, CheckCircle, XCircle, AlertTriangle, 
  Users, Send, Clock, Activity 
} from 'lucide-react';

interface DiagnosticResult {
  success: boolean;
  message: string;
  details?: string;
  timestamp: Date;
  recipientCount?: number;
  duration?: number;
}

export function EmailDiagnosticsPanel() {
  const [testTitle, setTestTitle] = useState('Test Notification');
  const [testBody, setTestBody] = useState('This is a test email from the admin panel.');
  const [isTesting, setIsTesting] = useState(false);
  const [lastResult, setLastResult] = useState<DiagnosticResult | null>(null);
  const [recipientCount, setRecipientCount] = useState<number>(0);
  const [isLoadingCount, setIsLoadingCount] = useState(false);

  // Fetch recipient count on mount
  useEffect(() => {
    fetchRecipientCount();
  }, []);

  const fetchRecipientCount = async () => {
    setIsLoadingCount(true);
    try {
      const { count, error } = await supabase
        .from('profiles')
        .select('*', { count: 'exact', head: true })
        .eq('email_notifications_enabled', true);

      if (error) throw error;
      setRecipientCount(count ?? 0);
    } catch (err) {
      console.error('Error fetching recipient count:', err);
    } finally {
      setIsLoadingCount(false);
    }
  };

  const sanitizeError = (error: any): string => {
    const message = error?.message ?? String(error);
    
    // Remove sensitive information patterns
    const sanitized = message
      .replace(/Bearer\s+[A-Za-z0-9\-_\.]+/gi, 'Bearer [REDACTED]')
      .replace(/api[_-]?key[=:]\s*[A-Za-z0-9\-_]+/gi, 'api_key=[REDACTED]')
      .replace(/password[=:]\s*\S+/gi, 'password=[REDACTED]')
      .replace(/secret[=:]\s*\S+/gi, 'secret=[REDACTED]');

    return sanitized;
  };

  const runEmailTest = async () => {
    if (!testTitle.trim() || !testBody.trim()) {
      toast.error('Please enter both title and body');
      return;
    }

    setIsTesting(true);
    const startTime = Date.now();

    try {
      // First refresh session to ensure valid JWT
      const { error: refreshError } = await supabase.auth.refreshSession();
      if (refreshError) {
        throw new Error(`Session refresh failed: ${refreshError.message}`);
      }

      const { data, error } = await supabase.functions.invoke('send-notification-email', {
        body: { title: testTitle.trim(), body: testBody.trim() }
      });

      const duration = Date.now() - startTime;

      if (error) {
        const status = (error as any)?.status;
        const msg = sanitizeError(error);

        let friendlyMessage = 'Email sending failed';
        let details = msg;

        if (status === 401 || msg.toLowerCase().includes('jwt')) {
          friendlyMessage = 'Authentication failed';
          details = 'Your session token is invalid or expired. Try signing out and back in.';
        } else if (status === 403) {
          friendlyMessage = 'Permission denied';
          details = 'You do not have admin privileges to send emails.';
        } else if (msg.includes('resend') || msg.includes('RESEND')) {
          friendlyMessage = 'Email service error';
          details = 'The email service (Resend) returned an error. Check if RESEND_API_KEY is configured correctly.';
        }

        setLastResult({
          success: false,
          message: friendlyMessage,
          details,
          timestamp: new Date(),
          duration,
        });

        toast.error(friendlyMessage);
      } else {
        const emailsSent = data?.sent ?? 0;
        const failures = data?.failures ?? 0;

        setLastResult({
          success: true,
          message: `Email test successful`,
          details: `Sent to ${emailsSent} recipients${failures > 0 ? `, ${failures} failures` : ''}`,
          timestamp: new Date(),
          recipientCount: emailsSent,
          duration,
        });

        toast.success(`Email test successful: ${emailsSent} emails sent`);
      }
    } catch (err: any) {
      const duration = Date.now() - startTime;
      const sanitized = sanitizeError(err);

      setLastResult({
        success: false,
        message: 'Unexpected error',
        details: sanitized,
        timestamp: new Date(),
        duration,
      });

      toast.error('Email test failed');
    } finally {
      setIsTesting(false);
    }
  };

  const retryTest = () => {
    runEmailTest();
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Mail className="h-5 w-5" />
          Email Diagnostics
        </CardTitle>
        <CardDescription>
          Test backend email sending and troubleshoot issues
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Recipient Count */}
        <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
          <div className="flex items-center gap-3">
            <Users className="h-5 w-5 text-muted-foreground" />
            <div>
              <p className="font-medium">Email Recipients</p>
              <p className="text-sm text-muted-foreground">
                Users with email notifications enabled
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant="secondary" className="text-lg px-3 py-1">
              {isLoadingCount ? '...' : recipientCount}
            </Badge>
            <Button
              variant="ghost"
              size="icon"
              onClick={fetchRecipientCount}
              disabled={isLoadingCount}
            >
              <RefreshCw className={`h-4 w-4 ${isLoadingCount ? 'animate-spin' : ''}`} />
            </Button>
          </div>
        </div>

        {/* Test Form */}
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="test-title">Test Email Title</Label>
            <Input
              id="test-title"
              value={testTitle}
              onChange={(e) => setTestTitle(e.target.value)}
              placeholder="Enter test email title"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="test-body">Test Email Body</Label>
            <Input
              id="test-body"
              value={testBody}
              onChange={(e) => setTestBody(e.target.value)}
              placeholder="Enter test email body"
            />
          </div>
          <Button
            onClick={runEmailTest}
            disabled={isTesting}
            className="w-full"
          >
            {isTesting ? (
              <>
                <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                Testing...
              </>
            ) : (
              <>
                <Send className="h-4 w-4 mr-2" />
                Send Test Email
              </>
            )}
          </Button>
        </div>

        {/* Last Result */}
        {lastResult && (
          <Alert variant={lastResult.success ? 'default' : 'destructive'}>
            <div className="flex items-start gap-3">
              {lastResult.success ? (
                <CheckCircle className="h-5 w-5 text-green-500 mt-0.5" />
              ) : (
                <XCircle className="h-5 w-5 mt-0.5" />
              )}
              <div className="flex-1 space-y-2">
                <AlertTitle className="flex items-center justify-between">
                  <span>{lastResult.message}</span>
                  {lastResult.duration && (
                    <Badge variant="outline" className="ml-2">
                      <Clock className="h-3 w-3 mr-1" />
                      {lastResult.duration}ms
                    </Badge>
                  )}
                </AlertTitle>
                <AlertDescription className="text-sm">
                  {lastResult.details}
                </AlertDescription>
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <Activity className="h-3 w-3" />
                  {lastResult.timestamp.toLocaleTimeString()}
                </div>
              </div>
            </div>
            {!lastResult.success && (
              <Button
                variant="outline"
                size="sm"
                className="mt-3"
                onClick={retryTest}
                disabled={isTesting}
              >
                <RefreshCw className="h-3 w-3 mr-1" />
                Retry
              </Button>
            )}
          </Alert>
        )}

        {/* Quick Tips */}
        <div className="p-4 bg-muted/50 rounded-lg space-y-2">
          <div className="flex items-center gap-2 text-sm font-medium">
            <AlertTriangle className="h-4 w-4 text-yellow-500" />
            Troubleshooting Tips
          </div>
          <ul className="text-sm text-muted-foreground space-y-1 ml-6 list-disc">
            <li>Ensure <code>RESEND_API_KEY</code> is set in project secrets</li>
            <li>Verify email domain is validated at resend.com/domains</li>
            <li>Check that users have email notifications enabled</li>
            <li>If you see JWT errors, try signing out and back in</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  );
}

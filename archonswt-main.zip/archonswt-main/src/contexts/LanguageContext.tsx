import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { useProfile } from "@/hooks/useProfile";

type Language = "en" | "bn";

interface Translations {
  [key: string]: {
    en: string;
    bn: string;
  };
}

const translations: Translations = {
  // Navigation
  "nav.dashboard": { en: "Dashboard", bn: "ড্যাশবোর্ড" },
  "nav.projects": { en: "Projects", bn: "প্রকল্প" },
  "nav.upload": { en: "Upload", bn: "আপলোড" },
  "nav.bank": { en: "Bank", bn: "ব্যাংক" },
  "nav.analytics": { en: "Analytics", bn: "বিশ্লেষণ" },
  "nav.settings": { en: "Settings", bn: "সেটিংস" },
  "nav.profile": { en: "Profile", bn: "প্রোফাইল" },
  "nav.signOut": { en: "Sign Out", bn: "সাইন আউট" },
  
  // Dashboard
  "dashboard.title": { en: "Project Expense Tracker", bn: "প্রকল্প ব্যয় ট্র্যাকার" },
  "dashboard.subtitle": { en: "Track, analyze, and export your construction project expenses", bn: "আপনার নির্মাণ প্রকল্পের ব্যয় ট্র্যাক, বিশ্লেষণ এবং রপ্তানি করুন" },
  "dashboard.totalProjects": { en: "Total Projects", bn: "মোট প্রকল্প" },
  "dashboard.activeProjects": { en: "Active Projects", bn: "সক্রিয় প্রকল্প" },
  "dashboard.totalExpenses": { en: "Total Expenses", bn: "মোট ব্যয়" },
  "dashboard.totalAmount": { en: "Total Amount", bn: "মোট পরিমাণ" },
  "dashboard.yourProjects": { en: "Your Projects", bn: "আপনার প্রকল্প" },
  "dashboard.viewAll": { en: "View All", bn: "সব দেখুন" },
  "dashboard.noProjects": { en: "No Projects Yet", bn: "কোনো প্রকল্প নেই" },
  "dashboard.createFirst": { en: "Create your first project to start tracking expenses", bn: "ব্যয় ট্র্যাকিং শুরু করতে আপনার প্রথম প্রকল্প তৈরি করুন" },
  "dashboard.uploadReceipt": { en: "Upload Receipt", bn: "রসিদ আপলোড করুন" },
  "dashboard.newProject": { en: "New Project", bn: "নতুন প্রকল্প" },
  
  // Projects
  "project.viewLedger": { en: "View Ledger", bn: "লেজার দেখুন" },
  "project.budget": { en: "Budget", bn: "বাজেট" },
  "project.spent": { en: "Spent", bn: "ব্যয়িত" },
  "project.remaining": { en: "Remaining", bn: "অবশিষ্ট" },
  "project.overBudget": { en: "Over Budget", bn: "বাজেট অতিক্রম" },
  "project.noBudget": { en: "No Budget Set", bn: "কোনো বাজেট সেট নেই" },
  "project.budgetWarning": { en: "Budget Warning", bn: "বাজেট সতর্কতা" },
  "project.entries": { en: "Entries", bn: "এন্ট্রি" },
  "project.collaborators": { en: "Collaborators", bn: "সহযোগী" },
  "project.addCollaborator": { en: "Add Collaborator", bn: "সহযোগী যোগ করুন" },
  "project.inviteEmail": { en: "Invite by email", bn: "ইমেইলে আমন্ত্রণ" },
  
  // Widgets
  "widget.recentActivity": { en: "Recent Activity", bn: "সাম্প্রতিক কার্যকলাপ" },
  "widget.expenseSummary": { en: "Expense Summary", bn: "ব্যয় সারসংক্ষেপ" },
  "widget.noActivity": { en: "No recent activity", bn: "কোনো সাম্প্রতিক কার্যকলাপ নেই" },
  "widget.noExpenses": { en: "No expenses recorded yet", bn: "এখনও কোনো ব্যয় রেকর্ড করা হয়নি" },
  
  // Analytics
  "analytics.title": { en: "Analytics", bn: "বিশ্লেষণ" },
  "analytics.subtitle": { en: "Insights and breakdowns of your project expenses", bn: "আপনার প্রকল্প ব্যয়ের অন্তর্দৃষ্টি এবং বিশ্লেষণ" },
  "analytics.totalSpending": { en: "Total Spending", bn: "মোট ব্যয়" },
  "analytics.cashPayments": { en: "Cash Payments", bn: "নগদ পেমেন্ট" },
  "analytics.bankTransfers": { en: "Bank Transfers", bn: "ব্যাংক ট্রান্সফার" },
  "analytics.categoryBreakdown": { en: "Category Breakdown", bn: "ক্যাটাগরি বিশ্লেষণ" },
  "analytics.paymentMethods": { en: "Payment Methods", bn: "পেমেন্ট পদ্ধতি" },
  "analytics.projectSpending": { en: "Project-wise Spending", bn: "প্রকল্প অনুযায়ী ব্যয়" },
  "analytics.monthlyTrend": { en: "Monthly Expense Trend", bn: "মাসিক ব্যয় প্রবণতা" },
  "analytics.aiAnalysis": { en: "AI Analysis", bn: "এআই বিশ্লেষণ" },
  "analytics.generateSummary": { en: "Generate Summary", bn: "সারসংক্ষেপ তৈরি করুন" },
  "analytics.analyzing": { en: "Analyzing...", bn: "বিশ্লেষণ করা হচ্ছে..." },
  
  // Settings
  "settings.title": { en: "Settings", bn: "সেটিংস" },
  "settings.subtitle": { en: "Manage your preferences and customize your experience", bn: "আপনার পছন্দ এবং অভিজ্ঞতা কাস্টমাইজ করুন" },
  "settings.currency": { en: "Currency Preferences", bn: "মুদ্রা পছন্দ" },
  "settings.currencyDesc": { en: "Choose your preferred currency for displaying amounts", bn: "পরিমাণ প্রদর্শনের জন্য আপনার পছন্দের মুদ্রা নির্বাচন করুন" },
  "settings.displayCurrency": { en: "Display currency", bn: "প্রদর্শন মুদ্রা" },
  "settings.language": { en: "Language", bn: "ভাষা" },
  "settings.languageDesc": { en: "Select your preferred language", bn: "আপনার পছন্দের ভাষা নির্বাচন করুন" },
  "settings.categories": { en: "Expense Categories", bn: "ব্যয় বিভাগ" },
  "settings.categoriesDesc": { en: "Manage your custom expense categories", bn: "আপনার কাস্টম ব্যয় বিভাগ পরিচালনা করুন" },
  "settings.addCategory": { en: "Add Category", bn: "বিভাগ যোগ করুন" },
  
  // Profile
  "profile.title": { en: "Profile Settings", bn: "প্রোফাইল সেটিংস" },
  "profile.subtitle": { en: "Manage your account information and preferences", bn: "আপনার অ্যাকাউন্ট তথ্য এবং পছন্দ পরিচালনা করুন" },
  "profile.picture": { en: "Profile Picture", bn: "প্রোফাইল ছবি" },
  "profile.uploadImage": { en: "Upload Image", bn: "ছবি আপলোড করুন" },
  "profile.accountInfo": { en: "Account Information", bn: "অ্যাকাউন্ট তথ্য" },
  "profile.displayName": { en: "Display Name", bn: "প্রদর্শন নাম" },
  "profile.companyName": { en: "Company Name", bn: "কোম্পানির নাম" },
  "profile.email": { en: "Email", bn: "ইমেইল" },
  "profile.saveChanges": { en: "Save Changes", bn: "পরিবর্তন সংরক্ষণ করুন" },
  
  // Email Reports
  "email.sendReport": { en: "Send Report", bn: "রিপোর্ট পাঠান" },
  "email.recipient": { en: "Recipient Email", bn: "প্রাপকের ইমেইল" },
  "email.subject": { en: "Subject", bn: "বিষয়" },
  "email.sending": { en: "Sending...", bn: "পাঠানো হচ্ছে..." },
  "email.success": { en: "Report sent successfully", bn: "রিপোর্ট সফলভাবে পাঠানো হয়েছে" },
  "email.fullReport": { en: "Full Report", bn: "সম্পূর্ণ রিপোর্ট" },
  "email.projectReport": { en: "Project Report", bn: "প্রকল্প রিপোর্ট" },
  
  // Common
  "common.save": { en: "Save", bn: "সংরক্ষণ" },
  "common.cancel": { en: "Cancel", bn: "বাতিল" },
  "common.delete": { en: "Delete", bn: "মুছে ফেলুন" },
  "common.edit": { en: "Edit", bn: "সম্পাদনা" },
  "common.add": { en: "Add", bn: "যোগ করুন" },
  "common.loading": { en: "Loading...", bn: "লোড হচ্ছে..." },
  "common.error": { en: "Error", bn: "ত্রুটি" },
  "common.success": { en: "Success", bn: "সফল" },
  "common.confirm": { en: "Confirm", bn: "নিশ্চিত করুন" },
  "common.back": { en: "Back", bn: "পেছনে" },
  "common.next": { en: "Next", bn: "পরবর্তী" },
  "common.search": { en: "Search", bn: "অনুসন্ধান" },
  "common.filter": { en: "Filter", bn: "ফিল্টার" },
  "common.export": { en: "Export", bn: "রপ্তানি" },
  "common.import": { en: "Import", bn: "আমদানি" },
  "common.download": { en: "Download", bn: "ডাউনলোড" },
  "common.pending": { en: "Pending", bn: "মুলতুবি" },
  "common.accepted": { en: "Accepted", bn: "গৃহীত" },
  "common.active": { en: "Active", bn: "সক্রিয়" },
  "common.completed": { en: "Completed", bn: "সম্পন্ন" },
  "common.onHold": { en: "On Hold", bn: "স্থগিত" },
  
  // Auth
  "auth.signIn": { en: "Sign In", bn: "সাইন ইন" },
  "auth.signUp": { en: "Sign Up", bn: "সাইন আপ" },
  "auth.email": { en: "Email", bn: "ইমেইল" },
  "auth.password": { en: "Password", bn: "পাসওয়ার্ড" },
  "auth.confirmPassword": { en: "Confirm Password", bn: "পাসওয়ার্ড নিশ্চিত করুন" },
  "auth.forgotPassword": { en: "Forgot Password?", bn: "পাসওয়ার্ড ভুলে গেছেন?" },
  "auth.noAccount": { en: "Don't have an account?", bn: "অ্যাকাউন্ট নেই?" },
  "auth.hasAccount": { en: "Already have an account?", bn: "ইতিমধ্যে অ্যাকাউন্ট আছে?" },
};

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error("useLanguage must be used within LanguageProvider");
  }
  return context;
};

export const LanguageProvider = ({ children }: { children: ReactNode }) => {
  const { profile, updateProfile } = useProfile();
  const [language, setLanguageState] = useState<Language>("en");

  useEffect(() => {
    if (profile?.language) {
      setLanguageState(profile.language as Language);
    }
  }, [profile]);

  const setLanguage = async (lang: Language) => {
    setLanguageState(lang);
    await updateProfile({ language: lang } as any);
  };

  const t = (key: string): string => {
    const translation = translations[key];
    if (!translation) return key;
    return translation[language] || translation.en || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

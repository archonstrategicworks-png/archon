import { useEffect, useState } from "react";
import Layout from "@/components/layout/Layout";
import StatsCard from "@/components/dashboard/StatsCard";
import ProjectCard from "@/components/dashboard/ProjectCard";
import ProjectForm from "@/components/forms/ProjectForm";
import RecentActivityWidget from "@/components/dashboard/RecentActivityWidget";
import ExpenseSummaryWidget from "@/components/dashboard/ExpenseSummaryWidget";
import NotificationsWidget from "@/components/dashboard/NotificationsWidget";
import CurrencySelector from "@/components/dashboard/CurrencySelector";
import ExcelExportButton from "@/components/export/ExcelExportButton";
import { supabase } from "@/integrations/supabase/client";
import { useCurrency } from "@/hooks/useCurrency";
import { 
  FolderOpen, 
  Receipt, 
  TrendingUp, 
  Wallet,
  ArrowRight 
} from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";

interface Project {
  id: string;
  project_name: string;
  client: string | null;
  start_date: string | null;
  status: string;
  budget: number | null;
}

interface ProjectWithExpenses extends Project {
  totalExpenses: number;
  expenseCount: number;
}

const Index = () => {
  const [projects, setProjects] = useState<ProjectWithExpenses[]>([]);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    totalProjects: 0,
    totalExpenses: 0,
    totalAmount: 0,
    activeProjects: 0,
  });
  const { format } = useCurrency();

  const fetchData = async () => {
    try {
      // Fetch projects
      const { data: projectsData, error: projectsError } = await supabase
        .from("projects")
        .select("*")
        .order("created_at", { ascending: false });

      if (projectsError) throw projectsError;

      // Fetch all expenses
      const { data: expensesData, error: expensesError } = await supabase
        .from("expenses")
        .select("*");

      if (expensesError) throw expensesError;

      // Calculate project expenses
      const projectsWithExpenses = (projectsData || []).map((project) => {
        const projectExpenses = (expensesData || []).filter(
          (e) => e.project_id === project.id
        );
        return {
          ...project,
          totalExpenses: projectExpenses.reduce((sum, e) => sum + Number(e.amount), 0),
          expenseCount: projectExpenses.length,
        };
      });

      setProjects(projectsWithExpenses);

      // Calculate stats
      const totalAmount = (expensesData || []).reduce(
        (sum, e) => sum + Number(e.amount),
        0
      );
      const activeProjects = (projectsData || []).filter(
        (p) => p.status === "Active"
      ).length;

      setStats({
        totalProjects: projectsData?.length || 0,
        totalExpenses: expensesData?.length || 0,
        totalAmount,
        activeProjects,
      });
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  return (
    <Layout>
      {/* Hero Section */}
      <section className="mb-10">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-2">
          <div>
            <h1 className="text-3xl md:text-4xl font-display font-bold text-foreground">
              Project Expense Tracker
            </h1>
            <p className="text-muted-foreground mt-1">
              Track, analyze, and export your construction project expenses
            </p>
          </div>
          <div className="flex flex-wrap gap-3 items-center">
            <CurrencySelector />
            <ExcelExportButton variant="all" />
            <ProjectForm onSuccess={fetchData} />
            <Link to="/upload">
              <Button variant="outline" size="lg">
                <Receipt className="w-5 h-5 mr-2" />
                Upload Receipt
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Stats Grid */}
      <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 mb-10">
        <StatsCard
          title="Total Projects"
          value={stats.totalProjects.toString()}
          icon={<FolderOpen className="w-6 h-6" />}
        />
        <StatsCard
          title="Active Projects"
          value={stats.activeProjects.toString()}
          icon={<TrendingUp className="w-6 h-6" />}
        />
        <StatsCard
          title="Total Expenses"
          value={stats.totalExpenses.toString()}
          icon={<Receipt className="w-6 h-6" />}
        />
        <StatsCard
          title="Total Amount"
          value={format(stats.totalAmount)}
          icon={<Wallet className="w-6 h-6" />}
        />
      </section>

      {/* Widgets Grid */}
      <section className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-10">
        <NotificationsWidget />
        <RecentActivityWidget />
        <ExpenseSummaryWidget />
      </section>

      {/* Projects Section */}
      <section>
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-display font-bold text-foreground">
            Your Projects
          </h2>
          <Link to="/projects">
            <Button variant="ghost" className="text-primary">
              View All
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </Link>
        </div>

        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3].map((i) => (
              <div key={i} className="bg-card rounded-xl p-6 animate-pulse">
                <div className="h-12 w-12 bg-muted rounded-xl mb-4" />
                <div className="h-6 bg-muted rounded w-3/4 mb-2" />
                <div className="h-4 bg-muted rounded w-1/2" />
              </div>
            ))}
          </div>
        ) : projects.length === 0 ? (
          <div className="text-center py-16 bg-card rounded-xl card-shadow">
            <FolderOpen className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-xl font-display font-bold text-foreground mb-2">
              No Projects Yet
            </h3>
            <p className="text-muted-foreground mb-6">
              Create your first project to start tracking expenses
            </p>
            <ProjectForm onSuccess={fetchData} />
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {projects.slice(0, 6).map((project, index) => (
              <div
                key={project.id}
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <ProjectCard
                  id={project.id}
                  name={project.project_name}
                  client={project.client}
                  startDate={project.start_date}
                  status={project.status}
                  totalExpenses={project.totalExpenses}
                  expenseCount={project.expenseCount}
                  budget={project.budget}
                />
              </div>
            ))}
          </div>
        )}
      </section>
    </Layout>
  );
};

export default Index;

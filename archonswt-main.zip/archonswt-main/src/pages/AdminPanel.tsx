import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Layout from '@/components/layout/Layout';
import { useAdmin } from '@/hooks/useAdmin';
import { useAuth } from '@/contexts/AuthContext';
import { useSessionHealth } from '@/hooks/useSessionHealth';
import { supabase } from '@/integrations/supabase/client';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Checkbox } from '@/components/ui/checkbox';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { toast } from 'sonner';
import { format } from 'date-fns';
import { EmailDiagnosticsPanel } from '@/components/admin/EmailDiagnosticsPanel';
import { 
  Shield, Users, FolderKanban, Receipt, Download, Bell, Send, Loader2, 
  UserPlus, Trash2, RefreshCw, History, Settings, CheckSquare, Mail, Activity,
  Clock, LogIn, Eye, TrendingUp, HeartPulse
} from 'lucide-react';

const AdminPanel = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { isAdmin, isLoading: adminLoading } = useAdmin();
  const { isHealthy, lastRefresh, forceRefresh } = useSessionHealth({ 
    checkInterval: 60_000, 
    refreshThreshold: 5 * 60 * 1000 
  });
  
  const [users, setUsers] = useState<any[]>([]);
  const [projects, setProjects] = useState<any[]>([]);
  const [expenses, setExpenses] = useState<any[]>([]);
  const [subscriptions, setSubscriptions] = useState<any[]>([]);
  const [auditLogs, setAuditLogs] = useState<any[]>([]);
  const [userRoles, setUserRoles] = useState<any[]>([]);
  const [userActivity, setUserActivity] = useState<any[]>([]);
  const [activityStats, setActivityStats] = useState<any>({});
  const [stats, setStats] = useState({ users: 0, projects: 0, expenses: 0, totalAmount: 0 });
  const [isLoading, setIsLoading] = useState(true);
  
  // Selection state for bulk actions
  const [selectedProjects, setSelectedProjects] = useState<Set<string>>(new Set());
  const [selectedExpenses, setSelectedExpenses] = useState<Set<string>>(new Set());
  
  // Notification form state
  const [notifTitle, setNotifTitle] = useState('');
  const [notifBody, setNotifBody] = useState('');
  const [sendEmailNotif, setSendEmailNotif] = useState(true);
  const [isSending, setIsSending] = useState(false);
  
  // Role management
  const [selectedUserId, setSelectedUserId] = useState('');
  const [selectedRole, setSelectedRole] = useState<string>('user');
  const [isAddingRole, setIsAddingRole] = useState(false);
  
  // Bulk action state
  const [bulkStatus, setBulkStatus] = useState<string>('');
  const [isProcessingBulk, setIsProcessingBulk] = useState(false);

  useEffect(() => {
    if (!adminLoading && !isAdmin) {
      toast.error('Access denied. Admin privileges required.');
      navigate('/');
    }
  }, [isAdmin, adminLoading, navigate]);

  useEffect(() => {
    if (isAdmin) {
      fetchAllData();
    }
  }, [isAdmin]);

  const fetchAllData = async () => {
    setIsLoading(true);
    try {
      await Promise.all([
        fetchUsers(), fetchProjects(), fetchExpenses(),
        fetchSubscriptions(), fetchAuditLogs(), fetchUserRoles(),
        fetchUserActivity()
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const fetchUsers = async () => {
    const { data, error } = await supabase.from('profiles').select('*').order('created_at', { ascending: false });
    if (!error && data) {
      setUsers(data);
      setStats(prev => ({ ...prev, users: data.length }));
    }
  };

  const fetchProjects = async () => {
    const { data, error } = await supabase.from('projects').select('*').order('created_at', { ascending: false });
    if (!error && data) {
      setProjects(data);
      setStats(prev => ({ ...prev, projects: data.length }));
    }
  };

  const fetchExpenses = async () => {
    const { data, error } = await supabase.from('expenses').select('*').order('created_at', { ascending: false }).limit(100);
    if (!error && data) {
      setExpenses(data);
      const total = data.reduce((sum, exp) => sum + Number(exp.amount), 0);
      setStats(prev => ({ ...prev, expenses: data.length, totalAmount: total }));
    }
  };

  const fetchSubscriptions = async () => {
    const { data, error } = await supabase.from('push_subscriptions').select('*').order('created_at', { ascending: false });
    if (!error && data) setSubscriptions(data);
  };

  const fetchAuditLogs = async () => {
    const { data, error } = await supabase.from('admin_audit_log').select('*').order('created_at', { ascending: false }).limit(50);
    if (!error && data) setAuditLogs(data);
  };

  const fetchUserRoles = async () => {
    const { data, error } = await supabase.from('user_roles').select('*').order('created_at', { ascending: false });
    if (!error && data) setUserRoles(data);
  };

  const fetchUserActivity = async () => {
    const { data, error } = await supabase
      .from('user_activity')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(200);
    if (!error && data) {
      setUserActivity(data);
      // Calculate activity stats
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const last7Days = new Date(today);
      last7Days.setDate(last7Days.getDate() - 7);
      const last30Days = new Date(today);
      last30Days.setDate(last30Days.getDate() - 30);

      const todayCount = data.filter(a => new Date(a.created_at) >= today).length;
      const weekCount = data.filter(a => new Date(a.created_at) >= last7Days).length;
      const monthCount = data.filter(a => new Date(a.created_at) >= last30Days).length;
      const loginCount = data.filter(a => a.activity_type === 'login').length;

      // Get unique active users
      const uniqueUsers = new Set(data.map(a => a.user_id)).size;

      setActivityStats({
        todayCount,
        weekCount,
        monthCount,
        loginCount,
        uniqueUsers
      });
    }
  };

  const logAdminAction = async (action: string, targetTable?: string, targetId?: string, details?: any) => {
    if (!user) return;
    await supabase.from('admin_audit_log').insert({
      admin_id: user.id, action, target_table: targetTable, target_id: targetId, details
    });
    fetchAuditLogs();
  };

  // Selection handlers
  const toggleProjectSelection = (id: string) => {
    const newSet = new Set(selectedProjects);
    if (newSet.has(id)) newSet.delete(id);
    else newSet.add(id);
    setSelectedProjects(newSet);
  };

  const toggleExpenseSelection = (id: string) => {
    const newSet = new Set(selectedExpenses);
    if (newSet.has(id)) newSet.delete(id);
    else newSet.add(id);
    setSelectedExpenses(newSet);
  };

  const selectAllProjects = () => {
    if (selectedProjects.size === projects.length) {
      setSelectedProjects(new Set());
    } else {
      setSelectedProjects(new Set(projects.map(p => p.id)));
    }
  };

  const selectAllExpenses = () => {
    if (selectedExpenses.size === expenses.length) {
      setSelectedExpenses(new Set());
    } else {
      setSelectedExpenses(new Set(expenses.map(e => e.id)));
    }
  };

  // Bulk actions
  const bulkDeleteProjects = async () => {
    if (selectedProjects.size === 0) return;
    setIsProcessingBulk(true);
    try {
      const ids = Array.from(selectedProjects);
      const { error } = await supabase.from('projects').delete().in('id', ids);
      if (error) throw error;
      await logAdminAction('bulk_delete_projects', 'projects', undefined, { count: ids.length });
      toast.success(`Deleted ${ids.length} projects`);
      setSelectedProjects(new Set());
      fetchProjects();
    } catch (error) {
      console.error('Error:', error);
      toast.error('Failed to delete projects');
    } finally {
      setIsProcessingBulk(false);
    }
  };

  const bulkDeleteExpenses = async () => {
    if (selectedExpenses.size === 0) return;
    setIsProcessingBulk(true);
    try {
      const ids = Array.from(selectedExpenses);
      const { error } = await supabase.from('expenses').delete().in('id', ids);
      if (error) throw error;
      await logAdminAction('bulk_delete_expenses', 'expenses', undefined, { count: ids.length });
      toast.success(`Deleted ${ids.length} expenses`);
      setSelectedExpenses(new Set());
      fetchExpenses();
    } catch (error) {
      console.error('Error:', error);
      toast.error('Failed to delete expenses');
    } finally {
      setIsProcessingBulk(false);
    }
  };

  const bulkUpdateProjectStatus = async () => {
    if (selectedProjects.size === 0 || !bulkStatus) return;
    setIsProcessingBulk(true);
    try {
      const ids = Array.from(selectedProjects);
      const { error } = await supabase.from('projects').update({ status: bulkStatus }).in('id', ids);
      if (error) throw error;
      await logAdminAction('bulk_update_project_status', 'projects', undefined, { count: ids.length, status: bulkStatus });
      toast.success(`Updated ${ids.length} projects to ${bulkStatus}`);
      setSelectedProjects(new Set());
      setBulkStatus('');
      fetchProjects();
    } catch (error) {
      console.error('Error:', error);
      toast.error('Failed to update projects');
    } finally {
      setIsProcessingBulk(false);
    }
  };

  const bulkUpdateExpenseStatus = async () => {
    if (selectedExpenses.size === 0 || !bulkStatus) return;
    setIsProcessingBulk(true);
    try {
      const ids = Array.from(selectedExpenses);
      const { error } = await supabase.from('expenses').update({ approval_status: bulkStatus }).in('id', ids);
      if (error) throw error;
      await logAdminAction('bulk_update_expense_status', 'expenses', undefined, { count: ids.length, status: bulkStatus });
      toast.success(`Updated ${ids.length} expenses to ${bulkStatus}`);
      setSelectedExpenses(new Set());
      setBulkStatus('');
      fetchExpenses();
    } catch (error) {
      console.error('Error:', error);
      toast.error('Failed to update expenses');
    } finally {
      setIsProcessingBulk(false);
    }
  };

  const exportSelectedData = async (type: 'projects' | 'expenses') => {
    const selectedIds = type === 'projects' ? selectedProjects : selectedExpenses;
    const data = type === 'projects' 
      ? projects.filter(p => selectedIds.has(p.id))
      : expenses.filter(e => selectedIds.has(e.id));
    
    if (data.length === 0) {
      toast.error('No items selected for export');
      return;
    }

    const csv = [
      Object.keys(data[0] || {}).join(','),
      ...data.map(row => Object.values(row).map(v => `"${v}"`).join(','))
    ].join('\n');

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${type}_selected_${format(new Date(), 'yyyy-MM-dd')}.csv`;
    a.click();
    URL.revokeObjectURL(url);

    await logAdminAction(`export_selected_${type}`, type, undefined, { count: data.length });
    toast.success(`Exported ${data.length} ${type}`);
  };

  const exportAllData = async (type: 'users' | 'projects' | 'expenses') => {
    const data = type === 'users' ? users : type === 'projects' ? projects : expenses;
    if (data.length === 0) return;

    const csv = [
      Object.keys(data[0] || {}).join(','),
      ...data.map(row => Object.values(row).map(v => `"${v}"`).join(','))
    ].join('\n');

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${type}_all_${format(new Date(), 'yyyy-MM-dd')}.csv`;
    a.click();
    URL.revokeObjectURL(url);

    await logAdminAction(`export_all_${type}`, type, undefined, { count: data.length });
    toast.success(`Exported ${data.length} ${type}`);
  };

  const sendNotification = async () => {
    if (!user || !notifTitle.trim() || !notifBody.trim()) {
      toast.error('Please fill in title and message');
      return;
    }

    setIsSending(true);
    try {
      // Save notification to database
      const { error } = await supabase.from('push_notifications').insert({
        sender_id: user.id,
        title: notifTitle.trim(),
        body: notifBody.trim(),
        sent_to_count: subscriptions.length
      });

      if (error) throw error;

      // Send email notifications via backend function
      if (sendEmailNotif) {
        const payload = { title: notifTitle.trim(), body: notifBody.trim() };

        const invokeEmail = () =>
          supabase.functions.invoke('send-notification-email', {
            body: payload,
          });

        let { error: emailError } = await invokeEmail();

        // If the session JWT is stale, refresh once and retry
        if (emailError) {
          const msg = (emailError as any)?.message ?? String(emailError);
          const status = (emailError as any)?.status;
          if (status === 401 || msg.toLowerCase().includes('invalid jwt')) {
            await supabase.auth.refreshSession();
            ({ error: emailError } = await invokeEmail());
          }
        }

        if (emailError) {
          const msg = (emailError as any)?.message ?? String(emailError);
          const status = (emailError as any)?.status;

          console.error('Email notification error:', emailError);

          if (status === 401 || msg.toLowerCase().includes('invalid jwt')) {
            toast.error('Your session expired. Please sign in again.');
            await supabase.auth.signOut();
            navigate('/auth');
          } else {
            toast.error('Email notifications failed. Please try again.');
          }
        }
      }

      // Show local notification
      if ('Notification' in window && Notification.permission === 'granted') {
        new Notification(notifTitle, { body: notifBody, icon: '/favicon.ico' });
      }

      await logAdminAction('send_notification', 'push_notifications', undefined, { 
        title: notifTitle, recipients: subscriptions.length, emailSent: sendEmailNotif 
      });
      
      toast.success(`Notification sent to ${subscriptions.length} subscribers`);
      setNotifTitle('');
      setNotifBody('');
    } catch (error) {
      console.error('Error sending notification:', error);
      toast.error('Failed to send notification');
    } finally {
      setIsSending(false);
    }
  };

  const addUserRole = async () => {
    if (!selectedUserId || !selectedRole) {
      toast.error('Please select a user and role');
      return;
    }
    setIsAddingRole(true);
    try {
      const { error } = await supabase.from('user_roles').insert([{
        user_id: selectedUserId,
        role: selectedRole as 'admin' | 'moderator' | 'user'
      }]);
      if (error) {
        if (error.code === '23505') toast.error('User already has this role');
        else throw error;
        return;
      }
      await logAdminAction('add_role', 'user_roles', selectedUserId, { role: selectedRole });
      toast.success('Role added successfully');
      setSelectedUserId('');
      setSelectedRole('user');
      fetchUserRoles();
    } catch (error) {
      console.error('Error:', error);
      toast.error('Failed to add role');
    } finally {
      setIsAddingRole(false);
    }
  };

  const removeUserRole = async (roleId: string, userId: string, role: string) => {
    try {
      const { error } = await supabase.from('user_roles').delete().eq('id', roleId);
      if (error) throw error;
      await logAdminAction('remove_role', 'user_roles', userId, { role });
      toast.success('Role removed');
      fetchUserRoles();
    } catch (error) {
      console.error('Error:', error);
      toast.error('Failed to remove role');
    }
  };

  if (adminLoading || isLoading) {
    return (
      <Layout>
        <div className="flex items-center justify-center h-96">
          <Loader2 className="h-8 w-8 animate-spin text-gold" />
        </div>
      </Layout>
    );
  }

  if (!isAdmin) return null;

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold flex items-center gap-3">
              <Shield className="w-8 h-8 text-gold" />
              Admin Panel
            </h1>
            <p className="text-muted-foreground mt-1">Manage users, data, and system settings</p>
          </div>
          <Button onClick={fetchAllData} variant="outline" size="sm">
            <RefreshCw className="mr-2 h-4 w-4" />
            Refresh
          </Button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <Users className="h-8 w-8 text-blue-500" />
                <div>
                  <p className="text-2xl font-bold">{stats.users}</p>
                  <p className="text-sm text-muted-foreground">Total Users</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <FolderKanban className="h-8 w-8 text-green-500" />
                <div>
                  <p className="text-2xl font-bold">{stats.projects}</p>
                  <p className="text-sm text-muted-foreground">Projects</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <Receipt className="h-8 w-8 text-purple-500" />
                <div>
                  <p className="text-2xl font-bold">{stats.expenses}</p>
                  <p className="text-sm text-muted-foreground">Expenses</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <Bell className="h-8 w-8 text-orange-500" />
                <div>
                  <p className="text-2xl font-bold">{subscriptions.length}</p>
                  <p className="text-sm text-muted-foreground">Subscribers</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="users" className="space-y-4">
          <TabsList className="grid grid-cols-7 w-full">
            <TabsTrigger value="users">Users</TabsTrigger>
            <TabsTrigger value="activity">Activity</TabsTrigger>
            <TabsTrigger value="projects">Projects</TabsTrigger>
            <TabsTrigger value="expenses">Expenses</TabsTrigger>
            <TabsTrigger value="notifications">Notifications</TabsTrigger>
            <TabsTrigger value="roles">Roles</TabsTrigger>
            <TabsTrigger value="audit">Audit Log</TabsTrigger>
          </TabsList>

          {/* Users Tab */}
          <TabsContent value="users">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>User Management</CardTitle>
                  <CardDescription>View and manage all registered users</CardDescription>
                </div>
                <Button onClick={() => exportAllData('users')} size="sm">
                  <Download className="mr-2 h-4 w-4" />
                  Export All CSV
                </Button>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[400px]">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Name</TableHead>
                        <TableHead>Company</TableHead>
                        <TableHead>Currency</TableHead>
                        <TableHead>Email Notif</TableHead>
                        <TableHead>Last Active</TableHead>
                        <TableHead>Joined</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {users.map((u) => (
                        <TableRow key={u.id}>
                          <TableCell className="font-medium">{u.display_name || 'N/A'}</TableCell>
                          <TableCell>{u.company_name || 'N/A'}</TableCell>
                          <TableCell>{u.preferred_currency}</TableCell>
                          <TableCell>
                            <Badge variant={(u as any).email_notifications_enabled ? 'default' : 'secondary'}>
                              {(u as any).email_notifications_enabled ? 'Enabled' : 'Disabled'}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            {(u as any).last_active_at ? (
                              <span className="flex items-center gap-1 text-sm">
                                <Clock className="h-3 w-3" />
                                {format(new Date((u as any).last_active_at), 'MMM d, HH:mm')}
                              </span>
                            ) : (
                              <span className="text-muted-foreground text-sm">Never</span>
                            )}
                          </TableCell>
                          <TableCell>{format(new Date(u.created_at), 'MMM d, yyyy')}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Activity Tab */}
          <TabsContent value="activity">
            <div className="grid md:grid-cols-4 gap-4 mb-4">
              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center gap-3">
                    <Activity className="h-6 w-6 text-green-500" />
                    <div>
                      <p className="text-xl font-bold">{activityStats.todayCount || 0}</p>
                      <p className="text-xs text-muted-foreground">Today's Activity</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center gap-3">
                    <TrendingUp className="h-6 w-6 text-blue-500" />
                    <div>
                      <p className="text-xl font-bold">{activityStats.weekCount || 0}</p>
                      <p className="text-xs text-muted-foreground">Last 7 Days</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center gap-3">
                    <LogIn className="h-6 w-6 text-purple-500" />
                    <div>
                      <p className="text-xl font-bold">{activityStats.loginCount || 0}</p>
                      <p className="text-xs text-muted-foreground">Total Logins</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center gap-3">
                    <Users className="h-6 w-6 text-orange-500" />
                    <div>
                      <p className="text-xl font-bold">{activityStats.uniqueUsers || 0}</p>
                      <p className="text-xs text-muted-foreground">Active Users</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="h-5 w-5 text-gold" />
                  User Activity Log
                </CardTitle>
                <CardDescription>Login history, page views, and user actions</CardDescription>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[400px]">
                  {userActivity.length === 0 ? (
                    <p className="text-sm text-muted-foreground text-center py-8">No activity recorded yet</p>
                  ) : (
                    <div className="space-y-2">
                      {userActivity.map((activity) => {
                        const userProfile = users.find(u => u.user_id === activity.user_id);
                        const activityIcon = activity.activity_type === 'login' ? LogIn :
                          activity.activity_type === 'page_view' ? Eye : Activity;
                        const IconComponent = activityIcon;
                        return (
                          <div key={activity.id} className="flex items-start gap-3 p-3 bg-muted/50 rounded-lg">
                            <div className="p-2 bg-primary/10 rounded">
                              <IconComponent className="h-4 w-4 text-primary" />
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2">
                                <p className="font-medium text-sm truncate">
                                  {userProfile?.display_name || activity.user_id.slice(0, 8)}
                                </p>
                                <Badge variant="outline" className="text-xs">
                                  {activity.activity_type}
                                </Badge>
                              </div>
                              {activity.metadata && Object.keys(activity.metadata).length > 0 && (
                                <p className="text-xs text-muted-foreground truncate">
                                  {JSON.stringify(activity.metadata)}
                                </p>
                              )}
                              <p className="text-xs text-muted-foreground">
                                {format(new Date(activity.created_at), 'MMM d, yyyy HH:mm:ss')}
                              </p>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Projects Tab */}
          <TabsContent value="projects">
            <Card>
              <CardHeader>
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div>
                    <CardTitle>Project Management</CardTitle>
                    <CardDescription>View and manage all projects ({selectedProjects.size} selected)</CardDescription>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <Button onClick={() => exportAllData('projects')} size="sm" variant="outline">
                      <Download className="mr-2 h-4 w-4" />
                      Export All
                    </Button>
                    {selectedProjects.size > 0 && (
                      <>
                        <Button onClick={() => exportSelectedData('projects')} size="sm" variant="outline">
                          <Download className="mr-2 h-4 w-4" />
                          Export Selected
                        </Button>
                        <Button onClick={bulkDeleteProjects} size="sm" variant="destructive" disabled={isProcessingBulk}>
                          {isProcessingBulk ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Trash2 className="mr-2 h-4 w-4" />}
                          Delete ({selectedProjects.size})
                        </Button>
                      </>
                    )}
                  </div>
                </div>
                {selectedProjects.size > 0 && (
                  <div className="flex items-center gap-2 mt-4 p-3 bg-muted rounded-lg">
                    <Select value={bulkStatus} onValueChange={setBulkStatus}>
                      <SelectTrigger className="w-40">
                        <SelectValue placeholder="Change status" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Active">Active</SelectItem>
                        <SelectItem value="On Hold">On Hold</SelectItem>
                        <SelectItem value="Completed">Completed</SelectItem>
                        <SelectItem value="Cancelled">Cancelled</SelectItem>
                      </SelectContent>
                    </Select>
                    <Button onClick={bulkUpdateProjectStatus} size="sm" disabled={!bulkStatus || isProcessingBulk}>
                      Apply Status
                    </Button>
                  </div>
                )}
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[400px]">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-12">
                          <Checkbox
                            checked={selectedProjects.size === projects.length && projects.length > 0}
                            onCheckedChange={selectAllProjects}
                          />
                        </TableHead>
                        <TableHead>Project Name</TableHead>
                        <TableHead>Client</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Budget</TableHead>
                        <TableHead>Created</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {projects.map((p) => (
                        <TableRow key={p.id} className={selectedProjects.has(p.id) ? 'bg-muted/50' : ''}>
                          <TableCell>
                            <Checkbox
                              checked={selectedProjects.has(p.id)}
                              onCheckedChange={() => toggleProjectSelection(p.id)}
                            />
                          </TableCell>
                          <TableCell className="font-medium">{p.project_name}</TableCell>
                          <TableCell>{p.client || 'N/A'}</TableCell>
                          <TableCell>
                            <Badge variant={p.status === 'Active' ? 'default' : 'secondary'}>
                              {p.status}
                            </Badge>
                          </TableCell>
                          <TableCell>{p.budget ? `৳${p.budget.toLocaleString()}` : 'N/A'}</TableCell>
                          <TableCell>{format(new Date(p.created_at), 'MMM d, yyyy')}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Expenses Tab */}
          <TabsContent value="expenses">
            <Card>
              <CardHeader>
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div>
                    <CardTitle>Expense Management</CardTitle>
                    <CardDescription>View all expenses ({selectedExpenses.size} selected)</CardDescription>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <Button onClick={() => exportAllData('expenses')} size="sm" variant="outline">
                      <Download className="mr-2 h-4 w-4" />
                      Export All
                    </Button>
                    {selectedExpenses.size > 0 && (
                      <>
                        <Button onClick={() => exportSelectedData('expenses')} size="sm" variant="outline">
                          <Download className="mr-2 h-4 w-4" />
                          Export Selected
                        </Button>
                        <Button onClick={bulkDeleteExpenses} size="sm" variant="destructive" disabled={isProcessingBulk}>
                          {isProcessingBulk ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Trash2 className="mr-2 h-4 w-4" />}
                          Delete ({selectedExpenses.size})
                        </Button>
                      </>
                    )}
                  </div>
                </div>
                {selectedExpenses.size > 0 && (
                  <div className="flex items-center gap-2 mt-4 p-3 bg-muted rounded-lg">
                    <Select value={bulkStatus} onValueChange={setBulkStatus}>
                      <SelectTrigger className="w-40">
                        <SelectValue placeholder="Change status" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="pending">Pending</SelectItem>
                        <SelectItem value="approved">Approved</SelectItem>
                        <SelectItem value="rejected">Rejected</SelectItem>
                      </SelectContent>
                    </Select>
                    <Button onClick={bulkUpdateExpenseStatus} size="sm" disabled={!bulkStatus || isProcessingBulk}>
                      Apply Status
                    </Button>
                  </div>
                )}
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[400px]">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-12">
                          <Checkbox
                            checked={selectedExpenses.size === expenses.length && expenses.length > 0}
                            onCheckedChange={selectAllExpenses}
                          />
                        </TableHead>
                        <TableHead>Date</TableHead>
                        <TableHead>Vendor</TableHead>
                        <TableHead>Category</TableHead>
                        <TableHead>Amount</TableHead>
                        <TableHead>Status</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {expenses.map((e) => (
                        <TableRow key={e.id} className={selectedExpenses.has(e.id) ? 'bg-muted/50' : ''}>
                          <TableCell>
                            <Checkbox
                              checked={selectedExpenses.has(e.id)}
                              onCheckedChange={() => toggleExpenseSelection(e.id)}
                            />
                          </TableCell>
                          <TableCell>{format(new Date(e.date), 'MMM d, yyyy')}</TableCell>
                          <TableCell>{e.vendor || 'N/A'}</TableCell>
                          <TableCell>{e.category}</TableCell>
                          <TableCell className="font-medium">
                            {e.currency} {Number(e.amount).toLocaleString()}
                          </TableCell>
                          <TableCell>
                            <Badge variant={
                              e.approval_status === 'approved' ? 'default' : 
                              e.approval_status === 'rejected' ? 'destructive' : 'secondary'
                            }>
                              {e.approval_status}
                            </Badge>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Notifications Tab */}
          <TabsContent value="notifications">
            <div className="grid gap-6 lg:grid-cols-2">
              {/* Send Notification Card */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Bell className="h-5 w-5 text-gold" />
                    Send Notification
                  </CardTitle>
                  <CardDescription>
                    Broadcast to {subscriptions.length} push subscribers and users with email notifications enabled
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Session Health Indicator */}
                  <div className="flex items-center justify-between p-2 bg-muted/50 rounded-lg text-sm">
                    <div className="flex items-center gap-2">
                      <HeartPulse className={`h-4 w-4 ${isHealthy ? 'text-green-500' : 'text-destructive'}`} />
                      <span className="text-muted-foreground">
                        Session: {isHealthy ? 'Healthy' : 'Unhealthy'}
                      </span>
                      {lastRefresh && (
                        <span className="text-xs text-muted-foreground">
                          (refreshed {lastRefresh.toLocaleTimeString()})
                        </span>
                      )}
                    </div>
                    <Button variant="ghost" size="sm" onClick={forceRefresh}>
                      <RefreshCw className="h-3 w-3" />
                    </Button>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="notif-title">Title</Label>
                    <Input
                      id="notif-title"
                      placeholder="Notification title..."
                      value={notifTitle}
                      onChange={(e) => setNotifTitle(e.target.value)}
                      maxLength={100}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="notif-body">Message</Label>
                    <Textarea
                      id="notif-body"
                      placeholder="Notification message..."
                      value={notifBody}
                      onChange={(e) => setNotifBody(e.target.value)}
                      rows={4}
                      maxLength={500}
                    />
                  </div>
                  <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                    <div className="flex items-center gap-2">
                      <Mail className="h-4 w-4 text-muted-foreground" />
                      <Label htmlFor="send-email" className="text-sm cursor-pointer">
                        Also send email to users with email notifications enabled
                      </Label>
                    </div>
                    <Switch
                      id="send-email"
                      checked={sendEmailNotif}
                      onCheckedChange={setSendEmailNotif}
                    />
                  </div>
                  <Button
                    onClick={sendNotification}
                    disabled={isSending || !notifTitle.trim() || !notifBody.trim()}
                    className="w-full bg-gold hover:bg-gold/90 text-primary"
                  >
                    {isSending ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Sending...
                      </>
                    ) : (
                      <>
                        <Send className="mr-2 h-4 w-4" />
                        Send Notification
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>

              {/* Email Diagnostics Panel */}
              <EmailDiagnosticsPanel />
            </div>
          </TabsContent>

          {/* Roles Tab */}
          <TabsContent value="roles">
            <div className="grid gap-4 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <UserPlus className="h-5 w-5" />
                    Add User Role
                  </CardTitle>
                  <CardDescription>Assign roles to users</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label>Select User</Label>
                    <Select value={selectedUserId} onValueChange={setSelectedUserId}>
                      <SelectTrigger>
                        <SelectValue placeholder="Choose a user..." />
                      </SelectTrigger>
                      <SelectContent>
                        {users.map((u) => (
                          <SelectItem key={u.user_id} value={u.user_id}>
                            {u.display_name || u.user_id.slice(0, 8)}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Role</Label>
                    <Select value={selectedRole} onValueChange={setSelectedRole}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="user">User</SelectItem>
                        <SelectItem value="moderator">Moderator</SelectItem>
                        <SelectItem value="admin">Admin</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <Button onClick={addUserRole} disabled={isAddingRole || !selectedUserId} className="w-full">
                    {isAddingRole ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <UserPlus className="mr-2 h-4 w-4" />}
                    Add Role
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Current Roles</CardTitle>
                  <CardDescription>Manage existing role assignments</CardDescription>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-[250px]">
                    {userRoles.length === 0 ? (
                      <p className="text-sm text-muted-foreground text-center py-8">No roles assigned yet</p>
                    ) : (
                      <div className="space-y-2">
                        {userRoles.map((r) => {
                          const userProfile = users.find(u => u.user_id === r.user_id);
                          return (
                            <div key={r.id} className="flex items-center justify-between p-2 bg-muted rounded-lg">
                              <div>
                                <p className="font-medium text-sm">{userProfile?.display_name || r.user_id.slice(0, 8)}</p>
                                <Badge variant={r.role === 'admin' ? 'destructive' : r.role === 'moderator' ? 'default' : 'secondary'}>
                                  {r.role}
                                </Badge>
                              </div>
                              <Button variant="ghost" size="icon" className="text-destructive" onClick={() => removeUserRole(r.id, r.user_id, r.role)}>
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </ScrollArea>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Audit Log Tab */}
          <TabsContent value="audit">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <History className="h-5 w-5 text-gold" />
                  Admin Audit Log
                </CardTitle>
                <CardDescription>Track all administrative actions</CardDescription>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[400px]">
                  {auditLogs.length === 0 ? (
                    <p className="text-sm text-muted-foreground text-center py-8">No audit logs yet</p>
                  ) : (
                    <div className="space-y-3">
                      {auditLogs.map((log) => (
                        <div key={log.id} className="flex items-start gap-3 p-3 bg-muted/50 rounded-lg">
                          <div className="p-2 bg-primary/10 rounded">
                            <Settings className="h-4 w-4 text-primary" />
                          </div>
                          <div className="flex-1">
                            <p className="font-medium text-sm">{log.action}</p>
                            {log.target_table && <p className="text-xs text-muted-foreground">Table: {log.target_table}</p>}
                            <p className="text-xs text-muted-foreground">{format(new Date(log.created_at), 'MMM d, yyyy HH:mm:ss')}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
};

export default AdminPanel;

import Layout from "@/components/layout/Layout";
import { PushNotificationPanel } from "@/components/notifications/PushNotificationPanel";
import { PushNotificationSettings } from "@/components/notifications/PushNotificationSettings";
import { Bell } from "lucide-react";

const NotificationCenter = () => {
  return (
    <Layout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-3">
            <Bell className="w-8 h-8 text-gold" />
            Notification Center
          </h1>
          <p className="text-muted-foreground mt-1">
            Manage and send push notifications to users
          </p>
        </div>

        <PushNotificationSettings />

        <PushNotificationPanel />
      </div>
    </Layout>
  );
};

export default NotificationCenter;

import Layout from "@/components/layout/Layout";
import CategoryManager from "@/components/settings/CategoryManager";
import CurrencySelector from "@/components/dashboard/CurrencySelector";
import LanguageSelector from "@/components/settings/LanguageSelector";
import { NotificationPreferences } from "@/components/notifications/NotificationPreferences";
import { useLanguage } from "@/contexts/LanguageContext";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Settings as SettingsIcon, DollarSign, Globe } from "lucide-react";

const Settings = () => {
  const { t } = useLanguage();

  return (
    <Layout>
      <div className="max-w-4xl mx-auto space-y-6">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-3">
            <SettingsIcon className="w-8 h-8" />
            {t("settings.title")}
          </h1>
          <p className="text-muted-foreground mt-1">
            {t("settings.subtitle")}
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Globe className="w-5 h-5" />
              {t("settings.language")}
            </CardTitle>
            <CardDescription>
              {t("settings.languageDesc")}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <LanguageSelector />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <DollarSign className="w-5 h-5" />
              {t("settings.currency")}
            </CardTitle>
            <CardDescription>
              {t("settings.currencyDesc")}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-4">
              <span className="text-sm text-muted-foreground">{t("settings.displayCurrency")}:</span>
              <CurrencySelector />
            </div>
          </CardContent>
        </Card>

        <NotificationPreferences />

        <CategoryManager />
      </div>
    </Layout>
  );
};

export default Settings;

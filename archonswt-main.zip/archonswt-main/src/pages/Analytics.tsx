import { useEffect, useState } from "react";
import Layout from "@/components/layout/Layout";
import MonthlyTrendChart from "@/components/analytics/MonthlyTrendChart";
import AdvancedAnalytics from "@/components/analytics/AdvancedAnalytics";
import CurrencyConverter from "@/components/currency/CurrencyConverter";
import ReportTemplateManager from "@/components/reports/ReportTemplateManager";
import PDFExportDialog from "@/components/reports/PDFExportDialog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { supabase } from "@/integrations/supabase/client";
import { useCurrency } from "@/hooks/useCurrency";
import { useLanguage } from "@/contexts/LanguageContext";
import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
} from "recharts";
import { TrendingUp, Wallet, CreditCard, Banknote, Loader2, BarChart3, PieChartIcon, FileText } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

interface Expense {
  category: string;
  payment_method: string;
  amount: number;
  project_id: string;
}

interface Project {
  id: string;
  project_name: string;
}

const Analytics = () => {
  const { toast } = useToast();
  const { format: formatCurrency } = useCurrency();
  const { t } = useLanguage();
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [aiSummary, setAiSummary] = useState<string | null>(null);
  const [loadingAI, setLoadingAI] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const { data: expensesData } = await supabase.from("expenses").select("*");
        const { data: projectsData } = await supabase.from("projects").select("id, project_name");

        setExpenses(expensesData || []);
        setProjects(projectsData || []);
      } catch (error) {
        console.error("Error fetching data:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  // Remove old formatCurrency since we use useCurrency hook

  // Category breakdown
  const categoryData = expenses.reduce((acc, e) => {
    const existing = acc.find((item) => item.name === e.category);
    if (existing) {
      existing.value += Number(e.amount);
    } else {
      acc.push({ name: e.category, value: Number(e.amount) });
    }
    return acc;
  }, [] as { name: string; value: number }[]);

  // Payment method breakdown
  const paymentData = expenses.reduce((acc, e) => {
    const existing = acc.find((item) => item.name === e.payment_method);
    if (existing) {
      existing.value += Number(e.amount);
    } else {
      acc.push({ name: e.payment_method, value: Number(e.amount) });
    }
    return acc;
  }, [] as { name: string; value: number }[]);

  // Project comparison
  const projectData = projects.map((project) => {
    const projectExpenses = expenses.filter((e) => e.project_id === project.id);
    return {
      name: project.project_name.length > 15 
        ? project.project_name.substring(0, 15) + "..." 
        : project.project_name,
      amount: projectExpenses.reduce((sum, e) => sum + Number(e.amount), 0),
    };
  }).filter((p) => p.amount > 0);

  const COLORS = ["#1E3A5F", "#C9A227", "#2E5A88", "#D4B84A", "#4A7AB3", "#E5CC6D"];

  const totalAmount = expenses.reduce((sum, e) => sum + Number(e.amount), 0);
  const cashAmount = expenses
    .filter((e) => e.payment_method === "Cash")
    .reduce((sum, e) => sum + Number(e.amount), 0);
  const bankAmount = expenses
    .filter((e) => e.payment_method === "Bank")
    .reduce((sum, e) => sum + Number(e.amount), 0);

  const generateAISummary = async () => {
    if (projects.length === 0) {
      toast({
        title: "No Data",
        description: "Add some projects first to generate a summary.",
        variant: "destructive",
      });
      return;
    }

    setLoadingAI(true);
    try {
      // Only pass project IDs - the server fetches data securely via RLS
      const { data, error } = await supabase.functions.invoke("generate-summary", {
        body: {
          projectIds: projects.map((p) => p.id),
        },
      });

      if (error) throw error;
      setAiSummary(data.summary);
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to generate summary.",
        variant: "destructive",
      });
    } finally {
      setLoadingAI(false);
    }
  };

  if (loading) {
    return (
      <Layout>
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-muted rounded w-1/3" />
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="h-32 bg-muted rounded-xl" />
            <div className="h-32 bg-muted rounded-xl" />
            <div className="h-32 bg-muted rounded-xl" />
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <section className="mb-8">
        <h1 className="text-3xl font-display font-bold text-foreground">
          Analytics
        </h1>
        <p className="text-muted-foreground mt-1">
          Insights, trends, and forecasting for your project expenses
        </p>
      </section>

      <Tabs defaultValue="advanced" className="space-y-6">
        <TabsList className="grid w-full max-w-lg grid-cols-4 h-12">
          <TabsTrigger value="advanced">
            <BarChart3 className="w-4 h-4 mr-2" />
            Advanced
          </TabsTrigger>
          <TabsTrigger value="overview">
            <PieChartIcon className="w-4 h-4 mr-2" />
            Overview
          </TabsTrigger>
          <TabsTrigger value="templates">
            <FileText className="w-4 h-4 mr-2" />
            Templates
          </TabsTrigger>
          <TabsTrigger value="currency">
            <Wallet className="w-4 h-4 mr-2" />
            Currency
          </TabsTrigger>
        </TabsList>

        <TabsContent value="advanced">
          <AdvancedAnalytics />
        </TabsContent>

        <TabsContent value="overview">
      <section className="grid grid-cols-1 md:grid-cols-3 gap-5 mb-8">
        <Card className="card-shadow">
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="p-3 rounded-xl bg-primary/10 text-primary">
                <Wallet className="w-6 h-6" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Total Spending</p>
                <p className="text-2xl font-bold font-display">{formatCurrency(totalAmount)}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="card-shadow">
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="p-3 rounded-xl bg-success/10 text-success">
                <Banknote className="w-6 h-6" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Cash Payments</p>
                <p className="text-2xl font-bold font-display">{formatCurrency(cashAmount)}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="card-shadow">
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="p-3 rounded-xl bg-accent/10 text-accent-foreground">
                <CreditCard className="w-6 h-6" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Bank Transfers</p>
                <p className="text-2xl font-bold font-display">{formatCurrency(bankAmount)}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </section>

      {/* Charts */}
      <section className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <Card className="card-shadow">
          <CardHeader>
            <CardTitle>Category Breakdown</CardTitle>
          </CardHeader>
          <CardContent>
            {categoryData.length === 0 ? (
              <div className="h-64 flex items-center justify-center text-muted-foreground">
                No expense data yet
              </div>
            ) : (
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={categoryData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {categoryData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value: number) => formatCurrency(value)} />
                </PieChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>

        <Card className="card-shadow">
          <CardHeader>
            <CardTitle>Payment Methods</CardTitle>
          </CardHeader>
          <CardContent>
            {paymentData.length === 0 ? (
              <div className="h-64 flex items-center justify-center text-muted-foreground">
                No expense data yet
              </div>
            ) : (
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={paymentData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {paymentData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value: number) => formatCurrency(value)} />
                </PieChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>
      </section>

      {/* Monthly Trend Chart */}
      <section className="mb-8">
        <MonthlyTrendChart />
      </section>

      {/* Project Comparison */}
      {projectData.length > 0 && (
        <section className="mb-8">
          <Card className="card-shadow">
            <CardHeader>
              <CardTitle>{t("analytics.projectSpending")}</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={projectData}>
                  <XAxis dataKey="name" />
                  <YAxis tickFormatter={(value) => `₹${(value / 1000).toFixed(0)}k`} />
                  <Tooltip formatter={(value: number) => formatCurrency(value)} />
                  <Legend />
                  <Bar dataKey="amount" fill="#1E3A5F" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </section>
      )}

      {/* AI Summary */}
      <section>
        <Card className="card-shadow">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-primary" />
              AI Analysis
            </CardTitle>
            <Button onClick={generateAISummary} disabled={loadingAI}>
              {loadingAI ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Analyzing...
                </>
              ) : (
                "Generate Summary"
              )}
            </Button>
          </CardHeader>
          <CardContent>
            {aiSummary ? (
              <div className="prose prose-sm max-w-none">
                <p className="text-foreground whitespace-pre-line">{aiSummary}</p>
              </div>
            ) : (
              <p className="text-muted-foreground">
                Click "Generate Summary" to get AI-powered insights about your spending patterns.
              </p>
            )}
          </CardContent>
        </Card>
      </section>
      </TabsContent>

        <TabsContent value="templates">
          <div className="space-y-4">
            <div className="flex justify-end">
              <PDFExportDialog />
            </div>
            <ReportTemplateManager />
          </div>
        </TabsContent>

        <TabsContent value="currency">
          <div className="max-w-md">
            <CurrencyConverter />
          </div>
        </TabsContent>
      </Tabs>
    </Layout>
  );
};

export default Analytics;

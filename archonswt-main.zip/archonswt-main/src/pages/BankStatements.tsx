import { useState } from "react";
import Layout from "@/components/layout/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import BankStatementUpload from "@/components/upload/BankStatementUpload";
import BankTransactionsList from "@/components/bank/BankTransactionsList";
import ExcelExportButton from "@/components/export/ExcelExportButton";
import { FileText, List, Landmark } from "lucide-react";

const BankStatements = () => {
  const [refreshKey, setRefreshKey] = useState(0);

  const handleTransactionsImported = () => {
    setRefreshKey((prev) => prev + 1);
  };

  return (
    <Layout>
      <section className="mb-8">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-3 rounded-xl bg-primary/10">
              <Landmark className="w-6 h-6 text-primary" />
            </div>
            <div>
              <h1 className="text-3xl font-display font-bold text-foreground">
                Bank Statements
              </h1>
              <p className="text-muted-foreground">
                Upload statements, detect transactions, and match to project expenses
              </p>
            </div>
          </div>
          <ExcelExportButton variant="bank" />
        </div>
      </section>

      <Tabs defaultValue="upload" className="space-y-6">
        <TabsList className="grid w-full max-w-md grid-cols-2 h-12">
          <TabsTrigger value="upload" className="text-sm font-medium">
            <FileText className="w-4 h-4 mr-2" />
            Upload Statement
          </TabsTrigger>
          <TabsTrigger value="transactions" className="text-sm font-medium">
            <List className="w-4 h-4 mr-2" />
            Transactions
          </TabsTrigger>
        </TabsList>

        <TabsContent value="upload" className="animate-fade-in">
          <Card className="card-shadow max-w-2xl">
            <CardHeader>
              <CardTitle>Upload Bank Statement</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground mb-6">
                Upload an image or PDF of your bank statement. Our AI will extract all transactions 
                and categorize them automatically. You can then link debit transactions to your project expenses.
              </p>
              <BankStatementUpload onTransactionsImported={handleTransactionsImported} />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="transactions" className="animate-fade-in">
          <Card className="card-shadow">
            <CardHeader>
              <CardTitle>Imported Transactions</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground mb-6">
                Review imported bank transactions and link them to project expenses. 
                Matched transactions help with reconciliation and audit compliance.
              </p>
              <BankTransactionsList refreshKey={refreshKey} />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </Layout>
  );
};

export default BankStatements;

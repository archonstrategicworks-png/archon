import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import Layout from "@/components/layout/Layout";
import ReceiptUpload from "@/components/upload/ReceiptUpload";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { Receipt, FolderOpen } from "lucide-react";
import { Button } from "@/components/ui/button";
import ProjectForm from "@/components/forms/ProjectForm";

interface Project {
  id: string;
  project_name: string;
}

const Upload = () => {
  const navigate = useNavigate();
  const [projects, setProjects] = useState<Project[]>([]);
  const [selectedProject, setSelectedProject] = useState<string>("");
  const [loading, setLoading] = useState(true);

  const fetchProjects = async () => {
    try {
      const { data, error } = await supabase
        .from("projects")
        .select("id, project_name")
        .order("project_name");

      if (error) throw error;
      setProjects(data || []);
    } catch (error) {
      console.error("Error fetching projects:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProjects();
  }, []);

  return (
    <Layout>
      <section className="mb-8">
        <h1 className="text-3xl font-display font-bold text-foreground">
          Upload Receipt
        </h1>
        <p className="text-muted-foreground mt-1">
          Scan receipts with AI-powered OCR to auto-fill expense entries
        </p>
      </section>

      <div className="max-w-2xl">
        <Card className="card-shadow mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FolderOpen className="w-5 h-5 text-primary" />
              Select Project
            </CardTitle>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="h-12 bg-muted animate-pulse rounded-lg" />
            ) : projects.length === 0 ? (
              <div className="text-center py-8">
                <FolderOpen className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
                <p className="text-muted-foreground mb-4">
                  Create a project first to upload receipts
                </p>
                <ProjectForm onSuccess={fetchProjects} />
              </div>
            ) : (
              <div className="space-y-2">
                <Label htmlFor="project">Project</Label>
                <Select value={selectedProject} onValueChange={setSelectedProject}>
                  <SelectTrigger className="h-12">
                    <SelectValue placeholder="Choose a project..." />
                  </SelectTrigger>
                  <SelectContent>
                    {projects.map((project) => (
                      <SelectItem key={project.id} value={project.id}>
                        {project.project_name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}
          </CardContent>
        </Card>

        {selectedProject && (
          <Card className="card-shadow animate-fade-in">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Receipt className="w-5 h-5 text-primary" />
                Upload Receipt
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground mb-6">
                Take a photo or upload an image. Our AI will extract the date, amount, and vendor details.
              </p>
              <ReceiptUpload
                projectId={selectedProject}
                onSuccess={() => navigate(`/project/${selectedProject}`)}
              />
            </CardContent>
          </Card>
        )}
      </div>
    </Layout>
  );
};

export default Upload;

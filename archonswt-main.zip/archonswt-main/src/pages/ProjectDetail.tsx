import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import Layout from "@/components/layout/Layout";
import ExpenseForm from "@/components/forms/ExpenseForm";
import ReceiptUpload from "@/components/upload/ReceiptUpload";
import ExpenseTable from "@/components/expense/ExpenseTable";
import BudgetProgress from "@/components/project/BudgetProgress";
import CollaboratorManager from "@/components/project/CollaboratorManager";
import EmailReportDialog from "@/components/email/EmailReportDialog";
import InvoiceGenerator from "@/components/invoice/InvoiceGenerator";
import ExcelExportButton from "@/components/export/ExcelExportButton";
import RecurringExpenseManager from "@/components/expense/RecurringExpenseManager";
import BudgetAlertManager from "@/components/alerts/BudgetAlertManager";
import { supabase } from "@/integrations/supabase/client";
import { useCurrency } from "@/hooks/useCurrency";
import { useLanguage } from "@/contexts/LanguageContext";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  ArrowLeft,
  Plus,
  Camera,
  FileSpreadsheet,
  Download,
  Wallet,
  TrendingUp,
  RefreshCw,
  Bell,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface Project {
  id: string;
  project_name: string;
  client: string | null;
  start_date: string | null;
  status: string;
  budget: number | null;
  budget_alert_threshold: number | null;
  user_id: string;
}

interface Expense {
  id: string;
  date: string;
  amount: number;
  payment_method: string;
  category: string;
  vendor: string | null;
  notes: string | null;
  source: string;
  created_at: string;
  file_id?: string | null;
  approval_status?: string;
  rejection_reason?: string | null;
}

const ProjectDetail = () => {
  const { id } = useParams<{ id: string }>();
  const { toast } = useToast();
  const { format: formatCurrency } = useCurrency();
  const { t } = useLanguage();
  const [project, setProject] = useState<Project | null>(null);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("expenses");

  const fetchData = async () => {
    if (!id) return;

    try {
      const { data: projectData, error: projectError } = await supabase
        .from("projects")
        .select("*")
        .eq("id", id)
        .single();

      if (projectError) throw projectError;
      setProject(projectData);

      const { data: expensesData, error: expensesError } = await supabase
        .from("expenses")
        .select("*")
        .eq("project_id", id)
        .order("date", { ascending: false });

      if (expensesError) throw expensesError;
      setExpenses(expensesData || []);
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [id]);

  const totalExpenses = expenses.reduce((sum, e) => sum + Number(e.amount), 0);

  const categoryBreakdown = expenses.reduce((acc, e) => {
    acc[e.category] = (acc[e.category] || 0) + Number(e.amount);
    return acc;
  }, {} as Record<string, number>);

  const exportToCSV = () => {
    if (expenses.length === 0) {
      toast({
        title: "No Data",
        description: "There are no expenses to export.",
        variant: "destructive",
      });
      return;
    }

    const headers = ["Date", "Category", "Vendor", "Payment Method", "Amount", "Notes", "Source"];
    const rows = expenses.map((e) => [
      e.date,
      e.category,
      e.vendor || "",
      e.payment_method,
      e.amount.toString(),
      e.notes || "",
      e.source,
    ]);

    const csvContent = [headers, ...rows].map((row) => row.join(",")).join("\n");
    const blob = new Blob([csvContent], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${project?.project_name || "expenses"}_${new Date().toISOString().split("T")[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);

    toast({
      title: "Export Complete",
      description: "CSV file downloaded successfully.",
    });
  };

  const statusColors: Record<string, string> = {
    Active: "bg-success/10 text-success border-success/20",
    Completed: "bg-primary/10 text-primary border-primary/20",
    "On Hold": "bg-warning/10 text-warning border-warning/20",
  };

  if (loading) {
    return (
      <Layout>
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-muted rounded w-1/3" />
          <div className="h-48 bg-muted rounded-xl" />
        </div>
      </Layout>
    );
  }

  if (!project) {
    return (
      <Layout>
        <div className="text-center py-16">
          <h2 className="text-2xl font-bold">Project Not Found</h2>
          <Link to="/">
            <Button className="mt-4">{t("common.back")}</Button>
          </Link>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      {/* Header */}
      <section className="mb-8">
        <Link to="/" className="inline-flex items-center text-muted-foreground hover:text-foreground mb-4 transition-colors">
          <ArrowLeft className="w-4 h-4 mr-2" />
          {t("common.back")} to Dashboard
        </Link>
        
        <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <h1 className="text-3xl font-display font-bold text-foreground">
                {project.project_name}
              </h1>
              <Badge className={`${statusColors[project.status]} border`}>
                {project.status}
              </Badge>
            </div>
            {project.client && (
              <p className="text-lg text-muted-foreground">{project.client}</p>
            )}
          </div>
          <div className="flex flex-wrap gap-2">
            <CollaboratorManager projectId={project.id} projectName={project.project_name} />
            <InvoiceGenerator 
              projectName={project.project_name}
              clientName={project.client}
              expenses={expenses}
              totalAmount={totalExpenses}
            />
            <EmailReportDialog 
              projectId={project.id}
              projectName={project.project_name}
              expenses={expenses}
              totalAmount={totalExpenses}
            />
            <ExcelExportButton 
              projectId={project.id}
              projectName={project.project_name}
              expenses={expenses}
              variant="project"
            />
          </div>
        </div>
      </section>

      {/* Budget Progress */}
      {project.budget && (
        <section className="mb-8">
          <BudgetProgress 
            budget={project.budget} 
            spent={totalExpenses}
            alertThreshold={project.budget_alert_threshold || 80}
          />
        </section>
      )}

      {/* Stats */}
      <section className="grid grid-cols-1 md:grid-cols-3 gap-5 mb-8">
        <Card className="card-shadow">
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="p-3 rounded-xl bg-primary/10 text-primary">
                <Wallet className="w-6 h-6" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">{t("dashboard.totalExpenses")}</p>
                <p className="text-2xl font-bold font-display">{formatCurrency(totalExpenses)}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="card-shadow">
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="p-3 rounded-xl bg-accent/10 text-accent-foreground">
                <FileSpreadsheet className="w-6 h-6" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">{t("project.entries")}</p>
                <p className="text-2xl font-bold font-display">{expenses.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="card-shadow">
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="p-3 rounded-xl bg-success/10 text-success">
                <TrendingUp className="w-6 h-6" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Categories</p>
                <p className="text-2xl font-bold font-display">{Object.keys(categoryBreakdown).length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </section>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full max-w-xl grid-cols-5 h-12">
          <TabsTrigger value="expenses" className="text-sm font-medium">
            <FileSpreadsheet className="w-4 h-4 mr-2" />
            Ledger
          </TabsTrigger>
          <TabsTrigger value="add" className="text-sm font-medium">
            <Plus className="w-4 h-4 mr-2" />
            {t("common.add")}
          </TabsTrigger>
          <TabsTrigger value="upload" className="text-sm font-medium">
            <Camera className="w-4 h-4 mr-2" />
            {t("nav.upload")}
          </TabsTrigger>
          <TabsTrigger value="recurring" className="text-sm font-medium">
            <RefreshCw className="w-4 h-4 mr-2" />
            Recurring
          </TabsTrigger>
          <TabsTrigger value="alerts" className="text-sm font-medium">
            <Bell className="w-4 h-4 mr-2" />
            Alerts
          </TabsTrigger>
        </TabsList>

        <TabsContent value="expenses" className="animate-fade-in">
          <Card className="card-shadow">
            <CardHeader>
              <CardTitle>Expense Ledger</CardTitle>
            </CardHeader>
            <CardContent>
              <ExpenseTable expenses={expenses} onDelete={fetchData} />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="add" className="animate-fade-in">
          <Card className="card-shadow max-w-2xl">
            <CardHeader>
              <CardTitle>{t("common.add")} Expense</CardTitle>
            </CardHeader>
            <CardContent>
              <ExpenseForm
                projectId={project.id}
                onSuccess={() => {
                  fetchData();
                  setActiveTab("expenses");
                }}
              />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="upload" className="animate-fade-in">
          <Card className="card-shadow max-w-2xl">
            <CardHeader>
              <CardTitle>{t("dashboard.uploadReceipt")}</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground mb-6">
                Take a photo or upload an image of your receipt. Our AI will extract the details automatically.
              </p>
              <ReceiptUpload
                projectId={project.id}
                onSuccess={() => {
                  fetchData();
                  setActiveTab("expenses");
                }}
              />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="recurring" className="animate-fade-in">
          <RecurringExpenseManager 
            projectId={project.id} 
            onExpenseGenerated={fetchData}
          />
        </TabsContent>

        <TabsContent value="alerts" className="animate-fade-in">
          <div className="max-w-md">
            <BudgetAlertManager
              projectId={project.id}
              projectName={project.project_name}
              budget={project.budget}
              currentSpent={totalExpenses}
            />
          </div>
        </TabsContent>
      </Tabs>

      {/* Category Breakdown */}
      {Object.keys(categoryBreakdown).length > 0 && (
        <section className="mt-8">
          <Card className="card-shadow">
            <CardHeader>
              <CardTitle>{t("analytics.categoryBreakdown")}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                {Object.entries(categoryBreakdown).map(([category, amount]) => (
                  <div
                    key={category}
                    className="p-4 rounded-xl bg-muted/50 text-center"
                  >
                    <p className="text-2xl mb-1">
                      {category === "Materials" && "🧱"}
                      {category === "Labor" && "👷"}
                      {category === "Transport" && "🚛"}
                      {category === "Fuel" && "⛽"}
                      {category === "Misc" && "📦"}
                      {category === "Equipment" && "🔧"}
                      {category === "Travel" && "🚗"}
                      {category === "Office" && "🏢"}
                      {category === "Utilities" && "⚡"}
                      {category === "Marketing" && "📢"}
                      {category === "Other" && "📦"}
                    </p>
                    <p className="text-sm text-muted-foreground mb-1">{category}</p>
                    <p className="font-bold font-display">{formatCurrency(amount)}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </section>
      )}
    </Layout>
  );
};

export default ProjectDetail;

import { useEffect, useState } from "react";
import Layout from "@/components/layout/Layout";
import ProjectCard from "@/components/dashboard/ProjectCard";
import ProjectForm from "@/components/forms/ProjectForm";
import { supabase } from "@/integrations/supabase/client";
import { Input } from "@/components/ui/input";
import { Search, FolderOpen } from "lucide-react";

interface Project {
  id: string;
  project_name: string;
  client: string | null;
  start_date: string | null;
  status: string;
}

interface ProjectWithExpenses extends Project {
  totalExpenses: number;
  expenseCount: number;
}

const Projects = () => {
  const [projects, setProjects] = useState<ProjectWithExpenses[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");

  const fetchData = async () => {
    try {
      const { data: projectsData, error: projectsError } = await supabase
        .from("projects")
        .select("*")
        .order("created_at", { ascending: false });

      if (projectsError) throw projectsError;

      const { data: expensesData, error: expensesError } = await supabase
        .from("expenses")
        .select("*");

      if (expensesError) throw expensesError;

      const projectsWithExpenses = (projectsData || []).map((project) => {
        const projectExpenses = (expensesData || []).filter(
          (e) => e.project_id === project.id
        );
        return {
          ...project,
          totalExpenses: projectExpenses.reduce((sum, e) => sum + Number(e.amount), 0),
          expenseCount: projectExpenses.length,
        };
      });

      setProjects(projectsWithExpenses);
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const filteredProjects = projects.filter(
    (p) =>
      p.project_name.toLowerCase().includes(search.toLowerCase()) ||
      p.client?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <Layout>
      <section className="mb-8">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-display font-bold text-foreground">
              All Projects
            </h1>
            <p className="text-muted-foreground mt-1">
              Manage your construction and works projects
            </p>
          </div>
          <ProjectForm onSuccess={fetchData} />
        </div>
      </section>

      <section className="mb-6">
        <div className="relative max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
          <Input
            placeholder="Search projects..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10 h-12"
          />
        </div>
      </section>

      <section>
        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <div key={i} className="bg-card rounded-xl p-6 animate-pulse">
                <div className="h-12 w-12 bg-muted rounded-xl mb-4" />
                <div className="h-6 bg-muted rounded w-3/4 mb-2" />
                <div className="h-4 bg-muted rounded w-1/2" />
              </div>
            ))}
          </div>
        ) : filteredProjects.length === 0 ? (
          <div className="text-center py-16 bg-card rounded-xl card-shadow">
            <FolderOpen className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-xl font-display font-bold text-foreground mb-2">
              {search ? "No matching projects" : "No Projects Yet"}
            </h3>
            <p className="text-muted-foreground mb-6">
              {search
                ? "Try a different search term"
                : "Create your first project to start tracking expenses"}
            </p>
            {!search && <ProjectForm onSuccess={fetchData} />}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProjects.map((project, index) => (
              <div
                key={project.id}
                style={{ animationDelay: `${index * 0.05}s` }}
              >
                <ProjectCard
                  id={project.id}
                  name={project.project_name}
                  client={project.client}
                  startDate={project.start_date}
                  status={project.status}
                  totalExpenses={project.totalExpenses}
                  expenseCount={project.expenseCount}
                />
              </div>
            ))}
          </div>
        )}
      </section>
    </Layout>
  );
};

export default Projects;

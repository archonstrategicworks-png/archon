import * as XLSX from "xlsx";

interface Expense {
  id: string;
  date: string;
  amount: number;
  payment_method: string;
  category: string;
  vendor: string | null;
  notes: string | null;
  source: string;
}

interface Project {
  id: string;
  project_name: string;
  client: string | null;
  status: string;
  budget: number | null;
}

interface BankTransaction {
  id: string;
  date: string;
  amount: number;
  description: string | null;
}

export const exportExpensesToExcel = (
  expenses: Expense[],
  projectName: string,
  currencySymbol: string = "৳"
) => {
  // Prepare data for Excel
  const data = expenses.map((expense) => ({
    Date: expense.date,
    Category: expense.category,
    Vendor: expense.vendor || "-",
    "Payment Method": expense.payment_method,
    Amount: expense.amount,
    Notes: expense.notes || "-",
    Source: expense.source,
  }));

  // Create worksheet
  const ws = XLSX.utils.json_to_sheet(data);

  // Set column widths
  ws["!cols"] = [
    { wch: 12 }, // Date
    { wch: 15 }, // Category
    { wch: 20 }, // Vendor
    { wch: 15 }, // Payment Method
    { wch: 12 }, // Amount
    { wch: 30 }, // Notes
    { wch: 10 }, // Source
  ];

  // Create workbook
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Expenses");

  // Add summary sheet
  const totalAmount = expenses.reduce((sum, e) => sum + Number(e.amount), 0);
  const categoryBreakdown = expenses.reduce((acc, e) => {
    acc[e.category] = (acc[e.category] || 0) + Number(e.amount);
    return acc;
  }, {} as Record<string, number>);

  const summaryData = [
    { Metric: "Total Expenses", Value: expenses.length },
    { Metric: "Total Amount", Value: `${currencySymbol}${totalAmount.toLocaleString()}` },
    { Metric: "", Value: "" },
    { Metric: "Category Breakdown", Value: "" },
    ...Object.entries(categoryBreakdown).map(([category, amount]) => ({
      Metric: category,
      Value: `${currencySymbol}${amount.toLocaleString()}`,
    })),
  ];

  const summaryWs = XLSX.utils.json_to_sheet(summaryData);
  summaryWs["!cols"] = [{ wch: 20 }, { wch: 20 }];
  XLSX.utils.book_append_sheet(wb, summaryWs, "Summary");

  // Generate filename
  const filename = `${projectName.replace(/[^a-z0-9]/gi, "_")}_expenses_${
    new Date().toISOString().split("T")[0]
  }.xlsx`;

  // Download file
  XLSX.writeFile(wb, filename);
};

export const exportAllProjectsToExcel = (
  projects: (Project & { expenses: Expense[] })[],
  currencySymbol: string = "৳"
) => {
  const wb = XLSX.utils.book_new();

  // Overview sheet
  const overviewData = projects.map((project) => {
    const totalExpenses = project.expenses.reduce(
      (sum, e) => sum + Number(e.amount),
      0
    );
    return {
      "Project Name": project.project_name,
      Client: project.client || "-",
      Status: project.status,
      Budget: project.budget
        ? `${currencySymbol}${project.budget.toLocaleString()}`
        : "-",
      "Total Expenses": `${currencySymbol}${totalExpenses.toLocaleString()}`,
      "Expense Count": project.expenses.length,
      "Budget Remaining": project.budget
        ? `${currencySymbol}${(project.budget - totalExpenses).toLocaleString()}`
        : "-",
    };
  });

  const overviewWs = XLSX.utils.json_to_sheet(overviewData);
  overviewWs["!cols"] = [
    { wch: 25 },
    { wch: 20 },
    { wch: 12 },
    { wch: 15 },
    { wch: 15 },
    { wch: 12 },
    { wch: 15 },
  ];
  XLSX.utils.book_append_sheet(wb, overviewWs, "Overview");

  // Individual project sheets
  projects.forEach((project) => {
    if (project.expenses.length > 0) {
      const data = project.expenses.map((expense) => ({
        Date: expense.date,
        Category: expense.category,
        Vendor: expense.vendor || "-",
        "Payment Method": expense.payment_method,
        Amount: expense.amount,
        Notes: expense.notes || "-",
        Source: expense.source,
      }));

      const ws = XLSX.utils.json_to_sheet(data);
      ws["!cols"] = [
        { wch: 12 },
        { wch: 15 },
        { wch: 20 },
        { wch: 15 },
        { wch: 12 },
        { wch: 30 },
        { wch: 10 },
      ];

      // Truncate sheet name to 31 chars (Excel limit)
      const sheetName = project.project_name.substring(0, 31).replace(/[*?:/\\[\]]/g, "_");
      XLSX.utils.book_append_sheet(wb, ws, sheetName);
    }
  });

  const filename = `all_projects_expenses_${
    new Date().toISOString().split("T")[0]
  }.xlsx`;

  XLSX.writeFile(wb, filename);
};

export const exportBankTransactionsToExcel = (
  transactions: BankTransaction[],
  currencySymbol: string = "৳"
) => {
  const data = transactions.map((tx) => ({
    Date: tx.date,
    Description: tx.description || "-",
    Amount: tx.amount,
  }));

  const ws = XLSX.utils.json_to_sheet(data);
  ws["!cols"] = [{ wch: 12 }, { wch: 40 }, { wch: 15 }];

  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Bank Transactions");

  // Summary
  const totalAmount = transactions.reduce((sum, t) => sum + Number(t.amount), 0);
  const summaryData = [
    { Metric: "Total Transactions", Value: transactions.length },
    { Metric: "Total Amount", Value: `${currencySymbol}${totalAmount.toLocaleString()}` },
  ];

  const summaryWs = XLSX.utils.json_to_sheet(summaryData);
  XLSX.utils.book_append_sheet(wb, summaryWs, "Summary");

  const filename = `bank_transactions_${
    new Date().toISOString().split("T")[0]
  }.xlsx`;

  XLSX.writeFile(wb, filename);
};

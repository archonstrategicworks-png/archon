export type Currency = 'BDT' | 'USD' | 'EUR' | 'GBP';

export const CURRENCIES: { code: Currency; name: string; symbol: string }[] = [
  { code: 'BDT', name: 'Bangladeshi Taka', symbol: '৳' },
  { code: 'USD', name: 'US Dollar', symbol: '$' },
  { code: 'EUR', name: 'Euro', symbol: '€' },
  { code: 'GBP', name: 'British Pound', symbol: '£' },
];

// Approximate exchange rates (BDT as base)
const RATES_FROM_BDT: Record<Currency, number> = {
  BDT: 1,
  USD: 0.0091,
  EUR: 0.0084,
  GBP: 0.0072,
};

export const convertCurrency = (
  amount: number,
  from: Currency,
  to: Currency
): number => {
  if (from === to) return amount;
  // Convert to BDT first, then to target currency
  const amountInBDT = amount / RATES_FROM_BDT[from];
  return amountInBDT * RATES_FROM_BDT[to];
};

export const formatCurrency = (
  amount: number,
  currency: Currency = 'BDT'
): string => {
  const currencyInfo = CURRENCIES.find(c => c.code === currency);
  const symbol = currencyInfo?.symbol || currency;
  
  const localeMap: Record<Currency, string> = {
    BDT: 'en-BD',
    USD: 'en-US',
    EUR: 'de-DE',
    GBP: 'en-GB',
  };

  return new Intl.NumberFormat(localeMap[currency], {
    style: 'currency',
    currency,
    maximumFractionDigits: currency === 'BDT' ? 0 : 2,
  }).format(amount);
};

export const getCurrencySymbol = (currency: Currency): string => {
  const currencyInfo = CURRENCIES.find(c => c.code === currency);
  return currencyInfo?.symbol || currency;
};

import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";

interface Expense {
  id: string;
  date: string;
  amount: number;
  category: string;
  vendor: string | null;
  payment_method: string;
  notes: string | null;
  tags?: string[] | null;
  approval_status?: string;
}

interface ReportTemplate {
  name: string;
  description: string | null;
  columns: string[];
  group_by: string | null;
  include_charts: boolean;
  date_range: string;
}

interface PDFExportOptions {
  template: ReportTemplate;
  expenses: Expense[];
  projectName: string;
  totalAmount: number;
  currency: string;
}

const COLUMN_LABELS: Record<string, string> = {
  date: "Date",
  vendor: "Vendor",
  category: "Category",
  amount: "Amount",
  payment_method: "Payment Method",
  notes: "Notes",
  tags: "Tags",
  approval_status: "Status",
};

const filterExpensesByDateRange = (expenses: Expense[], dateRange: string): Expense[] => {
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());

  switch (dateRange) {
    case "today":
      return expenses.filter((e) => new Date(e.date) >= today);
    case "week": {
      const weekAgo = new Date(today);
      weekAgo.setDate(weekAgo.getDate() - 7);
      return expenses.filter((e) => new Date(e.date) >= weekAgo);
    }
    case "month": {
      const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
      return expenses.filter((e) => new Date(e.date) >= monthStart);
    }
    case "quarter": {
      const quarterStart = new Date(now.getFullYear(), Math.floor(now.getMonth() / 3) * 3, 1);
      return expenses.filter((e) => new Date(e.date) >= quarterStart);
    }
    case "year": {
      const yearStart = new Date(now.getFullYear(), 0, 1);
      return expenses.filter((e) => new Date(e.date) >= yearStart);
    }
    default:
      return expenses;
  }
};

const groupExpenses = (expenses: Expense[], groupBy: string | null): Record<string, Expense[]> => {
  if (!groupBy) return { All: expenses };

  return expenses.reduce((acc, expense) => {
    const key = (expense as any)[groupBy] || "Unknown";
    if (!acc[key]) acc[key] = [];
    acc[key].push(expense);
    return acc;
  }, {} as Record<string, Expense[]>);
};

const formatCurrency = (amount: number, currency: string): string => {
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: currency,
    maximumFractionDigits: 2,
  }).format(amount);
};

export const generatePDFReport = ({
  template,
  expenses,
  projectName,
  totalAmount,
  currency,
}: PDFExportOptions): void => {
  const doc = new jsPDF();
  const pageWidth = doc.internal.pageSize.getWidth();
  let yPosition = 20;

  // Title
  doc.setFontSize(20);
  doc.setFont("helvetica", "bold");
  doc.text(template.name, pageWidth / 2, yPosition, { align: "center" });
  yPosition += 10;

  // Project name
  doc.setFontSize(14);
  doc.setFont("helvetica", "normal");
  doc.text(`Project: ${projectName}`, pageWidth / 2, yPosition, { align: "center" });
  yPosition += 8;

  // Date range
  doc.setFontSize(10);
  doc.setTextColor(100);
  const dateRangeLabel = template.date_range === "all" ? "All Time" : template.date_range.charAt(0).toUpperCase() + template.date_range.slice(1);
  doc.text(`Date Range: ${dateRangeLabel}`, pageWidth / 2, yPosition, { align: "center" });
  yPosition += 5;

  // Generated date
  doc.text(`Generated: ${new Date().toLocaleDateString()}`, pageWidth / 2, yPosition, { align: "center" });
  yPosition += 10;

  // Description
  if (template.description) {
    doc.setFontSize(10);
    doc.setTextColor(80);
    const descLines = doc.splitTextToSize(template.description, pageWidth - 40);
    doc.text(descLines, pageWidth / 2, yPosition, { align: "center" });
    yPosition += descLines.length * 5 + 5;
  }

  doc.setTextColor(0);

  // Filter expenses by date range
  const filteredExpenses = filterExpensesByDateRange(expenses, template.date_range);

  // Summary box
  doc.setFillColor(30, 58, 95);
  doc.rect(14, yPosition, pageWidth - 28, 25, "F");
  doc.setTextColor(255);
  doc.setFontSize(12);
  doc.setFont("helvetica", "bold");
  doc.text("Summary", 20, yPosition + 8);
  doc.setFontSize(16);
  doc.text(formatCurrency(filteredExpenses.reduce((sum, e) => sum + Number(e.amount), 0), currency), 20, yPosition + 18);
  doc.setFontSize(10);
  doc.setFont("helvetica", "normal");
  doc.text(`${filteredExpenses.length} expenses`, pageWidth - 20, yPosition + 13, { align: "right" });
  yPosition += 35;

  doc.setTextColor(0);

  // Group expenses
  const groupedExpenses = groupExpenses(filteredExpenses, template.group_by);

  // Generate tables for each group
  Object.entries(groupedExpenses).forEach(([groupName, groupExpenses]) => {
    if (template.group_by && groupName !== "All") {
      // Group header
      doc.setFontSize(12);
      doc.setFont("helvetica", "bold");
      doc.text(groupName, 14, yPosition);
      const groupTotal = groupExpenses.reduce((sum, e) => sum + Number(e.amount), 0);
      doc.setFont("helvetica", "normal");
      doc.setFontSize(10);
      doc.text(`(${formatCurrency(groupTotal, currency)})`, 14 + doc.getTextWidth(groupName) + 5, yPosition);
      yPosition += 8;
    }

    // Prepare table data
    const headers = template.columns.map((col) => COLUMN_LABELS[col] || col);
    const rows = groupExpenses.map((expense) =>
      template.columns.map((col) => {
        const value = (expense as any)[col];
        if (col === "amount") return formatCurrency(Number(value), currency);
        if (col === "tags" && Array.isArray(value)) return value.join(", ");
        if (col === "date") return new Date(value).toLocaleDateString();
        return value || "-";
      })
    );

    autoTable(doc, {
      startY: yPosition,
      head: [headers],
      body: rows,
      theme: "striped",
      headStyles: {
        fillColor: [30, 58, 95],
        textColor: 255,
        fontStyle: "bold",
      },
      alternateRowStyles: {
        fillColor: [245, 245, 245],
      },
      margin: { left: 14, right: 14 },
      didDrawPage: (data) => {
        // Footer with page number
        doc.setFontSize(8);
        doc.setTextColor(150);
        doc.text(
          `Page ${doc.getCurrentPageInfo().pageNumber}`,
          pageWidth / 2,
          doc.internal.pageSize.getHeight() - 10,
          { align: "center" }
        );
      },
    });

    yPosition = (doc as any).lastAutoTable.finalY + 15;

    // Check if we need a new page
    if (yPosition > doc.internal.pageSize.getHeight() - 40) {
      doc.addPage();
      yPosition = 20;
    }
  });

  // Category breakdown if include_charts is enabled
  if (template.include_charts && filteredExpenses.length > 0) {
    const categoryBreakdown = filteredExpenses.reduce((acc, e) => {
      acc[e.category] = (acc[e.category] || 0) + Number(e.amount);
      return acc;
    }, {} as Record<string, number>);

    // Check if we need a new page
    if (yPosition > doc.internal.pageSize.getHeight() - 80) {
      doc.addPage();
      yPosition = 20;
    }

    doc.setFontSize(12);
    doc.setFont("helvetica", "bold");
    doc.setTextColor(0);
    doc.text("Category Breakdown", 14, yPosition);
    yPosition += 8;

    const categoryData = Object.entries(categoryBreakdown)
      .sort((a, b) => b[1] - a[1])
      .map(([category, amount]) => [
        category,
        formatCurrency(amount, currency),
        `${((amount / filteredExpenses.reduce((sum, e) => sum + Number(e.amount), 0)) * 100).toFixed(1)}%`,
      ]);

    autoTable(doc, {
      startY: yPosition,
      head: [["Category", "Amount", "Percentage"]],
      body: categoryData,
      theme: "striped",
      headStyles: {
        fillColor: [201, 162, 39],
        textColor: 255,
        fontStyle: "bold",
      },
      margin: { left: 14, right: 14 },
    });
  }

  // Save the PDF
  const fileName = `${template.name.replace(/[^a-z0-9]/gi, "_")}_${projectName.replace(/[^a-z0-9]/gi, "_")}_${new Date().toISOString().split("T")[0]}.pdf`;
  doc.save(fileName);
};

import { useProfile } from "@/hooks/useProfile";
import { Currency, formatCurrency, convertCurrency, getCurrencySymbol } from "@/lib/currency";

export const useCurrency = () => {
  const { profile, updateProfile } = useProfile();
  
  const currency = (profile?.preferred_currency as Currency) || 'BDT';
  const symbol = getCurrencySymbol(currency);

  const setCurrency = async (newCurrency: Currency) => {
    await updateProfile({ preferred_currency: newCurrency });
  };

  const format = (amount: number, fromCurrency?: Currency) => {
    if (fromCurrency && fromCurrency !== currency) {
      const converted = convertCurrency(amount, fromCurrency, currency);
      return formatCurrency(converted, currency);
    }
    return formatCurrency(amount, currency);
  };

  const convert = (amount: number, from: Currency, to?: Currency) => {
    return convertCurrency(amount, from, to || currency);
  };

  return { currency, symbol, setCurrency, format, convert };
};

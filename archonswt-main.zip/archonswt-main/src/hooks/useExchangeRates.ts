import { useState, useEffect, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";

export type Currency = 
  | "BDT" | "USD" | "EUR" | "GBP" | "INR" 
  | "AED" | "SAR" | "MYR" | "SGD" | "CAD" 
  | "AUD" | "JPY" | "CNY";

export interface CurrencyInfo {
  code: Currency;
  name: string;
  symbol: string;
}

export const CURRENCIES: CurrencyInfo[] = [
  { code: "BDT", name: "Bangladeshi Taka", symbol: "৳" },
  { code: "USD", name: "US Dollar", symbol: "$" },
  { code: "EUR", name: "Euro", symbol: "€" },
  { code: "GBP", name: "British Pound", symbol: "£" },
  { code: "INR", name: "Indian Rupee", symbol: "₹" },
  { code: "AED", name: "UAE Dirham", symbol: "د.إ" },
  { code: "SAR", name: "Saudi Riyal", symbol: "﷼" },
  { code: "MYR", name: "Malaysian Ringgit", symbol: "RM" },
  { code: "SGD", name: "Singapore Dollar", symbol: "S$" },
  { code: "CAD", name: "Canadian Dollar", symbol: "C$" },
  { code: "AUD", name: "Australian Dollar", symbol: "A$" },
  { code: "JPY", name: "Japanese Yen", symbol: "¥" },
  { code: "CNY", name: "Chinese Yuan", symbol: "¥" },
];

interface ExchangeRate {
  base_currency: string;
  target_currency: string;
  rate: number;
  updated_at: string;
}

export const useExchangeRates = () => {
  const [rates, setRates] = useState<Record<string, number>>({});
  const [loading, setLoading] = useState(true);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);

  const fetchRates = useCallback(async () => {
    try {
      const { data, error } = await supabase
        .from("exchange_rates")
        .select("*");

      if (error) throw error;

      const rateMap: Record<string, number> = {};
      (data as ExchangeRate[] || []).forEach((r) => {
        rateMap[`${r.base_currency}_${r.target_currency}`] = r.rate;
        if (r.updated_at) {
          const updated = new Date(r.updated_at);
          if (!lastUpdated || updated > lastUpdated) {
            setLastUpdated(updated);
          }
        }
      });

      // Add identity rates
      CURRENCIES.forEach((c) => {
        rateMap[`${c.code}_${c.code}`] = 1;
      });

      setRates(rateMap);
    } catch (error) {
      console.error("Error fetching exchange rates:", error);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchRates();
  }, [fetchRates]);

  const convert = useCallback(
    (amount: number, from: Currency, to: Currency): number => {
      if (from === to) return amount;
      const rate = rates[`${from}_${to}`];
      if (!rate) {
        console.warn(`No exchange rate found for ${from} to ${to}`);
        return amount;
      }
      return amount * rate;
    },
    [rates]
  );

  const getRate = useCallback(
    (from: Currency, to: Currency): number | null => {
      if (from === to) return 1;
      return rates[`${from}_${to}`] || null;
    },
    [rates]
  );

  const refreshRates = async () => {
    setLoading(true);
    try {
      await supabase.functions.invoke("fetch-exchange-rates");
      await fetchRates();
    } catch (error) {
      console.error("Error refreshing rates:", error);
    } finally {
      setLoading(false);
    }
  };

  return {
    rates,
    loading,
    lastUpdated,
    convert,
    getRate,
    refreshRates,
  };
};

export const getCurrencySymbol = (currency: Currency): string => {
  const info = CURRENCIES.find((c) => c.code === currency);
  return info?.symbol || currency;
};

export const formatCurrencyAmount = (
  amount: number,
  currency: Currency = "BDT"
): string => {
  const symbol = getCurrencySymbol(currency);
  const decimals = currency === "BDT" || currency === "JPY" ? 0 : 2;

  return `${symbol}${amount.toLocaleString(undefined, {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  })}`;
};

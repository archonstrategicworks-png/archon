import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

export interface ExpenseCategory {
  id: string;
  user_id: string;
  name: string;
  icon: string | null;
  color: string | null;
  is_default: boolean;
  created_at: string;
}

export const useExpenseCategories = () => {
  const { user } = useAuth();
  const [categories, setCategories] = useState<ExpenseCategory[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchCategories = async () => {
    if (!user) {
      setCategories([]);
      setLoading(false);
      return;
    }

    try {
      const { data, error } = await supabase
        .from("expense_categories")
        .select("*")
        .eq("user_id", user.id)
        .order("is_default", { ascending: false })
        .order("name");

      if (error) throw error;
      setCategories(data || []);
    } catch (error) {
      console.error("Error fetching categories:", error);
    } finally {
      setLoading(false);
    }
  };

  const addCategory = async (name: string, icon?: string, color?: string) => {
    if (!user) return { error: new Error("Not authenticated") };

    const { data, error } = await supabase
      .from("expense_categories")
      .insert({
        user_id: user.id,
        name,
        icon: icon || null,
        color: color || null,
        is_default: false,
      })
      .select()
      .single();

    if (!error) {
      await fetchCategories();
    }

    return { data, error };
  };

  const updateCategory = async (id: string, updates: Partial<Pick<ExpenseCategory, "name" | "icon" | "color">>) => {
    const { data, error } = await supabase
      .from("expense_categories")
      .update(updates)
      .eq("id", id)
      .select()
      .single();

    if (!error) {
      await fetchCategories();
    }

    return { data, error };
  };

  const deleteCategory = async (id: string) => {
    const { error } = await supabase
      .from("expense_categories")
      .delete()
      .eq("id", id);

    if (!error) {
      await fetchCategories();
    }

    return { error };
  };

  useEffect(() => {
    fetchCategories();
  }, [user]);

  return {
    categories,
    loading,
    addCategory,
    updateCategory,
    deleteCategory,
    refetchCategories: fetchCategories,
  };
};

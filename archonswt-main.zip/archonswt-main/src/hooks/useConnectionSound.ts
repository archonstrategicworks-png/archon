import { useCallback, useRef } from "react";

// Create a futuristic connection sound using Web Audio API
export const useConnectionSound = () => {
  const audioContextRef = useRef<AudioContext | null>(null);

  const playConnectionSound = useCallback(() => {
    try {
      // Create or reuse audio context
      if (!audioContextRef.current) {
        audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      }
      
      const audioContext = audioContextRef.current;
      const currentTime = audioContext.currentTime;

      // Create master gain for overall volume control
      const masterGain = audioContext.createGain();
      masterGain.gain.setValueAtTime(0.3, currentTime);
      masterGain.connect(audioContext.destination);

      // Sound 1: Rising sweep (satellite connecting)
      const osc1 = audioContext.createOscillator();
      const gain1 = audioContext.createGain();
      osc1.type = "sine";
      osc1.frequency.setValueAtTime(200, currentTime);
      osc1.frequency.exponentialRampToValueAtTime(800, currentTime + 0.3);
      gain1.gain.setValueAtTime(0, currentTime);
      gain1.gain.linearRampToValueAtTime(0.4, currentTime + 0.1);
      gain1.gain.exponentialRampToValueAtTime(0.01, currentTime + 0.5);
      osc1.connect(gain1);
      gain1.connect(masterGain);
      osc1.start(currentTime);
      osc1.stop(currentTime + 0.5);

      // Sound 2: Confirmation beeps
      const playBeep = (startTime: number, frequency: number) => {
        const osc = audioContext.createOscillator();
        const gain = audioContext.createGain();
        osc.type = "square";
        osc.frequency.setValueAtTime(frequency, startTime);
        gain.gain.setValueAtTime(0, startTime);
        gain.gain.linearRampToValueAtTime(0.15, startTime + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.01, startTime + 0.15);
        osc.connect(gain);
        gain.connect(masterGain);
        osc.start(startTime);
        osc.stop(startTime + 0.15);
      };

      playBeep(currentTime + 0.3, 1200);
      playBeep(currentTime + 0.45, 1400);
      playBeep(currentTime + 0.6, 1800);

      // Sound 3: Success chord
      const playChord = (startTime: number) => {
        const frequencies = [523.25, 659.25, 783.99]; // C5, E5, G5 - major chord
        
        frequencies.forEach((freq, index) => {
          const osc = audioContext.createOscillator();
          const gain = audioContext.createGain();
          osc.type = "sine";
          osc.frequency.setValueAtTime(freq, startTime);
          gain.gain.setValueAtTime(0, startTime);
          gain.gain.linearRampToValueAtTime(0.2, startTime + 0.05);
          gain.gain.exponentialRampToValueAtTime(0.01, startTime + 0.8);
          osc.connect(gain);
          gain.connect(masterGain);
          osc.start(startTime + index * 0.03);
          osc.stop(startTime + 1);
        });
      };

      playChord(currentTime + 0.75);

      // Sound 4: Data transmission noise (white noise burst)
      const bufferSize = audioContext.sampleRate * 0.2;
      const noiseBuffer = audioContext.createBuffer(1, bufferSize, audioContext.sampleRate);
      const output = noiseBuffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        output[i] = Math.random() * 2 - 1;
      }
      
      const noiseSource = audioContext.createBufferSource();
      noiseSource.buffer = noiseBuffer;
      
      const noiseFilter = audioContext.createBiquadFilter();
      noiseFilter.type = "bandpass";
      noiseFilter.frequency.setValueAtTime(2000, currentTime);
      noiseFilter.Q.setValueAtTime(5, currentTime);
      
      const noiseGain = audioContext.createGain();
      noiseGain.gain.setValueAtTime(0.1, currentTime + 0.2);
      noiseGain.gain.exponentialRampToValueAtTime(0.01, currentTime + 0.4);
      
      noiseSource.connect(noiseFilter);
      noiseFilter.connect(noiseGain);
      noiseGain.connect(masterGain);
      noiseSource.start(currentTime + 0.2);

    } catch (error) {
      console.error("Failed to play connection sound:", error);
    }
  }, []);

  return { playConnectionSound };
};

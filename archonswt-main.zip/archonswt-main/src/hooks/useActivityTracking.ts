import { useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

type ActivityType = 'login' | 'logout' | 'page_view' | 'action';

export function useActivityTracking() {
  const { user } = useAuth();

  const trackActivity = useCallback(async (
    activityType: ActivityType,
    metadata: Record<string, any> = {}
  ) => {
    if (!user) return;

    try {
      await supabase.from('user_activity').insert({
        user_id: user.id,
        activity_type: activityType,
        user_agent: navigator.userAgent,
        metadata
      });
    } catch (error) {
      console.error('Failed to track activity:', error);
    }
  }, [user]);

  // Track login on mount when user exists
  useEffect(() => {
    if (user) {
      trackActivity('login', { source: 'session_start' });
    }
  }, [user?.id]);

  return { trackActivity };
}

import { useEffect, useRef, useCallback, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { useNavigate } from 'react-router-dom';

interface SessionHealthOptions {
  /** Interval in ms to check session health (default: 60000 = 1 min) */
  checkInterval?: number;
  /** How many ms before token expiry to trigger refresh (default: 300000 = 5 min) */
  refreshThreshold?: number;
  /** Whether to redirect to /auth on session loss (default: true) */
  redirectOnExpiry?: boolean;
}

export function useSessionHealth(options: SessionHealthOptions = {}) {
  const {
    checkInterval = 60_000,
    refreshThreshold = 5 * 60 * 1000,
    redirectOnExpiry = true,
  } = options;

  const navigate = useNavigate();
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  const [isHealthy, setIsHealthy] = useState(true);
  const [lastRefresh, setLastRefresh] = useState<Date | null>(null);

  const checkAndRefresh = useCallback(async () => {
    try {
      const { data: { session }, error } = await supabase.auth.getSession();

      if (error || !session) {
        console.warn('[SessionHealth] No active session');
        setIsHealthy(false);
        if (redirectOnExpiry) {
          toast.error('Your session has expired. Please sign in again.');
          navigate('/auth');
        }
        return false;
      }

      // Check if token is close to expiring
      const expiresAt = session.expires_at ? session.expires_at * 1000 : 0;
      const now = Date.now();
      const timeUntilExpiry = expiresAt - now;

      if (timeUntilExpiry < refreshThreshold) {
        console.log('[SessionHealth] Token expiring soon, refreshing...');
        const { data, error: refreshError } = await supabase.auth.refreshSession();

        if (refreshError || !data.session) {
          console.error('[SessionHealth] Failed to refresh session:', refreshError);
          setIsHealthy(false);
          if (redirectOnExpiry) {
            toast.error('Session refresh failed. Please sign in again.');
            await supabase.auth.signOut();
            navigate('/auth');
          }
          return false;
        }

        console.log('[SessionHealth] Session refreshed successfully');
        setLastRefresh(new Date());
        toast.success('Session refreshed', { duration: 2000 });
      }

      setIsHealthy(true);
      return true;
    } catch (err) {
      console.error('[SessionHealth] Error checking session:', err);
      setIsHealthy(false);
      return false;
    }
  }, [navigate, redirectOnExpiry, refreshThreshold]);

  // Manual refresh function for components to use
  const forceRefresh = useCallback(async () => {
    const { data, error } = await supabase.auth.refreshSession();
    if (error || !data.session) {
      setIsHealthy(false);
      toast.error('Failed to refresh session');
      return false;
    }
    setLastRefresh(new Date());
    setIsHealthy(true);
    return true;
  }, []);

  useEffect(() => {
    // Initial check
    checkAndRefresh();

    // Set up periodic checks
    intervalRef.current = setInterval(checkAndRefresh, checkInterval);

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [checkAndRefresh, checkInterval]);

  return {
    isHealthy,
    lastRefresh,
    forceRefresh,
    checkNow: checkAndRefresh,
  };
}

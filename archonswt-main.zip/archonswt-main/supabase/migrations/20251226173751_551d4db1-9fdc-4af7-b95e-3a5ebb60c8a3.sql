-- Add explicit deny policies for anonymous users on all sensitive tables
-- This prevents unauthenticated access to user data

-- Profiles table - deny anonymous access
CREATE POLICY "Deny anonymous access to profiles"
ON public.profiles FOR SELECT
TO anon
USING (false);

CREATE POLICY "Deny anonymous insert to profiles"
ON public.profiles FOR INSERT
TO anon
WITH CHECK (false);

CREATE POLICY "Deny anonymous update to profiles"
ON public.profiles FOR UPDATE
TO anon
USING (false);

-- Projects table - deny anonymous access
CREATE POLICY "Deny anonymous access to projects"
ON public.projects FOR SELECT
TO anon
USING (false);

CREATE POLICY "Deny anonymous insert to projects"
ON public.projects FOR INSERT
TO anon
WITH CHECK (false);

CREATE POLICY "Deny anonymous update to projects"
ON public.projects FOR UPDATE
TO anon
USING (false);

CREATE POLICY "Deny anonymous delete to projects"
ON public.projects FOR DELETE
TO anon
USING (false);

-- Expenses table - deny anonymous access
CREATE POLICY "Deny anonymous access to expenses"
ON public.expenses FOR SELECT
TO anon
USING (false);

CREATE POLICY "Deny anonymous insert to expenses"
ON public.expenses FOR INSERT
TO anon
WITH CHECK (false);

CREATE POLICY "Deny anonymous update to expenses"
ON public.expenses FOR UPDATE
TO anon
USING (false);

CREATE POLICY "Deny anonymous delete to expenses"
ON public.expenses FOR DELETE
TO anon
USING (false);

-- Project collaborators - deny anonymous access
CREATE POLICY "Deny anonymous access to project_collaborators"
ON public.project_collaborators FOR SELECT
TO anon
USING (false);

CREATE POLICY "Deny anonymous insert to project_collaborators"
ON public.project_collaborators FOR INSERT
TO anon
WITH CHECK (false);

CREATE POLICY "Deny anonymous update to project_collaborators"
ON public.project_collaborators FOR UPDATE
TO anon
USING (false);

CREATE POLICY "Deny anonymous delete to project_collaborators"
ON public.project_collaborators FOR DELETE
TO anon
USING (false);

-- Uploads table - deny anonymous access
CREATE POLICY "Deny anonymous access to uploads"
ON public.uploads FOR SELECT
TO anon
USING (false);

CREATE POLICY "Deny anonymous insert to uploads"
ON public.uploads FOR INSERT
TO anon
WITH CHECK (false);

CREATE POLICY "Deny anonymous delete to uploads"
ON public.uploads FOR DELETE
TO anon
USING (false);

-- Bank transactions - deny anonymous access
CREATE POLICY "Deny anonymous access to bank_transactions"
ON public.bank_transactions FOR SELECT
TO anon
USING (false);

CREATE POLICY "Deny anonymous insert to bank_transactions"
ON public.bank_transactions FOR INSERT
TO anon
WITH CHECK (false);

CREATE POLICY "Deny anonymous update to bank_transactions"
ON public.bank_transactions FOR UPDATE
TO anon
USING (false);

CREATE POLICY "Deny anonymous delete to bank_transactions"
ON public.bank_transactions FOR DELETE
TO anon
USING (false);

-- Expense categories - deny anonymous access
CREATE POLICY "Deny anonymous access to expense_categories"
ON public.expense_categories FOR SELECT
TO anon
USING (false);

CREATE POLICY "Deny anonymous insert to expense_categories"
ON public.expense_categories FOR INSERT
TO anon
WITH CHECK (false);

CREATE POLICY "Deny anonymous update to expense_categories"
ON public.expense_categories FOR UPDATE
TO anon
USING (false);

CREATE POLICY "Deny anonymous delete to expense_categories"
ON public.expense_categories FOR DELETE
TO anon
USING (false);

-- Report templates - deny anonymous access
CREATE POLICY "Deny anonymous access to report_templates"
ON public.report_templates FOR SELECT
TO anon
USING (false);

CREATE POLICY "Deny anonymous insert to report_templates"
ON public.report_templates FOR INSERT
TO anon
WITH CHECK (false);

CREATE POLICY "Deny anonymous update to report_templates"
ON public.report_templates FOR UPDATE
TO anon
USING (false);

CREATE POLICY "Deny anonymous delete to report_templates"
ON public.report_templates FOR DELETE
TO anon
USING (false);

-- Budget alerts - deny anonymous access
CREATE POLICY "Deny anonymous access to budget_alerts"
ON public.budget_alerts FOR SELECT
TO anon
USING (false);

CREATE POLICY "Deny anonymous insert to budget_alerts"
ON public.budget_alerts FOR INSERT
TO anon
WITH CHECK (false);

CREATE POLICY "Deny anonymous update to budget_alerts"
ON public.budget_alerts FOR UPDATE
TO anon
USING (false);

CREATE POLICY "Deny anonymous delete to budget_alerts"
ON public.budget_alerts FOR DELETE
TO anon
USING (false);

-- User activity - deny anonymous access
CREATE POLICY "Deny anonymous access to user_activity"
ON public.user_activity FOR SELECT
TO anon
USING (false);

CREATE POLICY "Deny anonymous insert to user_activity"
ON public.user_activity FOR INSERT
TO anon
WITH CHECK (false);

-- Recurring expenses - deny anonymous access
CREATE POLICY "Deny anonymous access to recurring_expenses"
ON public.recurring_expenses FOR SELECT
TO anon
USING (false);

CREATE POLICY "Deny anonymous insert to recurring_expenses"
ON public.recurring_expenses FOR INSERT
TO anon
WITH CHECK (false);

CREATE POLICY "Deny anonymous update to recurring_expenses"
ON public.recurring_expenses FOR UPDATE
TO anon
USING (false);

CREATE POLICY "Deny anonymous delete to recurring_expenses"
ON public.recurring_expenses FOR DELETE
TO anon
USING (false);

-- Project custom fields - deny anonymous access
CREATE POLICY "Deny anonymous access to project_custom_fields"
ON public.project_custom_fields FOR SELECT
TO anon
USING (false);

CREATE POLICY "Deny anonymous insert to project_custom_fields"
ON public.project_custom_fields FOR INSERT
TO anon
WITH CHECK (false);

CREATE POLICY "Deny anonymous update to project_custom_fields"
ON public.project_custom_fields FOR UPDATE
TO anon
USING (false);

CREATE POLICY "Deny anonymous delete to project_custom_fields"
ON public.project_custom_fields FOR DELETE
TO anon
USING (false);

-- Expense custom values - deny anonymous access
CREATE POLICY "Deny anonymous access to expense_custom_values"
ON public.expense_custom_values FOR SELECT
TO anon
USING (false);

CREATE POLICY "Deny anonymous insert to expense_custom_values"
ON public.expense_custom_values FOR INSERT
TO anon
WITH CHECK (false);

CREATE POLICY "Deny anonymous update to expense_custom_values"
ON public.expense_custom_values FOR UPDATE
TO anon
USING (false);

CREATE POLICY "Deny anonymous delete to expense_custom_values"
ON public.expense_custom_values FOR DELETE
TO anon
USING (false);

-- Push subscriptions - deny anonymous access
CREATE POLICY "Deny anonymous access to push_subscriptions"
ON public.push_subscriptions FOR SELECT
TO anon
USING (false);

CREATE POLICY "Deny anonymous insert to push_subscriptions"
ON public.push_subscriptions FOR INSERT
TO anon
WITH CHECK (false);

CREATE POLICY "Deny anonymous delete to push_subscriptions"
ON public.push_subscriptions FOR DELETE
TO anon
USING (false);

-- Push notifications - deny anonymous access
CREATE POLICY "Deny anonymous access to push_notifications"
ON public.push_notifications FOR SELECT
TO anon
USING (false);

CREATE POLICY "Deny anonymous insert to push_notifications"
ON public.push_notifications FOR INSERT
TO anon
WITH CHECK (false);

-- User roles - deny anonymous access
CREATE POLICY "Deny anonymous access to user_roles"
ON public.user_roles FOR SELECT
TO anon
USING (false);

-- Admin audit log - deny anonymous access
CREATE POLICY "Deny anonymous access to admin_audit_log"
ON public.admin_audit_log FOR SELECT
TO anon
USING (false);

CREATE POLICY "Deny anonymous insert to admin_audit_log"
ON public.admin_audit_log FOR INSERT
TO anon
WITH CHECK (false);
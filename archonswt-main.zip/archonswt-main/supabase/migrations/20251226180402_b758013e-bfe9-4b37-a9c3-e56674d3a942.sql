-- Create a security definer function to check if user is a project collaborator
-- This avoids infinite recursion between projects and project_collaborators policies
CREATE OR REPLACE FUNCTION public.is_project_collaborator(_user_id uuid, _project_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.project_collaborators
    WHERE project_id = _project_id
      AND user_id = _user_id
      AND status = 'accepted'
  )
$$;

-- Create a security definer function to check if user owns a project
CREATE OR REPLACE FUNCTION public.is_project_owner(_user_id uuid, _project_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.projects
    WHERE id = _project_id
      AND user_id = _user_id
  )
$$;

-- Drop the problematic policies on projects
DROP POLICY IF EXISTS "Users can view own projects or collaborator projects" ON public.projects;

-- Create a new policy using the security definer function
CREATE POLICY "Users can view own projects or collaborator projects" 
ON public.projects 
FOR SELECT 
TO authenticated
USING (
  user_id = auth.uid() 
  OR public.is_project_collaborator(auth.uid(), id)
);

-- Drop and recreate the project_collaborators policy to use the security definer function
DROP POLICY IF EXISTS "Project owners can manage collaborators" ON public.project_collaborators;

CREATE POLICY "Project owners can manage collaborators" 
ON public.project_collaborators 
FOR ALL 
TO authenticated
USING (public.is_project_owner(auth.uid(), project_id))
WITH CHECK (public.is_project_owner(auth.uid(), project_id));
-- Add currency to expenses table
ALTER TABLE public.expenses 
ADD COLUMN currency text NOT NULL DEFAULT 'BDT';

-- Add tags to expenses (array of strings)
ALTER TABLE public.expenses 
ADD COLUMN tags text[] NULL DEFAULT '{}';

-- Create custom fields table for projects
CREATE TABLE public.project_custom_fields (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  project_id uuid NOT NULL REFERENCES public.projects(id) ON DELETE CASCADE,
  field_name text NOT NULL,
  field_type text NOT NULL DEFAULT 'text', -- text, number, date, select
  options text[] NULL, -- for select type
  is_required boolean NOT NULL DEFAULT false,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Create expense custom field values
CREATE TABLE public.expense_custom_values (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  expense_id uuid NOT NULL REFERENCES public.expenses(id) ON DELETE CASCADE,
  field_id uuid NOT NULL REFERENCES public.project_custom_fields(id) ON DELETE CASCADE,
  value text NULL,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  UNIQUE(expense_id, field_id)
);

-- Create exchange rates cache table
CREATE TABLE public.exchange_rates (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  base_currency text NOT NULL,
  target_currency text NOT NULL,
  rate numeric NOT NULL,
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  UNIQUE(base_currency, target_currency)
);

-- Enable RLS
ALTER TABLE public.project_custom_fields ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.expense_custom_values ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.exchange_rates ENABLE ROW LEVEL SECURITY;

-- RLS policies for custom fields
CREATE POLICY "Users can view custom fields for their projects" 
ON public.project_custom_fields FOR SELECT 
USING (EXISTS (
  SELECT 1 FROM projects WHERE projects.id = project_custom_fields.project_id AND projects.user_id = auth.uid()
));

CREATE POLICY "Users can create custom fields for their projects" 
ON public.project_custom_fields FOR INSERT 
WITH CHECK (EXISTS (
  SELECT 1 FROM projects WHERE projects.id = project_custom_fields.project_id AND projects.user_id = auth.uid()
));

CREATE POLICY "Users can update custom fields for their projects" 
ON public.project_custom_fields FOR UPDATE 
USING (EXISTS (
  SELECT 1 FROM projects WHERE projects.id = project_custom_fields.project_id AND projects.user_id = auth.uid()
));

CREATE POLICY "Users can delete custom fields for their projects" 
ON public.project_custom_fields FOR DELETE 
USING (EXISTS (
  SELECT 1 FROM projects WHERE projects.id = project_custom_fields.project_id AND projects.user_id = auth.uid()
));

-- RLS policies for custom values
CREATE POLICY "Users can view custom values for their expenses" 
ON public.expense_custom_values FOR SELECT 
USING (EXISTS (
  SELECT 1 FROM expenses 
  JOIN projects ON projects.id = expenses.project_id 
  WHERE expenses.id = expense_custom_values.expense_id AND projects.user_id = auth.uid()
));

CREATE POLICY "Users can create custom values for their expenses" 
ON public.expense_custom_values FOR INSERT 
WITH CHECK (EXISTS (
  SELECT 1 FROM expenses 
  JOIN projects ON projects.id = expenses.project_id 
  WHERE expenses.id = expense_custom_values.expense_id AND projects.user_id = auth.uid()
));

CREATE POLICY "Users can update custom values for their expenses" 
ON public.expense_custom_values FOR UPDATE 
USING (EXISTS (
  SELECT 1 FROM expenses 
  JOIN projects ON projects.id = expenses.project_id 
  WHERE expenses.id = expense_custom_values.expense_id AND projects.user_id = auth.uid()
));

CREATE POLICY "Users can delete custom values for their expenses" 
ON public.expense_custom_values FOR DELETE 
USING (EXISTS (
  SELECT 1 FROM expenses 
  JOIN projects ON projects.id = expenses.project_id 
  WHERE expenses.id = expense_custom_values.expense_id AND projects.user_id = auth.uid()
));

-- Exchange rates are public read
CREATE POLICY "Anyone can view exchange rates" 
ON public.exchange_rates FOR SELECT 
USING (true);

-- Only system can manage exchange rates (no insert/update/delete for regular users)
-- We'll use service role in edge function to update rates
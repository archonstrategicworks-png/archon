-- Drop the overly permissive public access policy
DROP POLICY IF EXISTS "Anyone can view exchange rates" ON public.exchange_rates;

-- Create a policy that only allows authenticated users to view exchange rates
CREATE POLICY "Authenticated users can view exchange rates" 
ON public.exchange_rates 
FOR SELECT 
TO authenticated
USING (true);

-- Add deny policy for anonymous access
CREATE POLICY "Deny anonymous access to exchange_rates" 
ON public.exchange_rates 
FOR SELECT 
TO anon
USING (false);
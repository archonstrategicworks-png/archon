-- Add approval status to expenses table
ALTER TABLE public.expenses 
ADD COLUMN approval_status text NOT NULL DEFAULT 'pending',
ADD COLUMN approved_by uuid NULL,
ADD COLUMN approved_at timestamp with time zone NULL,
ADD COLUMN rejection_reason text NULL;

-- Create recurring expenses table
CREATE TABLE public.recurring_expenses (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  project_id uuid NOT NULL REFERENCES public.projects(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  category text NOT NULL,
  vendor text NULL,
  amount numeric NOT NULL,
  payment_method text NOT NULL,
  notes text NULL,
  frequency text NOT NULL DEFAULT 'monthly', -- daily, weekly, monthly, yearly
  start_date date NOT NULL DEFAULT CURRENT_DATE,
  end_date date NULL,
  next_run_date date NOT NULL DEFAULT CURRENT_DATE,
  is_active boolean NOT NULL DEFAULT true,
  last_generated_at timestamp with time zone NULL,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS on recurring_expenses
ALTER TABLE public.recurring_expenses ENABLE ROW LEVEL SECURITY;

-- RLS policies for recurring_expenses
CREATE POLICY "Users can view recurring expenses for their projects" 
ON public.recurring_expenses 
FOR SELECT 
USING (EXISTS (
  SELECT 1 FROM projects 
  WHERE projects.id = recurring_expenses.project_id 
  AND projects.user_id = auth.uid()
));

CREATE POLICY "Users can create recurring expenses for their projects" 
ON public.recurring_expenses 
FOR INSERT 
WITH CHECK (EXISTS (
  SELECT 1 FROM projects 
  WHERE projects.id = recurring_expenses.project_id 
  AND projects.user_id = auth.uid()
) AND user_id = auth.uid());

CREATE POLICY "Users can update recurring expenses for their projects" 
ON public.recurring_expenses 
FOR UPDATE 
USING (EXISTS (
  SELECT 1 FROM projects 
  WHERE projects.id = recurring_expenses.project_id 
  AND projects.user_id = auth.uid()
));

CREATE POLICY "Users can delete recurring expenses for their projects" 
ON public.recurring_expenses 
FOR DELETE 
USING (EXISTS (
  SELECT 1 FROM projects 
  WHERE projects.id = recurring_expenses.project_id 
  AND projects.user_id = auth.uid()
));

-- Create trigger for updated_at
CREATE TRIGGER update_recurring_expenses_updated_at
BEFORE UPDATE ON public.recurring_expenses
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();
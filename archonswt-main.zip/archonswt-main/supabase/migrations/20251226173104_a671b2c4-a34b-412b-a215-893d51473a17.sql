-- Secure the receipts storage bucket
-- Make the bucket private (not publicly accessible)
UPDATE storage.buckets 
SET public = false 
WHERE id = 'receipts';

-- Drop existing public policies if they exist
DROP POLICY IF EXISTS "Allow public read access on receipts" ON storage.objects;
DROP POLICY IF EXISTS "Allow public upload to receipts" ON storage.objects;
DROP POLICY IF EXISTS "Allow public delete from receipts" ON storage.objects;
DROP POLICY IF EXISTS "Users can view own receipts" ON storage.objects;
DROP POLICY IF EXISTS "Users can upload own receipts" ON storage.objects;
DROP POLICY IF EXISTS "Users can delete own receipts" ON storage.objects;
DROP POLICY IF EXISTS "Users can update own receipts" ON storage.objects;

-- Create user-scoped RLS policies for receipts bucket
-- Users can only view their own receipts (files in their user_id folder)
CREATE POLICY "Users can view own receipts"
ON storage.objects FOR SELECT
USING (
  bucket_id = 'receipts' 
  AND auth.uid()::text = (storage.foldername(name))[1]
);

-- Users can only upload to their own folder
CREATE POLICY "Users can upload own receipts"
ON storage.objects FOR INSERT
WITH CHECK (
  bucket_id = 'receipts' 
  AND auth.uid()::text = (storage.foldername(name))[1]
);

-- Users can only update their own receipts
CREATE POLICY "Users can update own receipts"
ON storage.objects FOR UPDATE
USING (
  bucket_id = 'receipts' 
  AND auth.uid()::text = (storage.foldername(name))[1]
);

-- Users can only delete their own receipts
CREATE POLICY "Users can delete own receipts"
ON storage.objects FOR DELETE
USING (
  bucket_id = 'receipts' 
  AND auth.uid()::text = (storage.foldername(name))[1]
);
-- Create projects table
CREATE TABLE public.projects (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  project_name TEXT NOT NULL,
  client TEXT,
  start_date DATE,
  status TEXT NOT NULL DEFAULT 'Active' CHECK (status IN ('Active', 'Completed', 'On Hold')),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create uploads table for file storage references
CREATE TABLE public.uploads (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  file_type TEXT NOT NULL CHECK (file_type IN ('Receipt', 'Bank Statement', 'Other')),
  file_url TEXT NOT NULL,
  file_name TEXT,
  uploaded_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create expenses table
CREATE TABLE public.expenses (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  project_id UUID NOT NULL REFERENCES public.projects(id) ON DELETE CASCADE,
  date DATE NOT NULL,
  amount DECIMAL(12, 2) NOT NULL,
  payment_method TEXT NOT NULL CHECK (payment_method IN ('Cash', 'Bank', 'Mobile', 'Cheque')),
  category TEXT NOT NULL CHECK (category IN ('Materials', 'Labor', 'Transport', 'Fuel', 'Misc')),
  vendor TEXT,
  notes TEXT,
  source TEXT NOT NULL DEFAULT 'Manual' CHECK (source IN ('Manual', 'Receipt OCR', 'Bank OCR')),
  file_id UUID REFERENCES public.uploads(id) ON DELETE SET NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create bank_transactions table
CREATE TABLE public.bank_transactions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  date DATE NOT NULL,
  description TEXT,
  amount DECIMAL(12, 2) NOT NULL,
  matched_expense_id UUID REFERENCES public.expenses(id) ON DELETE SET NULL,
  confidence_score DECIMAL(3, 2),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security (making tables public for this demo app)
ALTER TABLE public.projects ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.expenses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.uploads ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.bank_transactions ENABLE ROW LEVEL SECURITY;

-- Create public read/write policies (for demo - no auth required)
CREATE POLICY "Allow public read access on projects" ON public.projects FOR SELECT USING (true);
CREATE POLICY "Allow public insert access on projects" ON public.projects FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public update access on projects" ON public.projects FOR UPDATE USING (true);
CREATE POLICY "Allow public delete access on projects" ON public.projects FOR DELETE USING (true);

CREATE POLICY "Allow public read access on expenses" ON public.expenses FOR SELECT USING (true);
CREATE POLICY "Allow public insert access on expenses" ON public.expenses FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public update access on expenses" ON public.expenses FOR UPDATE USING (true);
CREATE POLICY "Allow public delete access on expenses" ON public.expenses FOR DELETE USING (true);

CREATE POLICY "Allow public read access on uploads" ON public.uploads FOR SELECT USING (true);
CREATE POLICY "Allow public insert access on uploads" ON public.uploads FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public update access on uploads" ON public.uploads FOR DELETE USING (true);

CREATE POLICY "Allow public read access on bank_transactions" ON public.bank_transactions FOR SELECT USING (true);
CREATE POLICY "Allow public insert access on bank_transactions" ON public.bank_transactions FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public update access on bank_transactions" ON public.bank_transactions FOR UPDATE USING (true);
CREATE POLICY "Allow public delete access on bank_transactions" ON public.bank_transactions FOR DELETE USING (true);

-- Create updated_at trigger function
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

-- Create trigger for projects
CREATE TRIGGER update_projects_updated_at
  BEFORE UPDATE ON public.projects
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Create storage bucket for receipts
INSERT INTO storage.buckets (id, name, public) VALUES ('receipts', 'receipts', true);

-- Create storage policies
CREATE POLICY "Allow public read access on receipts" ON storage.objects FOR SELECT USING (bucket_id = 'receipts');
CREATE POLICY "Allow public upload to receipts" ON storage.objects FOR INSERT WITH CHECK (bucket_id = 'receipts');
CREATE POLICY "Allow public delete from receipts" ON storage.objects FOR DELETE USING (bucket_id = 'receipts');
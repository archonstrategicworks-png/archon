-- Add currency preference to profiles
ALTER TABLE public.profiles 
ADD COLUMN preferred_currency text NOT NULL DEFAULT 'BDT';

-- Create expense categories table for user customization
CREATE TABLE public.expense_categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  name text NOT NULL,
  icon text,
  color text,
  is_default boolean NOT NULL DEFAULT false,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  UNIQUE(user_id, name)
);

-- Enable RLS
ALTER TABLE public.expense_categories ENABLE ROW LEVEL SECURITY;

-- RLS policies for expense_categories
CREATE POLICY "Users can view their own categories"
ON public.expense_categories FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own categories"
ON public.expense_categories FOR INSERT
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own categories"
ON public.expense_categories FOR UPDATE
USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own categories"
ON public.expense_categories FOR DELETE
USING (auth.uid() = user_id);

-- Function to create default categories for new users
CREATE OR REPLACE FUNCTION public.create_default_categories()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  INSERT INTO public.expense_categories (user_id, name, icon, color, is_default) VALUES
    (new.id, 'Materials', 'Package', '#3B82F6', true),
    (new.id, 'Labor', 'Users', '#10B981', true),
    (new.id, 'Equipment', 'Wrench', '#F59E0B', true),
    (new.id, 'Travel', 'Car', '#8B5CF6', true),
    (new.id, 'Office', 'Building', '#EC4899', true),
    (new.id, 'Utilities', 'Zap', '#06B6D4', true),
    (new.id, 'Marketing', 'Megaphone', '#F97316', true),
    (new.id, 'Other', 'MoreHorizontal', '#6B7280', true);
  RETURN new;
END;
$$;

-- Trigger to create default categories on user signup
CREATE TRIGGER on_auth_user_created_categories
AFTER INSERT ON auth.users
FOR EACH ROW EXECUTE FUNCTION public.create_default_categories();
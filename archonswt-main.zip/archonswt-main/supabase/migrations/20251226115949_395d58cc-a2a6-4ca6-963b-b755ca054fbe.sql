-- Add budget column to projects
ALTER TABLE public.projects 
ADD COLUMN budget numeric DEFAULT NULL,
ADD COLUMN budget_alert_threshold numeric DEFAULT 80;

-- Create project collaborators table
CREATE TABLE public.project_collaborators (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid NOT NULL REFERENCES public.projects(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  invited_by uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role text NOT NULL DEFAULT 'viewer',
  status text NOT NULL DEFAULT 'pending',
  invited_email text NOT NULL,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  UNIQUE(project_id, invited_email)
);

-- Enable RLS
ALTER TABLE public.project_collaborators ENABLE ROW LEVEL SECURITY;

-- RLS policies for project_collaborators
CREATE POLICY "Project owners can manage collaborators"
ON public.project_collaborators FOR ALL
USING (
  EXISTS (
    SELECT 1 FROM projects 
    WHERE projects.id = project_collaborators.project_id 
    AND projects.user_id = auth.uid()
  )
);

CREATE POLICY "Collaborators can view their own invitations"
ON public.project_collaborators FOR SELECT
USING (user_id = auth.uid() OR invited_email IN (
  SELECT email FROM auth.users WHERE id = auth.uid()
));

-- Update projects RLS to allow collaborators to view projects
DROP POLICY IF EXISTS "Users can view their own projects" ON public.projects;
CREATE POLICY "Users can view own projects or collaborator projects"
ON public.projects FOR SELECT
USING (
  user_id = auth.uid() OR
  EXISTS (
    SELECT 1 FROM project_collaborators 
    WHERE project_collaborators.project_id = projects.id 
    AND project_collaborators.user_id = auth.uid()
    AND project_collaborators.status = 'accepted'
  )
);

-- Add language preference to profiles
ALTER TABLE public.profiles 
ADD COLUMN language text NOT NULL DEFAULT 'en';
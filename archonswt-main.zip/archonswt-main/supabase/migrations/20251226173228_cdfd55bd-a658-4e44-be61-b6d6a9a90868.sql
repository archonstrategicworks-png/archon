-- Fix the push_notifications table RLS policy
-- Currently allows any authenticated user to see all notifications
-- Should restrict to notifications sent by the user or intended for them

-- Drop the overly permissive policy
DROP POLICY IF EXISTS "Users can view all notifications" ON public.push_notifications;

-- Create a more restrictive policy
-- Users can only view notifications they sent
CREATE POLICY "Users can view notifications they sent"
ON public.push_notifications FOR SELECT
USING (auth.uid() = sender_id);
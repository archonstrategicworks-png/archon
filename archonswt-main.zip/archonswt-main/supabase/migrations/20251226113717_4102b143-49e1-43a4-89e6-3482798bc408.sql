-- Add user_id column to projects table
ALTER TABLE public.projects 
ADD COLUMN user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE;

-- Add user_id column to uploads table
ALTER TABLE public.uploads 
ADD COLUMN user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE;

-- Drop existing overly permissive policies on projects
DROP POLICY IF EXISTS "Allow public read access on projects" ON public.projects;
DROP POLICY IF EXISTS "Allow public insert access on projects" ON public.projects;
DROP POLICY IF EXISTS "Allow public update access on projects" ON public.projects;
DROP POLICY IF EXISTS "Allow public delete access on projects" ON public.projects;

-- Create user-based RLS policies for projects
CREATE POLICY "Users can view their own projects" 
ON public.projects FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own projects" 
ON public.projects FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own projects" 
ON public.projects FOR UPDATE 
USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own projects" 
ON public.projects FOR DELETE 
USING (auth.uid() = user_id);

-- Drop existing overly permissive policies on expenses
DROP POLICY IF EXISTS "Allow public read access on expenses" ON public.expenses;
DROP POLICY IF EXISTS "Allow public insert access on expenses" ON public.expenses;
DROP POLICY IF EXISTS "Allow public update access on expenses" ON public.expenses;
DROP POLICY IF EXISTS "Allow public delete access on expenses" ON public.expenses;

-- Create user-based RLS policies for expenses (through project ownership)
CREATE POLICY "Users can view expenses for their projects" 
ON public.expenses FOR SELECT 
USING (
  EXISTS (
    SELECT 1 FROM public.projects 
    WHERE projects.id = expenses.project_id 
    AND projects.user_id = auth.uid()
  )
);

CREATE POLICY "Users can create expenses for their projects" 
ON public.expenses FOR INSERT 
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.projects 
    WHERE projects.id = project_id 
    AND projects.user_id = auth.uid()
  )
);

CREATE POLICY "Users can update expenses for their projects" 
ON public.expenses FOR UPDATE 
USING (
  EXISTS (
    SELECT 1 FROM public.projects 
    WHERE projects.id = expenses.project_id 
    AND projects.user_id = auth.uid()
  )
);

CREATE POLICY "Users can delete expenses for their projects" 
ON public.expenses FOR DELETE 
USING (
  EXISTS (
    SELECT 1 FROM public.projects 
    WHERE projects.id = expenses.project_id 
    AND projects.user_id = auth.uid()
  )
);

-- Drop existing overly permissive policies on uploads
DROP POLICY IF EXISTS "Allow public read access on uploads" ON public.uploads;
DROP POLICY IF EXISTS "Allow public insert access on uploads" ON public.uploads;
DROP POLICY IF EXISTS "Allow public update access on uploads" ON public.uploads;

-- Create user-based RLS policies for uploads
CREATE POLICY "Users can view their own uploads" 
ON public.uploads FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own uploads" 
ON public.uploads FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own uploads" 
ON public.uploads FOR DELETE 
USING (auth.uid() = user_id);

-- Drop existing overly permissive policies on bank_transactions
DROP POLICY IF EXISTS "Allow public read access on bank_transactions" ON public.bank_transactions;
DROP POLICY IF EXISTS "Allow public insert access on bank_transactions" ON public.bank_transactions;
DROP POLICY IF EXISTS "Allow public update access on bank_transactions" ON public.bank_transactions;
DROP POLICY IF EXISTS "Allow public delete access on bank_transactions" ON public.bank_transactions;

-- Add user_id to bank_transactions
ALTER TABLE public.bank_transactions 
ADD COLUMN user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE;

-- Create user-based RLS policies for bank_transactions
CREATE POLICY "Users can view their own bank_transactions" 
ON public.bank_transactions FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own bank_transactions" 
ON public.bank_transactions FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own bank_transactions" 
ON public.bank_transactions FOR UPDATE 
USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own bank_transactions" 
ON public.bank_transactions FOR DELETE 
USING (auth.uid() = user_id);
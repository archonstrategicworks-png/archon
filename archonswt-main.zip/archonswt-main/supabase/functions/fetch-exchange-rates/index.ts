import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// Free exchange rate API (no key required)
const EXCHANGE_API_URL = "https://api.exchangerate-api.com/v4/latest";

const SUPPORTED_CURRENCIES = ["BDT", "USD", "EUR", "GBP", "INR", "AED", "SAR", "MYR", "SGD", "CAD", "AUD", "JPY", "CNY"];

serve(async (req) => {
  // Handle CORS preflight
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log("Fetching exchange rates...");

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );

    // Fetch rates from external API using BDT as base
    const response = await fetch(`${EXCHANGE_API_URL}/BDT`);
    
    if (!response.ok) {
      throw new Error(`Failed to fetch exchange rates: ${response.status}`);
    }

    const data = await response.json();
    console.log("Exchange rates fetched successfully");

    const rates = data.rates;
    const updates: { base_currency: string; target_currency: string; rate: number }[] = [];

    // Create rate pairs for all supported currencies
    for (const baseCurrency of SUPPORTED_CURRENCIES) {
      for (const targetCurrency of SUPPORTED_CURRENCIES) {
        if (baseCurrency === targetCurrency) continue;

        // Calculate cross rate through BDT
        const baseToUSD = rates[baseCurrency] || 1;
        const targetToUSD = rates[targetCurrency] || 1;
        const rate = targetToUSD / baseToUSD;

        updates.push({
          base_currency: baseCurrency,
          target_currency: targetCurrency,
          rate: rate,
        });
      }
    }

    // Upsert all rates
    const { error } = await supabase
      .from("exchange_rates")
      .upsert(
        updates.map((u) => ({
          ...u,
          updated_at: new Date().toISOString(),
        })),
        { onConflict: "base_currency,target_currency" }
      );

    if (error) {
      console.error("Error upserting rates:", error);
      throw error;
    }

    console.log(`Updated ${updates.length} exchange rate pairs`);

    return new Response(
      JSON.stringify({
        success: true,
        updated: updates.length,
        timestamp: new Date().toISOString(),
      }),
      {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    console.error("Error in fetch-exchange-rates:", errorMessage);
    return new Response(
      JSON.stringify({ error: errorMessage }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});

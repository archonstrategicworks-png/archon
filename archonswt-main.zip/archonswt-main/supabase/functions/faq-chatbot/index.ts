import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.3";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// Structured logging helper
const log = {
  info: (message: string, data?: Record<string, unknown>) => {
    console.log(JSON.stringify({ level: "INFO", fn: "faq-chatbot", message, ...data, timestamp: new Date().toISOString() }));
  },
  warn: (message: string, data?: Record<string, unknown>) => {
    console.warn(JSON.stringify({ level: "WARN", fn: "faq-chatbot", message, ...data, timestamp: new Date().toISOString() }));
  },
  error: (message: string, error?: unknown, data?: Record<string, unknown>) => {
    const errorInfo = error instanceof Error 
      ? { errorMessage: error.message, errorStack: error.stack?.substring(0, 500) }
      : { errorMessage: String(error) };
    console.error(JSON.stringify({ level: "ERROR", fn: "faq-chatbot", message, ...errorInfo, ...data, timestamp: new Date().toISOString() }));
  },
};

const systemPrompt = `You are a helpful AI assistant for an Expense Tracker application. You help users understand how to use the app and answer their questions.

## About the Application
This is a comprehensive expense tracking and project management application with the following features:

### Core Features:
1. **Projects**: Create and manage multiple projects with budgets, clients, and status tracking
2. **Expenses**: Track expenses with categories, vendors, amounts, and payment methods
3. **Receipt Scanning**: Upload receipt photos and AI automatically extracts vendor, amount, and category
4. **Bank Statements**: Upload and process bank statements to match transactions
5. **Multi-Currency**: Support for multiple currencies with real-time exchange rates
6. **Analytics**: View spending trends, category breakdowns, and budget forecasts

### How to Use:
- **Create a Project**: Go to Projects page, click "Create Project", fill in name, budget, and client
- **Add Expenses**: Select a project, then add expenses manually or scan receipts
- **Upload Receipts**: Use the camera or upload button to scan receipts with AI
- **View Analytics**: Go to Analytics page to see spending trends and insights
- **Export Data**: Download expenses as Excel spreadsheets
- **Generate Invoices**: Create professional invoices from expense data

### FAQ:
Q: How do I create a new project?
A: Navigate to Projects, click "Create Project" and fill in the details.

Q: How does receipt scanning work?
A: Upload a photo of your receipt, and AI extracts vendor, amount, and date automatically.

Q: Can I track expenses in different currencies?
A: Yes! The app supports multiple currencies with real-time exchange rates.

Q: How do I export my expenses?
A: Use the "Export Excel" button on any project or dashboard page.

Q: What payment methods are supported?
A: Cash, Card, UPI, Bank Transfer, and Check.

IMPORTANT INSTRUCTIONS:
- Answer questions in the SAME LANGUAGE the user asks in (Bangla বাংলা or English)
- If the user writes in Bangla, respond entirely in Bangla
- If the user writes in English, respond entirely in English
- Be concise but helpful
- If you don't know something specific about the app, say so politely
- Always be friendly and professional`;

serve(async (req) => {
  const requestId = crypto.randomUUID().substring(0, 8);
  const startTime = Date.now();
  
  log.info("Request received", { requestId, method: req.method });

  if (req.method === "OPTIONS") {
    log.info("CORS preflight handled", { requestId });
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Extract and validate user from JWT
    const authHeader = req.headers.get("Authorization");
    log.info("Auth header check", { requestId, hasAuthHeader: !!authHeader });
    
    if (!authHeader) {
      log.warn("Missing authorization header", { requestId });
      return new Response(
        JSON.stringify({ error: "Authentication required" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    log.info("Creating Supabase client for user validation", { requestId });
    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } }
    );

    const { data: { user }, error: authError } = await supabaseClient.auth.getUser();
    
    if (authError || !user) {
      log.error("Authentication failed", authError, { requestId, hasUser: !!user });
      return new Response(
        JSON.stringify({ error: "Invalid or expired token" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    log.info("User authenticated", { requestId, userId: user.id });

    const { message, conversationHistory = [] } = await req.json();
    log.info("Request payload parsed", { requestId, messageLength: message?.length || 0, historyLength: conversationHistory?.length || 0 });

    if (!message) {
      log.warn("No message provided", { requestId });
      return new Response(
        JSON.stringify({ error: "No message provided" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Validate message length
    if (message.length > 2000) {
      log.warn("Message too long", { requestId, messageLength: message.length });
      return new Response(
        JSON.stringify({ error: "Message too long. Maximum 2000 characters." }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Limit conversation history size
    if (conversationHistory.length > 20) {
      log.warn("Conversation history too long", { requestId, historyLength: conversationHistory.length });
      return new Response(
        JSON.stringify({ error: "Conversation history too long" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Sanitize conversation history - prevent system prompt injection
    const sanitizedHistory = conversationHistory
      .filter((msg: any) => msg.role !== 'system')
      .slice(-10)
      .map((msg: any) => ({
        role: msg.role === 'user' || msg.role === 'assistant' ? msg.role : 'user',
        content: String(msg.content || '').substring(0, 2000)
      }));

    log.info("Conversation history sanitized", { requestId, sanitizedLength: sanitizedHistory.length });

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) {
      log.error("LOVABLE_API_KEY not configured", null, { requestId });
      return new Response(
        JSON.stringify({ error: "AI service not configured" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const messages = [
      { role: "system", content: systemPrompt },
      ...sanitizedHistory,
      { role: "user", content: message }
    ];

    log.info("Calling AI API", { requestId, totalMessages: messages.length });
    const aiStartTime = Date.now();

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages,
      }),
    });

    const aiDuration = Date.now() - aiStartTime;
    log.info("AI API response received", { requestId, status: response.status, aiDuration });

    if (!response.ok) {
      const errorText = await response.text();
      log.error("AI Gateway error", null, { requestId, status: response.status, errorText: errorText.substring(0, 500) });
      
      if (response.status === 429) {
        return new Response(
          JSON.stringify({ error: "Rate limit exceeded. Please try again later." }),
          { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      if (response.status === 402) {
        return new Response(
          JSON.stringify({ error: "AI usage credits exhausted." }),
          { status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      
      throw new Error(`AI Gateway error: ${response.status}`);
    }

    const data = await response.json();
    const reply = data.choices?.[0]?.message?.content || "Sorry, I couldn't process your request.";

    const duration = Date.now() - startTime;
    log.info("Request complete", { requestId, duration, replyLength: reply.length });

    return new Response(
      JSON.stringify({ reply }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error: unknown) {
    const duration = Date.now() - startTime;
    log.error("Unhandled exception", error, { requestId, duration });
    
    const errorMessage = error instanceof Error ? error.message : "Failed to process message";
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});

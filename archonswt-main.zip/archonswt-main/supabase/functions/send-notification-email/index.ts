import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { Resend } from "https://esm.sh/resend@2.0.0";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.3";

const resend = new Resend(Deno.env.get("RESEND_API_KEY"));
const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const supabaseAnonKey = Deno.env.get("SUPABASE_ANON_KEY")!;

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// Structured logging helper
const log = {
  info: (message: string, data?: Record<string, unknown>) => {
    console.log(JSON.stringify({ level: "INFO", fn: "send-notification-email", message, ...data, timestamp: new Date().toISOString() }));
  },
  warn: (message: string, data?: Record<string, unknown>) => {
    console.warn(JSON.stringify({ level: "WARN", fn: "send-notification-email", message, ...data, timestamp: new Date().toISOString() }));
  },
  error: (message: string, error?: unknown, data?: Record<string, unknown>) => {
    const errorInfo = error instanceof Error 
      ? { errorMessage: error.message, errorStack: error.stack?.substring(0, 500) }
      : { errorMessage: String(error) };
    console.error(JSON.stringify({ level: "ERROR", fn: "send-notification-email", message, ...errorInfo, ...data, timestamp: new Date().toISOString() }));
  },
};

interface NotificationRequest {
  title: string;
  body: string;
  targetUserId?: string;
}

// Sanitize error messages to prevent information leakage
const sanitizeError = (error: unknown): string => {
  if (error instanceof Error) {
    const msg = error.message.toLowerCase();
    if (msg.includes('rate limit') || msg.includes('429')) {
      return 'Email rate limit exceeded. Please try again later.';
    }
    if (msg.includes('invalid') && msg.includes('email')) {
      return 'Invalid email address found.';
    }
    if (msg.includes('api') || msg.includes('key') || msg.includes('resend')) {
      return 'Email service temporarily unavailable. Please try again.';
    }
    if (msg.includes('profile') || msg.includes('user')) {
      return 'Failed to retrieve user information.';
    }
  }
  return 'Failed to send notification emails. Please try again.';
};

const handler = async (req: Request): Promise<Response> => {
  const requestId = crypto.randomUUID().substring(0, 8);
  const startTime = Date.now();
  
  log.info("Request received", { requestId, method: req.method });

  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    log.info("CORS preflight handled", { requestId });
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Extract and validate user from JWT
    const authHeader = req.headers.get("Authorization");
    log.info("Auth header check", { requestId, hasAuthHeader: !!authHeader, authHeaderPrefix: authHeader?.substring(0, 20) });
    
    if (!authHeader) {
      log.warn("Missing authorization header", { requestId });
      return new Response(
        JSON.stringify({ error: "Authorization header required" }),
        { status: 401, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    log.info("Creating Supabase client for user validation", { requestId });
    const userClient = createClient(supabaseUrl, supabaseAnonKey, {
      global: { headers: { Authorization: authHeader } },
    });

    const { data: { user }, error: authError } = await userClient.auth.getUser();
    
    if (authError || !user) {
      log.error("Authentication failed", authError, { requestId, hasUser: !!user });
      return new Response(
        JSON.stringify({ error: "Invalid or expired token" }),
        { status: 401, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    log.info("User authenticated", { requestId, userId: user.id, email: user.email });

    // Check if the user is an admin
    log.info("Checking admin role", { requestId, userId: user.id });
    const { data: adminRole, error: roleError } = await userClient
      .from("user_roles")
      .select("role")
      .eq("user_id", user.id)
      .eq("role", "admin")
      .maybeSingle();

    if (roleError) {
      log.error("Role check query failed", roleError, { requestId, userId: user.id });
    }

    if (!adminRole) {
      log.warn("Admin access denied", { requestId, userId: user.id });
      return new Response(
        JSON.stringify({ error: "Admin access required to send notifications" }),
        { status: 403, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    log.info("Admin role verified", { requestId, userId: user.id, role: adminRole.role });

    const { title, body, targetUserId }: NotificationRequest = await req.json();
    log.info("Request payload parsed", { requestId, title, bodyLength: body?.length, targetUserId: targetUserId || "all" });

    if (!title || !body) {
      log.warn("Missing required fields", { requestId, hasTitle: !!title, hasBody: !!body });
      return new Response(
        JSON.stringify({ error: "Title and body are required" }),
        { status: 400, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    // Create Supabase client with service role to bypass RLS
    log.info("Creating service role client", { requestId });
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Query profiles to get users with email notifications enabled
    log.info("Fetching eligible profiles", { requestId });
    let query = supabase
      .from("profiles")
      .select("user_id, display_name, notification_email, email_notifications_enabled")
      .eq("email_notifications_enabled", true);

    if (targetUserId) {
      query = query.eq("user_id", targetUserId);
    }

    const { data: profiles, error: profilesError } = await query;

    if (profilesError) {
      log.error("Profile fetch failed", profilesError, { requestId });
      throw new Error("Failed to fetch user profiles");
    }

    log.info("Profiles fetched", { requestId, count: profiles?.length || 0 });

    if (!profiles || profiles.length === 0) {
      log.info("No eligible recipients", { requestId });
      return new Response(
        JSON.stringify({ success: true, sent: 0, message: "No users with email notifications enabled" }),
        { status: 200, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    // Get user emails from auth.users table
    log.info("Fetching auth user emails", { requestId });
    const userIds = profiles.map((p) => p.user_id);
    const { data: authUsers, error: authUsersError } = await supabase.auth.admin.listUsers();

    if (authUsersError) {
      log.error("Auth users fetch failed", authUsersError, { requestId });
      throw new Error("Failed to fetch user emails");
    }

    log.info("Auth users fetched", { requestId, count: authUsers.users.length });

    // Map user IDs to emails
    const userEmailMap = new Map<string, string>();
    authUsers.users.forEach((u) => {
      if (userIds.includes(u.id) && u.email) {
        userEmailMap.set(u.id, u.email);
      }
    });

    // Prepare email recipients
    const emailRecipients: { email: string; name: string }[] = [];
    profiles.forEach((profile) => {
      const email = profile.notification_email || userEmailMap.get(profile.user_id);
      if (email) {
        emailRecipients.push({
          email,
          name: profile.display_name || "User",
        });
      }
    });

    log.info("Recipients prepared", { requestId, recipientCount: emailRecipients.length });

    if (emailRecipients.length === 0) {
      log.info("No valid email addresses", { requestId });
      return new Response(
        JSON.stringify({ success: true, sent: 0, message: "No valid email addresses" }),
        { status: 200, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    // Send emails in batches
    const batchSize = 50;
    let totalSent = 0;
    let totalFailed = 0;

    log.info("Starting email batch send", { requestId, totalRecipients: emailRecipients.length, batchSize });

    for (let i = 0; i < emailRecipients.length; i += batchSize) {
      const batch = emailRecipients.slice(i, i + batchSize);
      const batchNum = Math.floor(i / batchSize) + 1;
      
      log.info("Processing batch", { requestId, batchNum, batchSize: batch.length });
      
      const emailPromises = batch.map(async (recipient) => {
        try {
          const result = await resend.emails.send({
            from: "Archon Strategic Works <onboarding@resend.dev>",
            to: [recipient.email],
            subject: title,
            html: `
              <!DOCTYPE html>
              <html>
              <head>
                <meta charset="utf-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>${title}</title>
              </head>
              <body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
                <div style="background: linear-gradient(135deg, #1e3a5f 0%, #0f1c2e 100%); padding: 30px; border-radius: 10px 10px 0 0;">
                  <h1 style="color: #d4af37; margin: 0; font-size: 24px;">Archon Strategic Works</h1>
                </div>
                <div style="background: #ffffff; padding: 30px; border: 1px solid #e0e0e0; border-top: none; border-radius: 0 0 10px 10px;">
                  <h2 style="color: #1e3a5f; margin-top: 0;">${title}</h2>
                  <p style="color: #555; font-size: 16px;">${body}</p>
                  <hr style="border: none; border-top: 1px solid #eee; margin: 30px 0;">
                  <p style="color: #888; font-size: 12px;">
                    You received this email because you have email notifications enabled in your account settings.
                    <br>To unsubscribe, update your notification preferences in the Settings page.
                  </p>
                </div>
              </body>
              </html>
            `,
          });

          if (result.error) {
            log.error("Resend API error for recipient", result.error, { requestId, recipientName: recipient.name });
            return false;
          }

          return true;
        } catch (err) {
          log.error("Email send exception", err, { requestId, recipientName: recipient.name });
          return false;
        }
      });

      const results = await Promise.all(emailPromises);
      const batchSent = results.filter(Boolean).length;
      const batchFailed = results.length - batchSent;
      
      totalSent += batchSent;
      totalFailed += batchFailed;
      
      log.info("Batch complete", { requestId, batchNum, sent: batchSent, failed: batchFailed });
    }

    const duration = Date.now() - startTime;
    log.info("Request complete", { requestId, totalSent, totalFailed, duration, totalRecipients: emailRecipients.length });

    return new Response(
      JSON.stringify({
        success: true,
        sent: totalSent,
        failures: totalFailed,
        totalRecipients: emailRecipients.length,
      }),
      {
        status: 200,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  } catch (error: unknown) {
    const duration = Date.now() - startTime;
    log.error("Unhandled exception", error, { requestId, duration });
    
    return new Response(
      JSON.stringify({ error: sanitizeError(error) }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
};

serve(handler);

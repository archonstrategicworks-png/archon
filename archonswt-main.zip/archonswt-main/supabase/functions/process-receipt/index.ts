import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.3";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// Structured logging helper
const log = {
  info: (message: string, data?: Record<string, unknown>) => {
    console.log(JSON.stringify({ level: "INFO", fn: "process-receipt", message, ...data, timestamp: new Date().toISOString() }));
  },
  warn: (message: string, data?: Record<string, unknown>) => {
    console.warn(JSON.stringify({ level: "WARN", fn: "process-receipt", message, ...data, timestamp: new Date().toISOString() }));
  },
  error: (message: string, error?: unknown, data?: Record<string, unknown>) => {
    const errorInfo = error instanceof Error 
      ? { errorMessage: error.message, errorStack: error.stack?.substring(0, 500) }
      : { errorMessage: String(error) };
    console.error(JSON.stringify({ level: "ERROR", fn: "process-receipt", message, ...errorInfo, ...data, timestamp: new Date().toISOString() }));
  },
};

// Input validation constants
const MAX_IMAGE_SIZE = 10 * 1024 * 1024; // 10MB in base64 characters
const BASE64_REGEX = /^[A-Za-z0-9+/]+=*$/;

// Sanitize error messages to prevent information leakage
const sanitizeError = (error: unknown): string => {
  if (error instanceof Error) {
    const msg = error.message.toLowerCase();
    if (msg.includes('rate limit') || msg.includes('429')) {
      return 'Request limit exceeded. Please try again later.';
    }
    if (msg.includes('gateway') || msg.includes('ai')) {
      return 'AI service temporarily unavailable. Please try again.';
    }
    if (msg.includes('timeout')) {
      return 'Request timed out. Please try again.';
    }
  }
  return 'Failed to process receipt. Please try again.';
};

// Validate base64 image data
const validateImageData = (image: string): { valid: boolean; error?: string; status?: number } => {
  if (!image) {
    return { valid: false, error: "No image provided", status: 400 };
  }
  
  if (image.length > MAX_IMAGE_SIZE) {
    return { valid: false, error: "Image too large. Maximum size is 10MB.", status: 413 };
  }
  
  // Remove data URL prefix if present for validation
  const base64Data = image.replace(/^data:image\/\w+;base64,/, '');
  
  if (!BASE64_REGEX.test(base64Data)) {
    return { valid: false, error: "Invalid image format. Please provide a valid base64 encoded image.", status: 400 };
  }
  
  return { valid: true };
};

serve(async (req) => {
  const requestId = crypto.randomUUID().substring(0, 8);
  const startTime = Date.now();
  
  log.info("Request received", { requestId, method: req.method });

  if (req.method === "OPTIONS") {
    log.info("CORS preflight handled", { requestId });
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Extract and validate user from JWT
    const authHeader = req.headers.get("Authorization");
    log.info("Auth header check", { requestId, hasAuthHeader: !!authHeader });
    
    if (!authHeader) {
      log.warn("Missing authorization header", { requestId });
      return new Response(
        JSON.stringify({ error: "Authorization header required" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    log.info("Creating Supabase client for user validation", { requestId });
    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } }
    );

    const { data: { user }, error: authError } = await supabaseClient.auth.getUser();
    
    if (authError || !user) {
      log.error("Authentication failed", authError, { requestId, hasUser: !!user });
      return new Response(
        JSON.stringify({ error: "Invalid or expired token" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    log.info("User authenticated", { requestId, userId: user.id });

    const { image } = await req.json();
    log.info("Request payload parsed", { requestId, imageLength: image?.length || 0 });

    // Validate image input
    const validation = validateImageData(image);
    if (!validation.valid) {
      log.warn("Image validation failed", { requestId, error: validation.error });
      return new Response(
        JSON.stringify({ error: validation.error }),
        { status: validation.status, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) {
      log.error("LOVABLE_API_KEY not configured", null, { requestId });
      return new Response(
        JSON.stringify({ error: "AI service not configured" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    log.info("Calling AI Vision API", { requestId });
    const aiStartTime = Date.now();

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          {
            role: "system",
            content: `You are an OCR assistant that extracts expense information from receipt images. 
Extract the following fields:
- date: The transaction date in YYYY-MM-DD format
- amount: The total amount as a number (no currency symbols)
- vendor: The store/vendor name
- category: Suggest a category from: Food, Transport, Office, Entertainment, Utilities, Marketing, Equipment, Travel, Other

Respond ONLY with valid JSON in this exact format:
{"date": "YYYY-MM-DD", "amount": "123.45", "vendor": "Store Name", "category": "Food"}

If you cannot extract a field, use reasonable defaults:
- date: use today's date
- amount: "0"
- vendor: "Unknown Vendor"
- category: "Other"`
          },
          {
            role: "user",
            content: [
              {
                type: "text",
                text: "Extract the expense details from this receipt image. Return only JSON."
              },
              {
                type: "image_url",
                image_url: {
                  url: `data:image/jpeg;base64,${image}`
                }
              }
            ]
          }
        ],
      }),
    });

    const aiDuration = Date.now() - aiStartTime;
    log.info("AI API response received", { requestId, status: response.status, aiDuration });

    if (!response.ok) {
      const errorText = await response.text();
      log.error("AI Gateway error", null, { requestId, status: response.status, errorText: errorText.substring(0, 500) });
      
      if (response.status === 429) {
        return new Response(
          JSON.stringify({ error: "Rate limit exceeded. Please try again later." }),
          { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      if (response.status === 402) {
        return new Response(
          JSON.stringify({ error: "AI usage credits exhausted. Please add credits." }),
          { status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      
      throw new Error(`AI Gateway error: ${response.status}`);
    }

    const data = await response.json();
    const content = data.choices?.[0]?.message?.content;

    log.info("AI response content", { requestId, contentLength: content?.length || 0 });

    // Parse the JSON response
    let extracted;
    try {
      const jsonMatch = content.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        extracted = JSON.parse(jsonMatch[0]);
        log.info("Extraction successful", { requestId, vendor: extracted.vendor, amount: extracted.amount });
      } else {
        throw new Error("No JSON found in response");
      }
    } catch (parseError) {
      log.error("Failed to parse AI response", parseError, { requestId });
      extracted = {
        date: new Date().toISOString().split("T")[0],
        amount: "0",
        vendor: "Unknown Vendor",
        category: "Other"
      };
    }

    const duration = Date.now() - startTime;
    log.info("Request complete", { requestId, duration, extracted });

    return new Response(
      JSON.stringify({ extracted }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error: unknown) {
    const duration = Date.now() - startTime;
    log.error("Unhandled exception", error, { requestId, duration });
    
    return new Response(
      JSON.stringify({ error: sanitizeError(error) }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.3";

const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY");

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// Structured logging helper
const log = {
  info: (message: string, data?: Record<string, unknown>) => {
    console.log(JSON.stringify({ level: "INFO", fn: "send-report-email", message, ...data, timestamp: new Date().toISOString() }));
  },
  warn: (message: string, data?: Record<string, unknown>) => {
    console.warn(JSON.stringify({ level: "WARN", fn: "send-report-email", message, ...data, timestamp: new Date().toISOString() }));
  },
  error: (message: string, error?: unknown, data?: Record<string, unknown>) => {
    const errorInfo = error instanceof Error 
      ? { errorMessage: error.message, errorStack: error.stack?.substring(0, 500) }
      : { errorMessage: String(error) };
    console.error(JSON.stringify({ level: "ERROR", fn: "send-report-email", message, ...errorInfo, ...data, timestamp: new Date().toISOString() }));
  },
};

interface ReportEmailRequest {
  type: "report" | "invitation" | "budget_alert";
  recipientEmail: string;
  subject?: string;
  message?: string;
  projectName?: string;
  projectId?: string;
  inviterEmail?: string;
  reportType?: "full" | "summary";
  threshold?: number;
  currentPercentage?: number;
  spent?: number;
  budget?: number;
  expenses?: Array<{
    date: string;
    category: string;
    vendor: string | null;
    amount: number;
    payment_method: string;
  }>;
  summary?: {
    totalAmount: string;
    expenseCount: number;
    categoryBreakdown: Record<string, number>;
  };
}

// Sanitize error messages to prevent information leakage
const sanitizeError = (error: unknown): string => {
  if (error instanceof Error) {
    const msg = error.message.toLowerCase();
    if (msg.includes('rate limit') || msg.includes('429')) {
      return 'Email rate limit exceeded. Please try again later.';
    }
    if (msg.includes('invalid') && msg.includes('email')) {
      return 'Invalid email address provided.';
    }
    if (msg.includes('api') || msg.includes('key')) {
      return 'Email service temporarily unavailable. Please try again.';
    }
  }
  return 'Failed to send email. Please try again.';
};

const handler = async (req: Request): Promise<Response> => {
  const requestId = crypto.randomUUID().substring(0, 8);
  const startTime = Date.now();
  
  log.info("Request received", { requestId, method: req.method });

  if (req.method === "OPTIONS") {
    log.info("CORS preflight handled", { requestId });
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Extract and validate user from JWT
    const authHeader = req.headers.get("Authorization");
    log.info("Auth header check", { requestId, hasAuthHeader: !!authHeader });
    
    if (!authHeader) {
      log.warn("Missing authorization header", { requestId });
      return new Response(
        JSON.stringify({ error: "Authorization header required" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    log.info("Creating Supabase client for user validation", { requestId });
    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } }
    );

    const { data: { user }, error: authError } = await supabaseClient.auth.getUser();
    
    if (authError || !user) {
      log.error("Authentication failed", authError, { requestId, hasUser: !!user });
      return new Response(
        JSON.stringify({ error: "Invalid or expired token" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    log.info("User authenticated", { requestId, userId: user.id });

    const body: ReportEmailRequest = await req.json();
    log.info("Request payload parsed", { requestId, type: body.type, recipientEmail: body.recipientEmail, projectName: body.projectName });

    // Validate ownership for project-related emails
    if (body.projectId && (body.type === "report" || body.type === "budget_alert")) {
      log.info("Validating project ownership", { requestId, projectId: body.projectId });
      
      const { data: project, error: projectError } = await supabaseClient
        .from("projects")
        .select("user_id")
        .eq("id", body.projectId)
        .single();

      if (projectError || !project) {
        log.warn("Project not found", { requestId, projectId: body.projectId, error: projectError });
        return new Response(
          JSON.stringify({ error: "Project not found" }),
          { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      // Check if user owns the project or is a collaborator
      if (project.user_id !== user.id) {
        log.info("Checking collaborator status", { requestId, projectId: body.projectId });
        
        const { data: collab } = await supabaseClient
          .from("project_collaborators")
          .select("id")
          .eq("project_id", body.projectId)
          .eq("user_id", user.id)
          .eq("status", "accepted")
          .maybeSingle();

        if (!collab) {
          log.warn("Unauthorized project access", { requestId, userId: user.id, projectId: body.projectId });
          return new Response(
            JSON.stringify({ error: "Unauthorized to send emails for this project" }),
            { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
        
        log.info("Collaborator access verified", { requestId });
      } else {
        log.info("Owner access verified", { requestId });
      }
    }

    let emailHtml = "";
    let emailSubject = "";

    if (body.type === "budget_alert") {
      log.info("Building budget alert email", { requestId, currentPercentage: body.currentPercentage });
      
      const percentageUsed = body.currentPercentage || 0;
      const isOverBudget = percentageUsed > 100;
      
      emailSubject = `⚠️ Budget Alert: ${body.projectName} at ${percentageUsed}%`;
      emailHtml = `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h1 style="color: ${isOverBudget ? '#DC2626' : '#F59E0B'};">
            ${isOverBudget ? '🚨 Budget Exceeded!' : '⚠️ Budget Alert'}
          </h1>
          <p>Your project <strong>${body.projectName}</strong> has reached ${percentageUsed}% of its budget.</p>
          <div style="background: ${isOverBudget ? '#FEE2E2' : '#FEF3C7'}; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <h2 style="margin: 0 0 10px 0; color: ${isOverBudget ? '#DC2626' : '#D97706'};">
              Budget Status
            </h2>
            <p style="margin: 5px 0;"><strong>Spent:</strong> ${body.spent?.toLocaleString()}</p>
            <p style="margin: 5px 0;"><strong>Budget:</strong> ${body.budget?.toLocaleString()}</p>
            <p style="margin: 5px 0;"><strong>Alert Threshold:</strong> ${body.threshold}%</p>
          </div>
          <p>Log in to review your expenses and take action.</p>
          <p style="color: #666; font-size: 14px; margin-top: 40px;">
            This email was sent from Project Expense Tracker.
          </p>
        </div>
      `;
    } else if (body.type === "invitation") {
      log.info("Building invitation email", { requestId, inviterEmail: body.inviterEmail });
      
      emailSubject = `You've been invited to collaborate on ${body.projectName}`;
      emailHtml = `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h1 style="color: #1E3A5F;">Project Collaboration Invitation</h1>
          <p>You've been invited by <strong>${body.inviterEmail}</strong> to collaborate on the project:</p>
          <div style="background: #f5f5f5; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <h2 style="margin: 0; color: #1E3A5F;">${body.projectName}</h2>
          </div>
          <p>Log in to your account to view and track expenses for this project.</p>
          <p style="color: #666; font-size: 14px; margin-top: 40px;">
            This email was sent from Project Expense Tracker.
          </p>
        </div>
      `;
    } else {
      log.info("Building report email", { requestId, reportType: body.reportType, expenseCount: body.expenses?.length });
      
      emailSubject = body.subject || `Expense Report: ${body.projectName}`;
      
      let expenseTableHtml = "";
      if (body.reportType === "full" && body.expenses) {
        expenseTableHtml = `
          <table style="width: 100%; border-collapse: collapse; margin: 20px 0;">
            <thead>
              <tr style="background: #1E3A5F; color: white;">
                <th style="padding: 12px; text-align: left;">Date</th>
                <th style="padding: 12px; text-align: left;">Category</th>
                <th style="padding: 12px; text-align: left;">Vendor</th>
                <th style="padding: 12px; text-align: right;">Amount</th>
                <th style="padding: 12px; text-align: left;">Payment</th>
              </tr>
            </thead>
            <tbody>
              ${body.expenses.map((e, i) => `
                <tr style="background: ${i % 2 === 0 ? '#f9f9f9' : 'white'};">
                  <td style="padding: 10px; border-bottom: 1px solid #eee;">${e.date}</td>
                  <td style="padding: 10px; border-bottom: 1px solid #eee;">${e.category}</td>
                  <td style="padding: 10px; border-bottom: 1px solid #eee;">${e.vendor || '-'}</td>
                  <td style="padding: 10px; border-bottom: 1px solid #eee; text-align: right;">${e.amount}</td>
                  <td style="padding: 10px; border-bottom: 1px solid #eee;">${e.payment_method}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        `;
      }

      const categoryBreakdown = body.summary?.categoryBreakdown
        ? Object.entries(body.summary.categoryBreakdown)
            .map(([cat, amt]) => `<li><strong>${cat}:</strong> ${amt}</li>`)
            .join('')
        : '';

      emailHtml = `
        <div style="font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto;">
          <h1 style="color: #1E3A5F;">Expense Report</h1>
          <h2 style="color: #333;">${body.projectName}</h2>
          
          ${body.message ? `<p style="background: #f5f5f5; padding: 15px; border-radius: 8px;">${body.message}</p>` : ''}
          
          <div style="background: #1E3A5F; color: white; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <h3 style="margin: 0 0 10px 0;">Summary</h3>
            <p style="font-size: 24px; margin: 0;"><strong>${body.summary?.totalAmount}</strong></p>
            <p style="margin: 5px 0 0 0;">${body.summary?.expenseCount} expense entries</p>
          </div>
          
          ${categoryBreakdown ? `
            <h3>Category Breakdown</h3>
            <ul>${categoryBreakdown}</ul>
          ` : ''}
          
          ${expenseTableHtml}
          
          <p style="color: #666; font-size: 14px; margin-top: 40px;">
            This report was generated from Project Expense Tracker.
          </p>
        </div>
      `;
    }

    log.info("Sending email via Resend", { requestId, subject: emailSubject, recipientEmail: body.recipientEmail });
    const emailStartTime = Date.now();

    const emailResponse = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${RESEND_API_KEY}`,
      },
      body: JSON.stringify({
        from: "Project Tracker <onboarding@resend.dev>",
        to: [body.recipientEmail],
        subject: emailSubject,
        html: emailHtml,
      }),
    });

    const emailDuration = Date.now() - emailStartTime;
    const responseData = await emailResponse.json();

    if (!emailResponse.ok) {
      log.error("Resend API error", null, { requestId, status: emailResponse.status, responseData, emailDuration });
      throw new Error(responseData.message || "Failed to send email");
    }

    const duration = Date.now() - startTime;
    log.info("Request complete", { requestId, duration, emailId: responseData.id, emailDuration });

    return new Response(JSON.stringify({ success: true, id: responseData.id }), {
      status: 200,
      headers: { "Content-Type": "application/json", ...corsHeaders },
    });
  } catch (error: unknown) {
    const duration = Date.now() - startTime;
    log.error("Unhandled exception", error, { requestId, duration });
    
    return new Response(
      JSON.stringify({ error: sanitizeError(error) }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
};

serve(handler);

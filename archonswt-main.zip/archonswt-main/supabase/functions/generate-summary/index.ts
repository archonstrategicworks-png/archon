import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.3";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// Structured logging helper
const log = {
  info: (message: string, data?: Record<string, unknown>) => {
    console.log(JSON.stringify({ level: "INFO", fn: "generate-summary", message, ...data, timestamp: new Date().toISOString() }));
  },
  warn: (message: string, data?: Record<string, unknown>) => {
    console.warn(JSON.stringify({ level: "WARN", fn: "generate-summary", message, ...data, timestamp: new Date().toISOString() }));
  },
  error: (message: string, error?: unknown, data?: Record<string, unknown>) => {
    const errorInfo = error instanceof Error 
      ? { errorMessage: error.message, errorStack: error.stack?.substring(0, 500) }
      : { errorMessage: String(error) };
    console.error(JSON.stringify({ level: "ERROR", fn: "generate-summary", message, ...errorInfo, ...data, timestamp: new Date().toISOString() }));
  },
};

serve(async (req) => {
  const requestId = crypto.randomUUID().substring(0, 8);
  const startTime = Date.now();
  
  log.info("Request received", { requestId, method: req.method });

  if (req.method === "OPTIONS") {
    log.info("CORS preflight handled", { requestId });
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Extract and validate user from JWT
    const authHeader = req.headers.get("Authorization");
    log.info("Auth header check", { requestId, hasAuthHeader: !!authHeader });
    
    if (!authHeader) {
      log.warn("Missing authorization header", { requestId });
      return new Response(
        JSON.stringify({ error: "Authorization header required" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    log.info("Creating Supabase client for user validation", { requestId });
    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } }
    );

    const { data: { user }, error: authError } = await supabaseClient.auth.getUser();
    
    if (authError || !user) {
      log.error("Authentication failed", authError, { requestId, hasUser: !!user });
      return new Response(
        JSON.stringify({ error: "Invalid or expired token" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    log.info("User authenticated", { requestId, userId: user.id });

    // Parse request to get optional project IDs filter
    const { projectIds } = await req.json();
    log.info("Request payload parsed", { requestId, projectIdsCount: projectIds?.length || 0 });

    // Fetch projects from database (RLS ensures user only sees their own projects)
    log.info("Fetching projects", { requestId });
    let projectsQuery = supabaseClient
      .from('projects')
      .select('id, project_name, budget, status');
    
    if (projectIds && Array.isArray(projectIds) && projectIds.length > 0) {
      // Validate projectIds are valid UUIDs
      const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
      const validProjectIds = projectIds.filter(id => typeof id === 'string' && uuidRegex.test(id));
      
      log.info("Filtering by project IDs", { requestId, validCount: validProjectIds.length, totalCount: projectIds.length });
      
      if (validProjectIds.length === 0) {
        log.warn("No valid project IDs provided", { requestId });
        return new Response(
          JSON.stringify({ error: "No valid project IDs provided" }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      
      projectsQuery = projectsQuery.in('id', validProjectIds);
    }

    const { data: projects, error: projectsError } = await projectsQuery;

    if (projectsError) {
      log.error("Projects fetch failed", projectsError, { requestId });
      return new Response(
        JSON.stringify({ error: "Failed to fetch projects" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    log.info("Projects fetched", { requestId, count: projects?.length || 0 });

    if (!projects || projects.length === 0) {
      log.info("No projects found", { requestId });
      return new Response(
        JSON.stringify({ error: "No projects found" }),
        { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Fetch expenses from database (RLS ensures user only sees their own expenses)
    log.info("Fetching expenses", { requestId });
    const projectIdList = projects.map(p => p.id);
    const { data: expenses, error: expensesError } = await supabaseClient
      .from('expenses')
      .select('id, amount, category, payment_method, date, vendor')
      .in('project_id', projectIdList);

    if (expensesError) {
      log.error("Expenses fetch failed", expensesError, { requestId });
      return new Response(
        JSON.stringify({ error: "Failed to fetch expenses" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    log.info("Expenses fetched", { requestId, count: expenses?.length || 0 });

    // Calculate total server-side
    const total = (expenses || []).reduce((sum, e) => sum + Number(e.amount || 0), 0);

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) {
      log.error("LOVABLE_API_KEY not configured", null, { requestId });
      return new Response(
        JSON.stringify({ error: "AI service not configured" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Sanitize text for prompt injection prevention
    const sanitizeForPrompt = (text: string | null | undefined): string => {
      if (!text) return '';
      return String(text).replace(/[<>{}]/g, '').substring(0, 100);
    };

    // Prepare expense summary for the AI with sanitized data
    const categoryTotals: Record<string, number> = {};
    const paymentTotals: Record<string, number> = {};

    (expenses || []).forEach((e: any) => {
      const category = sanitizeForPrompt(e.category) || 'Other';
      const paymentMethod = sanitizeForPrompt(e.payment_method) || 'Unknown';
      categoryTotals[category] = (categoryTotals[category] || 0) + Number(e.amount || 0);
      paymentTotals[paymentMethod] = (paymentTotals[paymentMethod] || 0) + Number(e.amount || 0);
    });

    const prompt = `You are a financial analyst helping a construction company understand their expenses.

Here is the expense data:
- Total spending: ₹${total.toLocaleString("en-IN")}
- Number of projects: ${projects.length}
- Total expense entries: ${(expenses || []).length}

Category breakdown:
${Object.entries(categoryTotals)
  .map(([cat, amt]) => `- ${cat}: ₹${Number(amt).toLocaleString("en-IN")}`)
  .join("\n")}

Payment method breakdown:
${Object.entries(paymentTotals)
  .map(([method, amt]) => `- ${method}: ₹${Number(amt).toLocaleString("en-IN")}`)
  .join("\n")}

Please provide a brief, professional analysis (3-4 paragraphs) in plain English that includes:
1. Overview of total spending and distribution across categories
2. Observations about payment methods used
3. Any notable patterns or recommendations for expense management
4. Suggestions for audit compliance and record-keeping

Keep the tone professional but accessible for a non-accountant.`;

    log.info("Calling AI API", { requestId, projectCount: projects.length, expenseCount: (expenses || []).length, total });
    const aiStartTime = Date.now();

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          {
            role: "user",
            content: prompt
          }
        ],
      }),
    });

    const aiDuration = Date.now() - aiStartTime;
    log.info("AI API response received", { requestId, status: response.status, aiDuration });

    if (!response.ok) {
      const errorText = await response.text();
      log.error("AI Gateway error", null, { requestId, status: response.status, errorText: errorText.substring(0, 500) });
      
      if (response.status === 429) {
        return new Response(
          JSON.stringify({ error: "Rate limit exceeded. Please try again later." }),
          { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      if (response.status === 402) {
        return new Response(
          JSON.stringify({ error: "AI usage credits exhausted. Please add credits." }),
          { status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      
      throw new Error(`AI Gateway error: ${response.status}`);
    }

    const data = await response.json();
    const summary = data.choices?.[0]?.message?.content;

    const duration = Date.now() - startTime;
    log.info("Request complete", { requestId, duration, summaryLength: summary?.length || 0 });

    return new Response(
      JSON.stringify({ summary }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error: unknown) {
    const duration = Date.now() - startTime;
    log.error("Unhandled exception", error, { requestId, duration });
    
    const errorMessage = error instanceof Error ? error.message : "Failed to generate summary";
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
